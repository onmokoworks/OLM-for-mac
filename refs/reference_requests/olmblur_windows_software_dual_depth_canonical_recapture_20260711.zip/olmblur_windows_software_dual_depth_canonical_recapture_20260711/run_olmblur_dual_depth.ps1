param(
    [Parameter(Mandatory=$true)][string]$PluginPath,
    [Parameter(Mandatory=$true)][string]$AfterFX,
    [Parameter(Mandatory=$true)][string]$ExrOutputTemplate,
    [Parameter(Mandatory=$false)][string]$OutputDir = ""
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExpectedHash = "f0611785e7b14ac4fcfc75f23b8862beb4539eee52d25d472556849535e96e5b"
$RequiredExrTemplate = "OLMBlur OpenEXR RGBA Float32 No Compression"
$RunDir = if ($OutputDir) { New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null; (Resolve-Path -LiteralPath $OutputDir).Path } else { Join-Path $Root "run" }
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
$SummaryPath = Join-Path $RunDir "return_manifest.json"
function Write-Json($Path, $Value) { $Value | ConvertTo-Json -Depth 20 | Set-Content -Encoding UTF8 -Path $Path }
function Fail-Closed([string]$Status, [string]$Message, $Provenance = $null) {
    $record = [ordered]@{ kind="olmblur_windows_dual_depth_return"; status=$Status; rendered=$false; error=$Message; plugin=$Provenance; required_sha256=$ExpectedHash }
    Write-Json $SummaryPath $record
    Write-Error "$Status`: $Message"
    exit 2
}
if (-not (Test-Path -LiteralPath $PluginPath -PathType Leaf)) { Fail-Closed "missing_plugin" "PluginPath does not name a file" }
$plugin = Get-Item -LiteralPath $PluginPath
if ($plugin.Name -ne "OLMBlur.aex") { Fail-Closed "missing_plugin" "PluginPath must name OLMBlur.aex" }
$hash = (Get-FileHash -LiteralPath $plugin.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
$provenance = [ordered]@{ path=$plugin.FullName; size_bytes=[int64]$plugin.Length; last_write_time_utc=$plugin.LastWriteTimeUtc.ToString("o"); sha256=$hash; required_sha256=$ExpectedHash }
if ($hash -ne $ExpectedHash) { Fail-Closed "hash_mismatch" "installed OLMBlur.aex SHA-256 $hash does not equal required $ExpectedHash" $provenance }
if (-not (Test-Path -LiteralPath $AfterFX -PathType Leaf)) { Fail-Closed "missing_afterfx" "AfterFX.exe was not found; no render was started" $provenance }
if ($ExrOutputTemplate -cne $RequiredExrTemplate) { Fail-Closed "wrong_exr_template" "ExrOutputTemplate must be exactly '$RequiredExrTemplate' (no compression, FLOAT32, RGBA)" $provenance }
$lanes = @(@{ name="8bpc_png"; bits=8; mode="png"; dir=(Join-Path $Root "lanes\8bpc"); output=(Join-Path $RunDir "8bpc_png") }, @{ name="32bpc_float32_rgba_exr"; bits=32; mode="exr_render_queue"; dir=(Join-Path $Root "lanes\32bpc"); output=(Join-Path $RunDir "32bpc_float32_rgba_exr") })
$results = @()
foreach ($lane in $lanes) {
    New-Item -ItemType Directory -Force -Path $lane.output | Out-Null
    foreach ($caseNumber in 1..7) {
        $caseId = "case_{0:D4}" -f $caseNumber
        $env:OLM_AE_REQUEST_DIR = $lane.dir; $env:OLM_AE_CASE_ID = $caseId; $env:OLM_AE_OUTPUT_DIR = $lane.output
        $env:OLM_AE_LOG_PATH = Join-Path $RunDir "$($lane.name)_$caseId.log"; $env:OLM_AE_RESULT_JSON = Join-Path $RunDir "$($lane.name)_$caseId.result.json"
        $env:OLM_AE_OUTPUT_MODE = $lane.mode; $env:OLM_AE_OUTPUT_TEMPLATE = $ExrOutputTemplate; $env:OLM_AE_FORCE_SOFTWARE = "1"; $env:OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT = "1"; $env:OLM_AE_FORCE_NEW_PROJECT = "1"; $env:OLM_AE_DISABLE_EFFECT = ""
        & $AfterFX -r (Join-Path $Root "render_olmblur_case.jsx")
        if ($LASTEXITCODE -ne 0) { Fail-Closed "render_failed" "$($lane.name) $caseId AfterFX exit $LASTEXITCODE" $provenance }
        $result = Get-Content $env:OLM_AE_RESULT_JSON -Raw | ConvertFrom-Json
        if ($result.status -ne "ok") { Fail-Closed "render_failed" "$($lane.name) $caseId reported $($result.error)" $provenance }
        if ($lane.bits -eq 8 -and -not (Test-Path (Join-Path $lane.output "$caseId.png"))) { Fail-Closed "missing_output" "$($lane.name) $caseId PNG missing" $provenance }
        if ($lane.bits -eq 32 -and -not (Test-Path (Join-Path $lane.output "$caseId.exr"))) { Fail-Closed "missing_output" "$($lane.name) $caseId EXR missing" $provenance }
        $results += [ordered]@{ lane=$lane.name; case_id=$caseId; result=$result }
    }
    $controlDir = Join-Path $RunDir "$($lane.name)_no_effect_control"; New-Item -ItemType Directory -Force -Path $controlDir | Out-Null
    $env:OLM_AE_CASE_ID = "case_0001"; $env:OLM_AE_OUTPUT_DIR = $controlDir; $env:OLM_AE_LOG_PATH = Join-Path $RunDir "$($lane.name)_no_effect_control.log"; $env:OLM_AE_RESULT_JSON = Join-Path $RunDir "$($lane.name)_no_effect_control.result.json"; $env:OLM_AE_DISABLE_EFFECT = "1"
    & $AfterFX -r (Join-Path $Root "render_olmblur_case.jsx")
    if ($LASTEXITCODE -ne 0) { Fail-Closed "no_effect_control_failed" "$($lane.name) control AfterFX exit $LASTEXITCODE" $provenance }
    $control = Get-Content $env:OLM_AE_RESULT_JSON -Raw | ConvertFrom-Json
    if ($control.status -ne "ok" -or -not $control.effect_disabled) { Fail-Closed "no_effect_control_failed" "$($lane.name) control was not recorded as disabled" $provenance }
    if ($lane.bits -eq 8 -and -not (Test-Path (Join-Path $controlDir "case_0001.png"))) { Fail-Closed "no_effect_control_failed" "$($lane.name) control PNG missing" $provenance }
    if ($lane.bits -eq 32 -and -not (Test-Path (Join-Path $controlDir "case_0001.exr"))) { Fail-Closed "no_effect_control_failed" "$($lane.name) control EXR missing" $provenance }
    $results += [ordered]@{ lane=$lane.name; case_id="case_0001"; no_effect_control=$control }
}
$env:OLM_AE_DISABLE_EFFECT = ""
$record = [ordered]@{ kind="olmblur_windows_dual_depth_return"; status="rendered"; rendered=$true; plugin=$provenance; required_sha256=$ExpectedHash; ae_version=($results[0].result.ae_version); renderer="Software"; color_settings=[ordered]@{ working_space=$results[0].result.project_working_space; linear_blending=$false; bits_per_channel=@(8,32) }; exr_output_template=$ExrOutputTemplate; exr_header_required=[ordered]@{ container_format="OpenEXR"; compression="none"; sample_type="float"; bits_per_channel=32; channel_order="RGBA"; channel_count=4 }; results=$results }
Write-Json $SummaryPath $record
Write-Host "OK: dual-depth OLMBlur recapture complete; return manifest $SummaryPath"
