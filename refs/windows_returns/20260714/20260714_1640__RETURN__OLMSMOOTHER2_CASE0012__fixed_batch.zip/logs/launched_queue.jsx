/* Generated serial AE witness queue. Common behavior; probes live in CDB templates. */
(function () {
    function env(name) { try { return $.getenv(name) || ""; } catch (_) { return ""; } }
    function write(path, value, append) {
        var file = new File(path); file.encoding = "UTF-8";
        if (!file.open(append ? "a" : "w")) { throw new Error("could not write " + path); }
        file.write(value); file.close();
    }
    var bootstrapPath = File($.fileName).parent.fsName + "/queue_bootstrap.log";
    var work = env("WINDOWS_WITNESS_WORK_ROOT");
    var runId = env("WINDOWS_WITNESS_RUN_ID");
    var root = env("WINDOWS_WITNESS_PACKAGE_ROOT") || File($.fileName).parent.parent.fsName;
    root = new Folder(root).fsName;
    var queueSha256 = env("WINDOWS_WITNESS_QUEUE_SHA256");
    var bootstrapTempPath = bootstrapPath + ".tmp";
    write(bootstrapTempPath, "WITNESS_QUEUE_BOOTSTRAP\n" +
        "run_id=" + runId + "\n" +
        "work=" + work + "\n" +
        "root=" + root + "\n" +
        "queue_sha256=" + queueSha256 + "\n", false);
    if (!(new File(bootstrapTempPath)).rename("queue_bootstrap.log")) {
        throw new Error("could not publish queue bootstrap marker");
    }
    var requestDir = new Folder(root + "/request").fsName;
    var cases = ["legacy_case_0012_gamma5_red_blue_current_aex"];
    var extraEnvironment = {"OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT": "1"};
    if (!work || !runId || !root || !queueSha256) { throw new Error("WINDOWS_WITNESS queue binding is required"); }
    var queueLog = work + "/queue.log";
    write(queueLog, "WITNESS_QUEUE_START run_id=" + runId + "\n", false);
    for (var i = 0; i < cases.length; i++) {
        var caseId = cases[i];
        $.setenv("OLM_AE_REQUEST_DIR", requestDir);
        $.setenv("OLM_AE_CASE_ID", caseId);
        $.setenv("OLM_AE_OUTPUT_DIR", work + "/exports/" + caseId);
        $.setenv("OLM_AE_LOG_PATH", work + "/ae_" + caseId + ".log");
        $.setenv("OLM_AE_RESULT_JSON", work + "/ae_result_" + caseId + ".json");
        $.setenv("OLM_AE_READY_MARKER", work + "/ready_" + caseId + ".marker");
        $.setenv("OLM_AE_CONTINUE_MARKER", work + "/continue_" + caseId + ".marker");
        $.setenv("OLM_AE_KEEP_OPEN", i === cases.length - 1 ? "0" : "1");
        $.setenv("OLM_AE_FORCE_NEW_PROJECT", i === 0 ? "1" : "0");
        for (var key in extraEnvironment) {
            if (extraEnvironment.hasOwnProperty(key)) { $.setenv(key, String(extraEnvironment[key])); }
        }
        write(queueLog, "WITNESS_CASE_START run_id=" + runId + " case_id=" + caseId + "\n", true);
        $.evalFile(new File(root + "/scripts/renderer.jsx"));
        write(queueLog, "WITNESS_CASE_END run_id=" + runId + " case_id=" + caseId + "\n", true);
    }
    write(queueLog, "WITNESS_QUEUE_END run_id=" + runId + "\n", true);
}());
