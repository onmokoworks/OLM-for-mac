# OLMSmoother2 Current-AEX Witness Contract

- Decision: `blocked-narrow-proof-only`
- Next step: Do not add broad PNGs or global toggles. Read/trace only the listed witness paths until the first Windows-vs-Mac divergence is classified.

## Keep

- Keep key-enabled Smooth Range threshold promotion.
- Keep FUN_18000e170 bit mapping: A(x,y-1), R(x-1,y), A(x,y).
- Keep FUN_18000f270 shape: suppress only e170==4, otherwise call e3a0.
- Keep FUN_18000fef0 key 50 -> f270(..., 1.0).
- Keep final 8bpc writer as ruled out for the active residuals.

## Rejected Global Toggles

- curve_idx: `rejected-inert`
- f270_suppression: `rejected-worse`

## Witnesses

| Case | XY | Reference | Candidate | Local path | Required proof |
| --- | --- | --- | --- | --- | --- |
| `legacy_case_0004_current_aex` | `[1903, 519]` | `[103, 103, 103, 113]` | `[0, 0, 0, 0]` | `local-transparent-center-no-polygon-passthrough` | Windows must decide whether idx=208 also produces zero polygon vertices, or whether a helper appends neighbor-derived samples before cce0. |
| `legacy_case_0012_gamma5_red_blue_current_aex` | `[91, 841]` | `[0, 0, 0, 0]` | `[90, 90, 90, 91]` | `local-cardinal6-f270-e3a0-append` | Windows must decide whether this exact witness differs in c280 idx, cardinal6 desc/key, e170 bits/code, f270/e3a0 emission, cce0 blend, or final u8 writer. |

## Local Trace Details

### legacy_case_0004_current_aex `[1903, 519]`
- class_threshold: `{'mode': '0', 'field': '2', 'threshold': '0.02100000', 'enable_key': '1', 'invert_key': '0', 'smooth_range': '2', 'key_pred': '1'}`
- build_polygon: `{'x': '1903', 'y': '519', 'idx': '208', 'c': 'ffffffff', 'bits': '0,0,0,0,0'}`
- polygon_done: `{'count': '0'}`
- passthrough: `{'out': '1.00000000,1.00000000,1.00000000,0.00000000'}`

### legacy_case_0012_gamma5_red_blue_current_aex `[91, 841]`
- class_threshold: `{'mode': '0', 'field': '88', 'threshold': '0.88099998', 'enable_key': '1', 'invert_key': '0', 'smooth_range': '88', 'key_pred': '1'}`
- build_polygon: `{'x': '91', 'y': '841', 'idx': '105', 'c': '00ff00ff', 'bits': '2,0,0,8,1'}`
- polygon_done: `{'count': '1'}`
- cardinal6: `{'desc': '91,841,1,91,843,5', 'key': '50', 'count_before': '0'}`
- e170: `{'desc': '91,841,1,91,843,5', 'a_prev': '1', 'r_left': '0', 'a_center': '0', 'c': '2'}`
- f270: `{'c': '2', 'p3': '1', 'extra_n': '0.40000001', 'count_before': '0'}`
- e3a0: `{'desc': '91,841,1,91,843,5', 'scale_m': '0.57999998', 'scale_h': '1', 'trap': '1.74,0,0.5', 'weight': '0.35632184'}`
- append: `{'src': '91,840', 'dst': '91,841', 'rgba': '0.99106717,0.99106717,0.99106717,0.99607843', 'weight': '0.35632184'}`
- cce0_after_b120: `{'out': '0.99106723,0.99106723,0.99106723,0.35492450'}`
