[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$AexPath,
  [string]$CdbPath='C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe',
  [string]$AfterFxPath='C:\Program Files\Adobe\Adobe After Effects 2026\Support Files\AfterFX.exe',
  [string]$WorkRoot=(Join-Path $PSScriptRoot 'work')
)
$ErrorActionPreference='Stop'
$requestId='olmdirectionalblur_front_alpha_host_boundary_2025_20260711'
$caseId='db_angle0_alpha_fade_hard_edges'
$expectedHash='d3e5e4079a759d521dc7457ebf998487fe43b00f182a1e2f910b187936b6c06e'
$expectedSize=56832L
$runId='dblur-boundary-'+[guid]::NewGuid().ToString('N')
$work=Join-Path $WorkRoot $runId
New-Item -ItemType Directory -Force -Path $work|Out-Null
$script:returnPath=Join-Path $work 'RETURN_RUNTIME_TRACE.json'

function Finish([string]$status,[hashtable]$body,[int]$code) {
  $returnZip=Join-Path $WorkRoot ($requestId+'_'+$runId+'_return_windows.zip')
  $r=[ordered]@{request_id=$requestId;status=$status;run_id=$runId;return_zip=$returnZip}
  foreach($e in $body.GetEnumerator()){$r[$e.Key]=$e.Value}
  $j=$r|ConvertTo-Json -Depth 12
  $j|Set-Content -LiteralPath $script:returnPath -Encoding UTF8
  try {
    Compress-Archive -Path (Join-Path $work '*') -DestinationPath $returnZip -CompressionLevel Optimal
  } catch {
    $r.status='return_packaging_failure'
    $r.failure=@{stage='return_zip';reason=$_.Exception.Message;original_status=$status}
    $j=$r|ConvertTo-Json -Depth 12
    $j|Set-Content -LiteralPath $script:returnPath -Encoding UTF8
    $j
    exit 8
  }
  $j
  "return_zip=$returnZip"
  exit $code
}
function Strip-Rows([string]$src,[string]$dst,[int]$rowbytes) {
  $input=[IO.File]::OpenRead($src)
  try {
    if($input.Length -ne ([int64]$rowbytes*1080)){throw "raw size $($input.Length)"}
    $output=[IO.File]::Create($dst)
    try {
      $row=New-Object byte[] $rowbytes
      for($y=0;$y -lt 1080;$y++){
        $n=0
        while($n -lt $rowbytes){$got=$input.Read($row,$n,$rowbytes-$n);if($got -le 0){throw "short row $y"};$n+=$got}
        $output.Write($row,0,7680)
      }
    } finally {$output.Dispose()}
  } finally {$input.Dispose()}
  if((Get-Item -LiteralPath $dst).Length -ne 8294400){throw 'tight size mismatch'}
}
if(-not(Test-Path -LiteralPath $AexPath -PathType Leaf)){Finish 'binary_identity_mismatch' @{failure=@{stage='preflight';reason="AEX absent: $AexPath"}} 2}
$aex=Get-Item -LiteralPath $AexPath
$hash=(Get-FileHash -Algorithm SHA256 -LiteralPath $aex.FullName).Hash.ToLowerInvariant()
if($aex.Length -ne $expectedSize -or $hash -ne $expectedHash){Finish 'binary_identity_mismatch' @{module=@{path=$aex.FullName;size=$aex.Length;sha256=$hash};failure=@{stage='preflight';reason='size/SHA256 mismatch; AE not launched'}} 2}
foreach($exe in @($CdbPath,$AfterFxPath)){if(-not(Test-Path -LiteralPath $exe -PathType Leaf)){Finish 'render_failure' @{failure=@{stage='preflight';reason="executable absent: $exe"}} 2}}

$trace=Join-Path $work 'cdb_stdout.txt';$stderr=Join-Path $work 'cdb_stderr.txt'
$rawIn=Join-Path $work 'input_argb8_padded.bin';$rawOut=Join-Path $work 'output_argb8_padded.bin'
$tightIn=Join-Path $work 'input_argb8_tight.bin';$tightOut=Join-Path $work 'output_argb8_tight.bin'
$cmd=Join-Path $work 'boundary_capture.cdb'
$template=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'boundary_capture.cdb.in') -Raw
$template.Replace('__TRACE__',$trace).Replace('__RAW_IN__',$rawIn).Replace('__RAW_OUT__',$rawOut).Replace('__RUN__',$runId)|Set-Content -LiteralPath $cmd -Encoding ASCII
$env:OLM_AE_REQUEST_DIR=Join-Path $PSScriptRoot 'case';$env:OLM_AE_CASE_ID=$caseId
$env:OLM_AE_OUTPUT_DIR=Join-Path $work 'render';$env:OLM_AE_LOG_PATH=Join-Path $work 'ae_render.log';$env:OLM_AE_RESULT_JSON=Join-Path $work 'ae_render_result.json'
$env:OLM_AE_FORCE_NEW_PROJECT='1';$env:OLM_AE_FORCE_SOFTWARE='1';$env:OLM_AE_INPUT_ALPHA_MODE='PREMULTIPLIED'
New-Item -ItemType Directory -Force -Path $env:OLM_AE_OUTPUT_DIR|Out-Null
$jsx=Join-Path $PSScriptRoot 'scripts\ae_render_single_case.jsx'
$cdbArguments="-cf `"$cmd`" `"$AfterFxPath`" -r `"$jsx`""
$proc=Start-Process -FilePath $CdbPath -ArgumentList $cdbArguments -RedirectStandardOutput $trace -RedirectStandardError $stderr -NoNewWindow -PassThru -Wait
$text=if(Test-Path $trace){Get-Content $trace -Raw}else{''}

$block=[regex]::Match($text,'OLMDB_MODULE_BEGIN(?<b>[\s\S]*?)OLMDB_MODULE_END').Groups['b'].Value
$pathM=[regex]::Match($block,'(?im)^\s*Image path:\s*(?<v>.+?)\s*$');$baseM=[regex]::Match($block,'(?im)^\s*(?<v>[0-9a-f`]+)\s+[0-9a-f`]+\s+OLMDirectionalBlur')
$sizeM=[regex]::Match($block,'(?im)^\s*ImageSize:\s*(?<v>[0-9a-f]+)');$timeM=[regex]::Match($block,'(?im)^\s*Timestamp:\s*(?<v>.+?)\s*$')
$fvM=[regex]::Match($block,'(?im)^\s*File version:\s*(?<v>.+?)\s*$');$pvM=[regex]::Match($block,'(?im)^\s*Product version:\s*(?<v>.+?)\s*$')
if(-not $pathM.Success -or -not $baseM.Success -or -not $sizeM.Success){Finish 'module_identity_failure' @{failure=@{stage='lmvm';reason='loaded module metadata absent'}} 3}
try{$loaded=(Resolve-Path -LiteralPath $pathM.Groups['v'].Value.Trim()).Path;$wanted=(Resolve-Path -LiteralPath $aex.FullName).Path}catch{Finish 'module_identity_failure' @{failure=@{stage='loaded_path';reason=$_.Exception.Message}} 3}
$loadedFile=Get-Item $loaded;$loadedHash=(Get-FileHash -Algorithm SHA256 $loaded).Hash.ToLowerInvariant();$imageSize=[Convert]::ToInt64($sizeM.Groups['v'].Value,16)
$module=[ordered]@{path=$loaded;base='0x'+$baseM.Groups['v'].Value.Replace('`','');image_size=$imageSize;timestamp=$timeM.Groups['v'].Value.Trim();file_version=$fvM.Groups['v'].Value.Trim();product_version=$pvM.Groups['v'].Value.Trim();sha256=$loadedHash;file_size=$loadedFile.Length}
if($loaded -ne $wanted -or $loadedHash -ne $expectedHash -or $loadedFile.Length -ne $expectedSize){Finish 'binary_identity_mismatch' @{module=$module;failure=@{stage='loaded_identity';reason='loaded path/hash/file size mismatch'}} 3}

$pattern='OLMDB_(?<kind>INPUT|OUTPUT)\s+run_id=(?<run>\S+)\s+pid=(?<pid>\d+)\s+invocation=(?<invocation>\S+)\s+context=(?<context>\S+)\s+output_token=(?<output_token>\S+)\s+world=(?<world>\S+)\s+data=(?<data>\S+)\s+rowbytes=(?<rowbytes>-?\d+)\s+width=(?<width>-?\d+)\s+height=(?<height>-?\d+)\s+extent_left=(?<extent_left>-?\d+)\s+extent_top=(?<extent_top>-?\d+)\s+extent_right=(?<extent_right>-?\d+)\s+extent_bottom=(?<extent_bottom>-?\d+)\s+origin_x=(?<origin_x>-?\d+)\s+origin_y=(?<origin_y>-?\d+)\s+hit=(?<hit>\d+)'
$hits=@([regex]::Matches($text,$pattern));$ins=@($hits|Where-Object{$_.Groups['kind'].Value -eq 'INPUT'});$outs=@($hits|Where-Object{$_.Groups['kind'].Value -eq 'OUTPUT'})
if($ins.Count -ne 1 -or $outs.Count -ne 1){Finish 'exact_dump_failure' @{module=$module;failure=@{stage='hit_count';reason="input=$($ins.Count), output=$($outs.Count), exact one each required"}} 4}
function World($m){[ordered]@{world=$m.Groups['world'].Value;data=$m.Groups['data'].Value;rowbytes=[int]$m.Groups['rowbytes'].Value;width=[int]$m.Groups['width'].Value;height=[int]$m.Groups['height'].Value;extent=@{left=[int]$m.Groups['extent_left'].Value;top=[int]$m.Groups['extent_top'].Value;right=[int]$m.Groups['extent_right'].Value;bottom=[int]$m.Groups['extent_bottom'].Value};origin=@{x=[int]$m.Groups['origin_x'].Value;y=[int]$m.Groups['origin_y'].Value};invocation=$m.Groups['invocation'].Value;context=$m.Groups['context'].Value;output_token=$m.Groups['output_token'].Value}}
$iw=World $ins[0];$ow=World $outs[0];$pids=@($hits|%{$_.Groups['pid'].Value}|Select-Object -Unique);$runs=@($hits|%{$_.Groups['run'].Value}|Select-Object -Unique)
if($pids.Count -ne 1 -or $runs.Count -ne 1 -or $runs[0] -ne $runId -or $iw.invocation -ne $ow.invocation -or $iw.context -ne $ow.context -or $iw.output_token -ne $ow.world){Finish 'exact_dump_failure' @{module=$module;input_world=$iw;output_world=$ow;failure=@{stage='same_invocation';reason='run id, PID, frame pointer, render context, or output-world token disagreement'}} 4}
foreach($w in @($iw,$ow)){if($w.data -match '^0+$' -or $w.width -ne 1920 -or $w.height -ne 1080 -or $w.rowbytes -lt 7680){Finish 'world_validation_failure' @{module=$module;input_world=$iw;output_world=$ow;failure=@{stage='pf_world';reason='invalid ARGB8 world'}} 5}}
try{Strip-Rows $rawIn $tightIn $iw.rowbytes;Strip-Rows $rawOut $tightOut $ow.rowbytes}catch{Finish 'exact_dump_failure' @{module=$module;input_world=$iw;output_world=$ow;failure=@{stage='strip_rows';reason=$_.Exception.Message}} 6}
$rr=if(Test-Path $env:OLM_AE_RESULT_JSON){Get-Content $env:OLM_AE_RESULT_JSON -Raw|ConvertFrom-Json}else{$null}
if($null -eq $rr -or $rr.status -ne 'ok' -or $proc.ExitCode -ne 0){Finish 'render_failure' @{module=$module;failure=@{stage='render';reason='AE result failed/missing or CDB nonzero';cdb_exit_code=$proc.ExitCode}} 7}
$case=[ordered]@{id=$caseId;input_alpha_mode='PREMULTIPLIED';request_manifest='case/request_manifest.json';input='case/input/directionalblur_context_scale_20260606__software__fr24__db_angle0_alpha_fade_hard_edges_before_effects.png';reference='case/expected/directionalblur_context_scale_20260606__software__fr24__db_angle0_alpha_fade_hard_edges.png';reference_provenance='UNPROVEN retained June19 reference; producing AEX was not hash-bound'}
$dumps=[ordered]@{input=@{raw_path=$rawIn;raw_bytes=(Get-Item $rawIn).Length;tight_path=$tightIn;tight_bytes=(Get-Item $tightIn).Length;sha256=(Get-FileHash -Algorithm SHA256 $tightIn).Hash.ToLowerInvariant()};output=@{raw_path=$rawOut;raw_bytes=(Get-Item $rawOut).Length;tight_path=$tightOut;tight_bytes=(Get-Item $tightOut).Length;sha256=(Get-FileHash -Algorithm SHA256 $tightOut).Hash.ToLowerInvariant()}}
Finish 'answered' @{ae_pid=[int]$pids[0];case=$case;module=$module;input_world=$iw;output_world=$ow;dumps=$dumps;failure=$null} 0
