
# RVA 40f0..4260
000040f0 48895c2408                       mov qword ptr [rsp + 8], rbx
000040f5 55                               push rbp
000040f6 56                               push rsi
000040f7 57                               push rdi
000040f8 4156                             push r14
000040fa 4157                             push r15
000040fc 4881ec50010000                   sub rsp, 0x150
00004103 498bf9                           mov rdi, r9
00004106 498be8                           mov rbp, r8
00004109 488bf2                           mov rsi, rdx
0000410c 488bd9                           mov rbx, rcx
0000410f 498b01                           mov rax, qword ptr [r9]
00004112 440fb7702c                       movzx r14d, word ptr [rax + 0x2c]
00004117 4533ff                           xor r15d, r15d
0000411a 4c897c2430                       mov qword ptr [rsp + 0x30], r15
0000411f 4c897c2438                       mov qword ptr [rsp + 0x38], r15
00004124 498b4108                         mov rax, qword ptr [r9 + 8]
00004128 4c8b10                           mov r10, qword ptr [rax]
0000412b 4c8d442430                       lea r8, [rsp + 0x30]
00004130 33d2                             xor edx, edx
00004132 488b8eb8000000                   mov rcx, qword ptr [rsi + 0xb8]
00004139 41ffd2                           call r10
0000413c 8bc8                             mov ecx, eax
0000413e e89dcc0000                       call 0x10de0
00004143 488b4708                         mov rax, qword ptr [rdi + 8]
00004147 4c8b4010                         mov r8, qword ptr [rax + 0x10]
0000414b 488d542438                       lea rdx, [rsp + 0x38]
00004150 488b8eb8000000                   mov rcx, qword ptr [rsi + 0xb8]
00004157 41ffd0                           call r8
0000415a 8bc8                             mov ecx, eax
0000415c e87fcc0000                       call 0x10de0
00004161 4c89bc2498010000                 mov qword ptr [rsp + 0x198], r15
00004169 4c89bc2488010000                 mov qword ptr [rsp + 0x188], r15
00004171 488b4708                         mov rax, qword ptr [rdi + 8]
00004175 4c8b08                           mov r9, qword ptr [rax]
00004178 4c8d842498010000                 lea r8, [rsp + 0x198]
00004180 33d2                             xor edx, edx
00004182 488b8eb8000000                   mov rcx, qword ptr [rsi + 0xb8]
00004189 41ffd1                           call r9
0000418c 488b4708                         mov rax, qword ptr [rdi + 8]
00004190 4c8b4010                         mov r8, qword ptr [rax + 0x10]
00004194 488d942488010000                 lea rdx, [rsp + 0x188]
0000419c 488b8eb8000000                   mov rcx, qword ptr [rsi + 0xb8]
000041a3 41ffd0                           call r8
000041a6 488d8c24f0000000                 lea rcx, [rsp + 0xf0]
000041ae e8ad510000                       call 0x9360
000041b3 90                               nop 
000041b4 48895c2420                       mov qword ptr [rsp + 0x20], rbx
000041b9 4c8d4c2440                       lea r9, [rsp + 0x40]
000041be 4c8bc7                           mov r8, rdi
000041c1 488bd5                           mov rdx, rbp
000041c4 488bce                           mov rcx, rsi
000041c7 e8c4440000                       call 0x8690
000041cc 664183fe08                       cmp r14w, 8
000041d1 7527                             jne 0x41fa
000041d3 488d442440                       lea rax, [rsp + 0x40]
000041d8 4889442420                       mov qword ptr [rsp + 0x20], rax
000041dd 4c8b8c2488010000                 mov r9, qword ptr [rsp + 0x188]
000041e5 4c8b842498010000                 mov r8, qword ptr [rsp + 0x198]
000041ed 488bd5                           mov rdx, rbp
000041f0 488bce                           mov rcx, rsi
000041f3 e828330000                       call 0x7520
000041f8 eb5b                             jmp 0x4255
000041fa 664183fe10                       cmp r14w, 0x10
000041ff 7527                             jne 0x4228
00004201 488d442440                       lea rax, [rsp + 0x40]
00004206 4889442420                       mov qword ptr [rsp + 0x20], rax
0000420b 4c8b8c2488010000                 mov r9, qword ptr [rsp + 0x188]
00004213 4c8b842498010000                 mov r8, qword ptr [rsp + 0x198]
0000421b 488bd5                           mov rdx, rbp
0000421e 488bce                           mov rcx, rsi
00004221 e8ea2a0000                       call 0x6d10
00004226 eb2d                             jmp 0x4255
00004228 664183fe20                       cmp r14w, 0x20
0000422d 7526                             jne 0x4255
0000422f 488d442440                       lea rax, [rsp + 0x40]
00004234 4889442420                       mov qword ptr [rsp + 0x20], rax
00004239 4c8b8c2488010000                 mov r9, qword ptr [rsp + 0x188]
00004241 4c8b842498010000                 mov r8, qword ptr [rsp + 0x198]
00004249 488bd5                           mov rdx, rbp
0000424c 488bce                           mov rcx, rsi
0000424f e8dc3a0000                       call 0x7d30
00004254 90                               nop 
00004255 488d8c24f0000000                 lea rcx, [rsp + 0xf0]

# RVA 43c0..4460
000043c0 48895c2410                       mov qword ptr [rsp + 0x10], rbx
000043c5 55                               push rbp
000043c6 56                               push rsi
000043c7 57                               push rdi
000043c8 4883ec40                         sub rsp, 0x40
000043cc 488bfa                           mov rdi, rdx
000043cf 488d2dd2d10100                   lea rbp, [rip + 0x1d1d2]
000043d6 48896c2430                       mov qword ptr [rsp + 0x30], rbp
000043db c744243802000000                 mov dword ptr [rsp + 0x38], 2
000043e3 488bb180010000                   mov rsi, qword ptr [rcx + 0x180]
000043ea 4889742428                       mov qword ptr [rsp + 0x28], rsi
000043ef 488b06                           mov rax, qword ptr [rsi]
000043f2 4c8d442470                       lea r8, [rsp + 0x70]
000043f7 ba02000000                       mov edx, 2
000043fc 488bcd                           mov rcx, rbp
000043ff ffd0                             call rax
00004401 85c0                             test eax, eax
00004403 753f                             jne 0x4444
00004405 488b5c2470                       mov rbx, qword ptr [rsp + 0x70]
0000440a 48895c2420                       mov qword ptr [rsp + 0x20], rbx
0000440f 4885ff                           test rdi, rdi
00004412 740c                             je 0x4420
00004414 488b4308                         mov rax, qword ptr [rbx + 8]
00004418 488bcf                           mov rcx, rdi
0000441b ffd0                             call rax
0000441d 488bf8                           mov rdi, rax
00004420 4885db                           test rbx, rbx
00004423 740f                             je 0x4434
00004425 488b4608                         mov rax, qword ptr [rsi + 8]
00004429 ba02000000                       mov edx, 2
0000442e 488bcd                           mov rcx, rbp
00004431 ffd0                             call rax
00004433 90                               nop 
00004434 488bc7                           mov rax, rdi
00004437 488b5c2468                       mov rbx, qword ptr [rsp + 0x68]
0000443c 4883c440                         add rsp, 0x40
00004440 5f                               pop rdi
00004441 5e                               pop rsi
00004442 5d                               pop rbp
00004443 c3                               ret 
00004444 c74424600d000000                 mov dword ptr [rsp + 0x60], 0xd
0000444c 488d15155b0200                   lea rdx, [rip + 0x25b15]
00004453 488d4c2460                       lea rcx, [rsp + 0x60]
00004458 e8bdb00100                       call 0x1f51a
0000445d cc                               int3 
0000445e cc                               int3 
0000445f cc                               int3 

# RVA 45a0..4640
000045a0 48895c2410                       mov qword ptr [rsp + 0x10], rbx
000045a5 4889742420                       mov qword ptr [rsp + 0x20], rsi
000045aa 57                               push rdi
000045ab 4883ec40                         sub rsp, 0x40
000045af 4863da                           movsxd rbx, edx
000045b2 488d35dfcf0100                   lea rsi, [rip + 0x1cfdf]
000045b9 4889742430                       mov qword ptr [rsp + 0x30], rsi
000045be c744243802000000                 mov dword ptr [rsp + 0x38], 2
000045c6 488bb980010000                   mov rdi, qword ptr [rcx + 0x180]
000045cd 48897c2428                       mov qword ptr [rsp + 0x28], rdi
000045d2 488b07                           mov rax, qword ptr [rdi]
000045d5 4c8d442460                       lea r8, [rsp + 0x60]
000045da ba02000000                       mov edx, 2
000045df 488bce                           mov rcx, rsi
000045e2 ffd0                             call rax
000045e4 85c0                             test eax, eax
000045e6 753d                             jne 0x4625
000045e8 488b442460                       mov rax, qword ptr [rsp + 0x60]
000045ed 4889442420                       mov qword ptr [rsp + 0x20], rax
000045f2 4c8b00                           mov r8, qword ptr [rax]
000045f5 488bcb                           mov rcx, rbx
000045f8 48c1e102                         shl rcx, 2
000045fc 41ffd0                           call r8
000045ff 488bd8                           mov rbx, rax
00004602 4c8b4708                         mov r8, qword ptr [rdi + 8]
00004606 ba02000000                       mov edx, 2
0000460b 488bce                           mov rcx, rsi
0000460e 41ffd0                           call r8
00004611 90                               nop 
00004612 488bc3                           mov rax, rbx
00004615 488b5c2458                       mov rbx, qword ptr [rsp + 0x58]
0000461a 488b742468                       mov rsi, qword ptr [rsp + 0x68]
0000461f 4883c440                         add rsp, 0x40
00004623 5f                               pop rdi
00004624 c3                               ret 
00004625 c74424500d000000                 mov dword ptr [rsp + 0x50], 0xd
0000462d 488d1534590200                   lea rdx, [rip + 0x25934]
00004634 488d4c2450                       lea rcx, [rsp + 0x50]
00004639 e8dcae0100                       call 0x1f51a
0000463e cc                               int3 
0000463f cc                               int3 

# RVA 4640..6510
00004640 488bc4                           mov rax, rsp
00004643 55                               push rbp
00004644 53                               push rbx
00004645 56                               push rsi
00004646 57                               push rdi
00004647 4154                             push r12
00004649 4155                             push r13
0000464b 4156                             push r14
0000464d 4157                             push r15
0000464f 488d6888                         lea rbp, [rax - 0x78]
00004653 4881ec38010000                   sub rsp, 0x138
0000465a 0f2970a8                         movaps xmmword ptr [rax - 0x58], xmm6
0000465e 0f297898                         movaps xmmword ptr [rax - 0x68], xmm7
00004662 440f294088                       movaps xmmword ptr [rax - 0x78], xmm8
00004667 4c8bf2                           mov r14, rdx
0000466a 488bf1                           mov rsi, rcx
0000466d ff157dca0100                     call qword ptr [rip + 0x1ca7d]
00004673 b920000000                       mov ecx, 0x20
00004678 3bc1                             cmp eax, ecx
0000467a 0f4fc1                           cmovg eax, ecx
0000467d 898650c90300                     mov dword ptr [rsi + 0x3c950], eax
00004683 418b4678                         mov eax, dword ptr [r14 + 0x78]
00004687 894614                           mov dword ptr [rsi + 0x14], eax
0000468a 66410f6e467c                     movd xmm0, dword ptr [r14 + 0x7c]
00004690 0f5bc0                           cvtdq2ps xmm0, xmm0
00004693 f30f114618                       movss dword ptr [rsi + 0x18], xmm0
00004698 66410f6e467c                     movd xmm0, dword ptr [r14 + 0x7c]
0000469e f30fe6c0                         cvtdq2pd xmm0, xmm0
000046a2 e8c1ae0100                       call 0x1f568
000046a7 f20f5ac0                         cvtsd2ss xmm0, xmm0
000046ab f30f11461c                       movss dword ptr [rsi + 0x1c], xmm0
000046b0 66410f6e467c                     movd xmm0, dword ptr [r14 + 0x7c]
000046b6 f30fe6c0                         cvtdq2pd xmm0, xmm0
000046ba e8afae0100                       call 0x1f56e
000046bf f20f5ac0                         cvtsd2ss xmm0, xmm0
000046c3 f30f114620                       movss dword ptr [rsi + 0x20], xmm0
000046c8 f2410f104e28                     movsd xmm1, qword ptr [r14 + 0x28]
000046ce 660f5ac9                         cvtpd2ps xmm1, xmm1
000046d2 f30f118e38c90300                 movss dword ptr [rsi + 0x3c938], xmm1
000046da f2410f104630                     movsd xmm0, qword ptr [r14 + 0x30]
000046e0 660f5ac0                         cvtpd2ps xmm0, xmm0
000046e4 f30f11863cc90300                 movss dword ptr [rsi + 0x3c93c], xmm0
000046ec 418b4654                         mov eax, dword ptr [r14 + 0x54]
000046f0 894624                           mov dword ptr [rsi + 0x24], eax
000046f3 f30f1006                         movss xmm0, dword ptr [rsi]
000046f7 0f5ac0                           cvtps2pd xmm0, xmm0
000046fa f20f103506cf0100                 movsd xmm6, qword ptr [rip + 0x1cf06]
00004702 0f28d6                           movaps xmm2, xmm6
00004705 f20f5ed0                         divsd xmm2, xmm0
00004709 66410f6e4658                     movd xmm0, dword ptr [r14 + 0x58]
0000470f f30fe6c0                         cvtdq2pd xmm0, xmm0
00004713 f20f59c2                         mulsd xmm0, xmm2
00004717 f20f2cc0                         cvttsd2si eax, xmm0
0000471b 894628                           mov dword ptr [rsi + 0x28], eax
0000471e 418b465c                         mov eax, dword ptr [r14 + 0x5c]
00004722 89462c                           mov dword ptr [rsi + 0x2c], eax
00004725 66410f6e4660                     movd xmm0, dword ptr [r14 + 0x60]
0000472b f30fe6c0                         cvtdq2pd xmm0, xmm0
0000472f f20f59c2                         mulsd xmm0, xmm2
00004733 f20f2cc0                         cvttsd2si eax, xmm0
00004737 894630                           mov dword ptr [rsi + 0x30], eax
0000473a 66410f6e4e64                     movd xmm1, dword ptr [r14 + 0x64]
00004740 f30fe6c9                         cvtdq2pd xmm1, xmm1
00004744 f20f59ca                         mulsd xmm1, xmm2
00004748 f20f2cc1                         cvttsd2si eax, xmm1
0000474c 8986e8a90300                     mov dword ptr [rsi + 0x3a9e8], eax
00004752 488d4e68                         lea rcx, [rsi + 0x68]
00004756 ba30750000                       mov edx, 0x7530
0000475b e8206f0000                       call 0xb680
00004760 f30f1006                         movss xmm0, dword ptr [rsi]
00004764 0f5ac0                           cvtps2pd xmm0, xmm0
00004767 0f28d6                           movaps xmm2, xmm6
0000476a f20f5ed0                         divsd xmm2, xmm0
0000476e 66410f6e4e68                     movd xmm1, dword ptr [r14 + 0x68]
00004774 f30fe6c9                         cvtdq2pd xmm1, xmm1
00004778 f20f59d1                         mulsd xmm2, xmm1
0000477c f20f2cc2                         cvttsd2si eax, xmm2
00004780 8986eca90300                     mov dword ptr [rsi + 0x3a9ec], eax
00004786 488d8e28d50100                   lea rcx, [rsi + 0x1d528]
0000478d ba30750000                       mov edx, 0x7530
00004792 e8e96e0000                       call 0xb680
00004797 f30f1006                         movss xmm0, dword ptr [rsi]
0000479b 0f5ac0                           cvtps2pd xmm0, xmm0
0000479e 0f28d6                           movaps xmm2, xmm6
000047a1 f20f5ed0                         divsd xmm2, xmm0
000047a5 66410f6e4e6c                     movd xmm1, dword ptr [r14 + 0x6c]
000047ab f30fe6c9                         cvtdq2pd xmm1, xmm1
000047af f20f59d1                         mulsd xmm2, xmm1
000047b3 f20f2cd2                         cvttsd2si edx, xmm2
000047b7 899630c90300                     mov dword ptr [rsi + 0x3c930], edx
000047bd 488d8ef0a90300                   lea rcx, [rsi + 0x3a9f0]
000047c4 e8b76e0000                       call 0xb680
000047c9 f30f1006                         movss xmm0, dword ptr [rsi]
000047cd 0f5ac0                           cvtps2pd xmm0, xmm0
000047d0 f20f5ef0                         divsd xmm6, xmm0
000047d4 66410f6e4e70                     movd xmm1, dword ptr [r14 + 0x70]
000047da f30fe6c9                         cvtdq2pd xmm1, xmm1
000047de f20f59f1                         mulsd xmm6, xmm1
000047e2 f20f2cd6                         cvttsd2si edx, xmm6
000047e6 899634c90300                     mov dword ptr [rsi + 0x3c934], edx
000047ec 488d8e90b90300                   lea rcx, [rsi + 0x3b990]
000047f3 e8886e0000                       call 0xb680
000047f8 488d5e10                         lea rbx, [rsi + 0x10]
000047fc 488d7e0c                         lea rdi, [rsi + 0xc]
00004800 498b4608                         mov rax, qword ptr [r14 + 8]
00004804 48895c2420                       mov qword ptr [rsp + 0x20], rbx
00004809 4c8bcf                           mov r9, rdi
0000480c 448b4028                         mov r8d, dword ptr [rax + 0x28]
00004810 8b5024                           mov edx, dword ptr [rax + 0x24]
00004813 488bce                           mov rcx, rsi
00004816 e895d3ffff                       call 0x1bb0
0000481b 660f6e07                         movd xmm0, dword ptr [rdi]
0000481f 0f5bc0                           cvtdq2ps xmm0, xmm0
00004822 f30f5e4614                       divss xmm0, dword ptr [rsi + 0x14]
00004827 f30f2cc8                         cvttss2si ecx, xmm0
0000482b 83c1fe                           add ecx, -2
0000482e 890f                             mov dword ptr [rdi], ecx
00004830 c7858000000000000000             mov dword ptr [rbp + 0x80], 0
0000483a 488d8580000000                   lea rax, [rbp + 0x80]
00004841 480f49c7                         cmovns rax, rdi
00004845 8b08                             mov ecx, dword ptr [rax]
00004847 890f                             mov dword ptr [rdi], ecx
00004849 830302                           add dword ptr [rbx], 2
0000484c 448b3b                           mov r15d, dword ptr [rbx]
0000484f f30f1005cdcd0100                 movss xmm0, dword ptr [rip + 0x1cdcd]
00004857 f30f5e06                         divss xmm0, dword ptr [rsi]
0000485b f3440f2ce8                       cvttss2si r13d, xmm0
00004860 4489ad90000000                   mov dword ptr [rbp + 0x90], r13d
00004867 442bf9                           sub r15d, ecx
0000486a 41ffc7                           inc r15d
0000486d 4489bd88000000                   mov dword ptr [rbp + 0x88], r15d
00004874 418bff                           mov edi, r15d
00004877 410faffd                         imul edi, r13d
0000487b 8d1cbd00000000                   lea ebx, [rdi*4]
00004882 8bd3                             mov edx, ebx
00004884 498b0e                           mov rcx, qword ptr [r14]
00004887 e814fdffff                       call 0x45a0
0000488c 488945b8                         mov qword ptr [rbp - 0x48], rax
00004890 488bd0                           mov rdx, rax
00004893 498b0e                           mov rcx, qword ptr [r14]
00004896 e825fbffff                       call 0x43c0
0000489b 48898640c90300                   mov qword ptr [rsi + 0x3c940], rax
000048a2 8bd7                             mov edx, edi
000048a4 498b0e                           mov rcx, qword ptr [r14]
000048a7 e8f4fcffff                       call 0x45a0
000048ac 488945c0                         mov qword ptr [rbp - 0x40], rax
000048b0 488bd0                           mov rdx, rax
000048b3 498b0e                           mov rcx, qword ptr [r14]
000048b6 e805fbffff                       call 0x43c0
000048bb 48898648c90300                   mov qword ptr [rsi + 0x3c948], rax
000048c2 8bd3                             mov edx, ebx
000048c4 498b0e                           mov rcx, qword ptr [r14]
000048c7 e8d4fcffff                       call 0x45a0
000048cc 488945c8                         mov qword ptr [rbp - 0x38], rax
000048d0 488bd0                           mov rdx, rax
000048d3 498b0e                           mov rcx, qword ptr [r14]
000048d6 e8e5faffff                       call 0x43c0
000048db 48894638                         mov qword ptr [rsi + 0x38], rax
000048df 8bd7                             mov edx, edi
000048e1 498b0e                           mov rcx, qword ptr [r14]
000048e4 e8b7fcffff                       call 0x45a0
000048e9 488945d0                         mov qword ptr [rbp - 0x30], rax
000048ed 488bd0                           mov rdx, rax
000048f0 498b0e                           mov rcx, qword ptr [r14]
000048f3 e8c8faffff                       call 0x43c0
000048f8 48894640                         mov qword ptr [rsi + 0x40], rax
000048fc 8bd7                             mov edx, edi
000048fe 498b0e                           mov rcx, qword ptr [r14]
00004901 e89afcffff                       call 0x45a0
00004906 488945d8                         mov qword ptr [rbp - 0x28], rax
0000490a 488bd0                           mov rdx, rax
0000490d 498b0e                           mov rcx, qword ptr [r14]
00004910 e8abfaffff                       call 0x43c0
00004915 48894648                         mov qword ptr [rsi + 0x48], rax
00004919 8bd7                             mov edx, edi
0000491b 498b0e                           mov rcx, qword ptr [r14]
0000491e e87dfcffff                       call 0x45a0
00004923 488945e0                         mov qword ptr [rbp - 0x20], rax
00004927 488bd0                           mov rdx, rax
0000492a 498b0e                           mov rcx, qword ptr [r14]
0000492d e88efaffff                       call 0x43c0
00004932 48894650                         mov qword ptr [rsi + 0x50], rax
00004936 8bd7                             mov edx, edi
00004938 498b0e                           mov rcx, qword ptr [r14]
0000493b e820fbffff                       call 0x4460
00004940 488945e8                         mov qword ptr [rbp - 0x18], rax
00004944 488bd0                           mov rdx, rax
00004947 498b0e                           mov rcx, qword ptr [r14]
0000494a e831f9ffff                       call 0x4280
0000494f 488bd8                           mov rbx, rax
00004952 488945a0                         mov qword ptr [rbp - 0x60], rax
00004956 428d146d00000000                 lea edx, [r13*2]
0000495e 498b0e                           mov rcx, qword ptr [r14]
00004961 e83afcffff                       call 0x45a0
00004966 488945f0                         mov qword ptr [rbp - 0x10], rax
0000496a 488bd0                           mov rdx, rax
0000496d 498b0e                           mov rcx, qword ptr [r14]
00004970 e84bfaffff                       call 0x43c0
00004975 4c8bc0                           mov r8, rax
00004978 48894580                         mov qword ptr [rbp - 0x80], rax
0000497c 4533e4                           xor r12d, r12d
0000497f 4963fd                           movsxd rdi, r13d
00004982 48897d98                         mov qword ptr [rbp - 0x68], rdi
00004986 4585ed                           test r13d, r13d
00004989 7e41                             jle 0x49cc
0000498b 33db                             xor ebx, ebx
0000498d 0f1f00                           nop dword ptr [rax]
00004990 66410f6ecc                       movd xmm1, r12d
00004995 0f5bc9                           cvtdq2ps xmm1, xmm1
00004998 f30f594e04                       mulss xmm1, dword ptr [rsi + 4]
0000499d 0f28c1                           movaps xmm0, xmm1
000049a0 e8bb860100                       call 0x1d060
000049a5 0f28c8                           movaps xmm1, xmm0
000049a8 0fc6c801                         shufps xmm1, xmm0, 1
000049ac 4c8b4580                         mov r8, qword ptr [rbp - 0x80]
000049b0 f3410f110cd8                     movss dword ptr [r8 + rbx*8], xmm1
000049b6 f3410f1144d804                   movss dword ptr [r8 + rbx*8 + 4], xmm0
000049bd 41ffc4                           inc r12d
000049c0 48ffc3                           inc rbx
000049c3 483bdf                           cmp rbx, rdi
000049c6 7cc8                             jl 0x4990
000049c8 488b5da0                         mov rbx, qword ptr [rbp - 0x60]
000049cc 410fb64e74                       movzx ecx, byte ptr [r14 + 0x74]
000049d1 488d1578cfffff                   lea rdx, [rip - 0x3088]
000049d8 488d0521ceffff                   lea rax, [rip - 0x31df]
000049df 84c9                             test cl, cl
000049e1 480f44d0                         cmove rdx, rax
000049e5 488d0534cbffff                   lea rax, [rip - 0x34cc]
000049ec 4c8d0d7dc8ffff                   lea r9, [rip - 0x3783]
000049f3 490f44c1                         cmove rax, r9
000049f7 48894658                         mov qword ptr [rsi + 0x58], rax
000049fb 48895660                         mov qword ptr [rsi + 0x60], rdx
000049ff 33d2                             xor edx, edx
00004a01 899580000000                     mov dword ptr [rbp + 0x80], edx
00004a07 4585ff                           test r15d, r15d
00004a0a 0f8ede010000                     jle 0x4bee
00004a10 488bcb                           mov rcx, rbx
00004a13 48899d98000000                   mov qword ptr [rbp + 0x98], rbx
00004a1a 4533c9                           xor r9d, r9d
00004a1d 4c894d90                         mov qword ptr [rbp - 0x70], r9
00004a21 488d04bd00000000                 lea rax, [rdi*4]
00004a29 488945b0                         mov qword ptr [rbp - 0x50], rax
00004a2d 4533d2                           xor r10d, r10d
00004a30 4c895588                         mov qword ptr [rbp - 0x78], r10
00004a34 428d04ad00000000                 lea eax, [r13*4]
00004a3c 4898                             cdqe 
00004a3e 48c1e002                         shl rax, 2
00004a42 488945a8                         mov qword ptr [rbp - 0x58], rax
00004a46 66660f1f840000000000             nop word ptr [rax + rax]
00004a50 8b460c                           mov eax, dword ptr [rsi + 0xc]
00004a53 03c2                             add eax, edx
00004a55 66440f6ec0                       movd xmm8, eax
00004a5a 450f5bc0                         cvtdq2ps xmm8, xmm8
00004a5e 4c8b7e38                         mov r15, qword ptr [rsi + 0x38]
00004a62 4d03fa                           add r15, r10
00004a65 4c8b6640                         mov r12, qword ptr [rsi + 0x40]
00004a69 4d03e1                           add r12, r9
00004a6c 488b7e50                         mov rdi, qword ptr [rsi + 0x50]
00004a70 4903f9                           add rdi, r9
00004a73 33db                             xor ebx, ebx
00004a75 4c8b6d98                         mov r13, qword ptr [rbp - 0x68]
00004a79 4d85ed                           test r13, r13
00004a7c 0f8e2c010000                     jle 0x4bae
00004a82 0f1f4000                         nop dword ptr [rax]
00004a86 66660f1f840000000000             nop word ptr [rax + rax]
00004a90 f3410f101cd8                     movss xmm3, dword ptr [r8 + rbx*8]
00004a96 f3410f59d8                       mulss xmm3, xmm8
00004a9b 410f28f0                         movaps xmm6, xmm8
00004a9f f30f597614                       mulss xmm6, dword ptr [rsi + 0x14]
00004aa4 f3410f5974d804                   mulss xmm6, dword ptr [r8 + rbx*8 + 4]
00004aab 0f28fb                           movaps xmm7, xmm3
00004aae f30f597e1c                       mulss xmm7, dword ptr [rsi + 0x1c]
00004ab3 0f28c6                           movaps xmm0, xmm6
00004ab6 f30f594620                       mulss xmm0, dword ptr [rsi + 0x20]
00004abb f30f5cf8                         subss xmm7, xmm0
00004abf f30f58be38c90300                 addss xmm7, dword ptr [rsi + 0x3c938]
00004ac7 f30f59761c                       mulss xmm6, dword ptr [rsi + 0x1c]
00004acc f30f595e20                       mulss xmm3, dword ptr [rsi + 0x20]
00004ad1 f30f58f3                         addss xmm6, xmm3
00004ad5 f30f58b63cc90300                 addss xmm6, dword ptr [rsi + 0x3c93c]
00004add 4c8b5658                         mov r10, qword ptr [rsi + 0x58]
00004ae1 498b4e08                         mov rcx, qword ptr [r14 + 8]
00004ae5 448b4124                         mov r8d, dword ptr [rcx + 0x24]
00004ae9 428d048500000000                 lea eax, [r8*4]
00004af1 f30f11742430                     movss dword ptr [rsp + 0x30], xmm6
00004af7 f30f117c2428                     movss dword ptr [rsp + 0x28], xmm7
00004afd 89442420                         mov dword ptr [rsp + 0x20], eax
00004b01 448b4928                         mov r9d, dword ptr [rcx + 0x28]
00004b05 498bd7                           mov rdx, r15
00004b08 498b8e98000000                   mov rcx, qword ptr [r14 + 0x98]
00004b0f 41ffd2                           call r10
00004b12 488b8d98000000                   mov rcx, qword ptr [rbp + 0x98]
00004b19 88040b                           mov byte ptr [rbx + rcx], al
00004b1c 4c8b5660                         mov r10, qword ptr [rsi + 0x60]
00004b20 498b4608                         mov rax, qword ptr [r14 + 8]
00004b24 f30f11742428                     movss dword ptr [rsp + 0x28], xmm6
00004b2a f30f117c2420                     movss dword ptr [rsp + 0x20], xmm7
00004b30 448b4828                         mov r9d, dword ptr [rax + 0x28]
00004b34 448b4024                         mov r8d, dword ptr [rax + 0x24]
00004b38 498bd4                           mov rdx, r12
00004b3b 498b8e90000000                   mov rcx, qword ptr [r14 + 0x90]
00004b42 41ffd2                           call r10
00004b45 41807e4400                       cmp byte ptr [r14 + 0x44], 0
00004b4a 742b                             je 0x4b77
00004b4c 4c8b5660                         mov r10, qword ptr [rsi + 0x60]
00004b50 498b4608                         mov rax, qword ptr [r14 + 8]
00004b54 f30f11742428                     movss dword ptr [rsp + 0x28], xmm6
00004b5a f30f117c2420                     movss dword ptr [rsp + 0x20], xmm7
00004b60 448b4828                         mov r9d, dword ptr [rax + 0x28]
00004b64 448b4024                         mov r8d, dword ptr [rax + 0x24]
00004b68 488bd7                           mov rdx, rdi
00004b6b 498b8e88000000                   mov rcx, qword ptr [r14 + 0x88]
00004b72 41ffd2                           call r10
00004b75 eb06                             jmp 0x4b7d
00004b77 c7070000803f                     mov dword ptr [rdi], 0x3f800000
00004b7d 48ffc3                           inc rbx
00004b80 4983c710                         add r15, 0x10
00004b84 4983c404                         add r12, 4
00004b88 4883c704                         add rdi, 4
00004b8c 493bdd                           cmp rbx, r13
00004b8f 4c8b4580                         mov r8, qword ptr [rbp - 0x80]
00004b93 0f8cf7feffff                     jl 0x4a90
00004b99 488b8d98000000                   mov rcx, qword ptr [rbp + 0x98]
00004ba0 8b9580000000                     mov edx, dword ptr [rbp + 0x80]
00004ba6 4c8b4d90                         mov r9, qword ptr [rbp - 0x70]
00004baa 4c8b5588                         mov r10, qword ptr [rbp - 0x78]
00004bae ffc2                             inc edx
00004bb0 899580000000                     mov dword ptr [rbp + 0x80], edx
00004bb6 4c0355a8                         add r10, qword ptr [rbp - 0x58]
00004bba 4c895588                         mov qword ptr [rbp - 0x78], r10
00004bbe 4c034db0                         add r9, qword ptr [rbp - 0x50]
00004bc2 4c894d90                         mov qword ptr [rbp - 0x70], r9
00004bc6 498bfd                           mov rdi, r13
00004bc9 4903cd                           add rcx, r13
00004bcc 48898d98000000                   mov qword ptr [rbp + 0x98], rcx
00004bd3 448bbd88000000                   mov r15d, dword ptr [rbp + 0x88]
00004bda 413bd7                           cmp edx, r15d
00004bdd 4c8b4580                         mov r8, qword ptr [rbp - 0x80]
00004be1 0f8c69feffff                     jl 0x4a50
00004be7 448bad90000000                   mov r13d, dword ptr [rbp + 0x90]
00004bee 8b8e50c90300                     mov ecx, dword ptr [rsi + 0x3c950]
00004bf4 66410f6ef7                       movd xmm6, r15d
00004bf9 0f5bf6                           cvtdq2ps xmm6, xmm6
00004bfc 660f6ec1                         movd xmm0, ecx
00004c00 0f5bc0                           cvtdq2ps xmm0, xmm0
00004c03 f30f5ef0                         divss xmm6, xmm0
00004c07 33c0                             xor eax, eax
00004c09 85c9                             test ecx, ecx
00004c0b 7e6e                             jle 0x4c7b
00004c0d 0f1f00                           nop dword ptr [rax]
00004c10 8d5801                           lea ebx, [rax + 1]
00004c13 660f6ec3                         movd xmm0, ebx
00004c17 0f5bc0                           cvtdq2ps xmm0, xmm0
00004c1a f30f59c6                         mulss xmm0, xmm6
00004c1e f30f2cd0                         cvttss2si edx, xmm0
00004c22 660f6ec8                         movd xmm1, eax
00004c26 0f5bc9                           cvtdq2ps xmm1, xmm1
00004c29 f30f59ce                         mulss xmm1, xmm6
00004c2d f30f2cc9                         cvttss2si ecx, xmm1
00004c31 488b8648c90300                   mov rax, qword ptr [rsi + 0x3c948]
00004c38 4889442448                       mov qword ptr [rsp + 0x48], rax
00004c3d 488b8640c90300                   mov rax, qword ptr [rsi + 0x3c940]
00004c44 4889442440                       mov qword ptr [rsp + 0x40], rax
00004c49 89542438                         mov dword ptr [rsp + 0x38], edx
00004c4d 894c2430                         mov dword ptr [rsp + 0x30], ecx
00004c51 44897c2428                       mov dword ptr [rsp + 0x28], r15d
00004c56 44896c2420                       mov dword ptr [rsp + 0x20], r13d
00004c5b 4c8b4e50                         mov r9, qword ptr [rsi + 0x50]
00004c5f 4c8b4648                         mov r8, qword ptr [rsi + 0x48]
00004c63 488b5638                         mov rdx, qword ptr [rsi + 0x38]
00004c67 488bce                           mov rcx, rsi
00004c6a e811dbffff                       call 0x2780
00004c6f 8bc3                             mov eax, ebx
00004c71 8b8e50c90300                     mov ecx, dword ptr [rsi + 0x3c950]
00004c77 3bd9                             cmp ebx, ecx
00004c79 7c95                             jl 0x4c10
00004c7b 33c0                             xor eax, eax
00004c7d 85c9                             test ecx, ecx
00004c7f 7e7d                             jle 0x4cfe
00004c81 4c8b65a0                         mov r12, qword ptr [rbp - 0x60]
00004c85 6666660f1f840000000000           nop word ptr [rax + rax]
00004c90 8d5801                           lea ebx, [rax + 1]
00004c93 660f6ec3                         movd xmm0, ebx
00004c97 0f5bc0                           cvtdq2ps xmm0, xmm0
00004c9a f30f59c6                         mulss xmm0, xmm6
00004c9e f30f2cd0                         cvttss2si edx, xmm0
00004ca2 660f6ec8                         movd xmm1, eax
00004ca6 0f5bc9                           cvtdq2ps xmm1, xmm1
00004ca9 f30f59ce                         mulss xmm1, xmm6
00004cad f30f2cc9                         cvttss2si ecx, xmm1
00004cb1 488b8648c90300                   mov rax, qword ptr [rsi + 0x3c948]
00004cb8 4889442450                       mov qword ptr [rsp + 0x50], rax
00004cbd 488b8640c90300                   mov rax, qword ptr [rsi + 0x3c940]
00004cc4 4889442448                       mov qword ptr [rsp + 0x48], rax
00004cc9 89542440                         mov dword ptr [rsp + 0x40], edx
00004ccd 894c2438                         mov dword ptr [rsp + 0x38], ecx
00004cd1 44897c2430                       mov dword ptr [rsp + 0x30], r15d
00004cd6 44896c2428                       mov dword ptr [rsp + 0x28], r13d
00004cdb 4c89642420                       mov qword ptr [rsp + 0x20], r12
00004ce0 4c8b4e40                         mov r9, qword ptr [rsi + 0x40]
00004ce4 4c8b4648                         mov r8, qword ptr [rsi + 0x48]
00004ce8 488b5638                         mov rdx, qword ptr [rsi + 0x38]
00004cec 488bce                           mov rcx, rsi
00004cef e8ccd7ffff                       call 0x24c0
00004cf4 8bc3                             mov eax, ebx
00004cf6 3b9e50c90300                     cmp ebx, dword ptr [rsi + 0x3c950]
00004cfc 7c92                             jl 0x4c90
00004cfe 0f57ff                           xorps xmm7, xmm7
00004d01 4585ff                           test r15d, r15d
00004d04 0f8ee6000000                     jle 0x4df0
00004d0a 4533c9                           xor r9d, r9d
00004d0d 488bdf                           mov rbx, rdi
00004d10 48c1e304                         shl rbx, 4
00004d14 4c8d24bd00000000                 lea r12, [rdi*4]
00004d1c 458d510c                         lea r10d, [r9 + 0xc]
00004d20 458bdf                           mov r11d, r15d
00004d23 4885ff                           test rdi, rdi
00004d26 0f8eb4000000                     jle 0x4de0
00004d2c 498bd1                           mov rdx, r9
00004d2f 498bca                           mov rcx, r10
00004d32 4c8bc7                           mov r8, rdi
00004d35 6666660f1f840000000000           nop word ptr [rax + rax]
00004d40 488b8648c90300                   mov rax, qword ptr [rsi + 0x3c948]
00004d47 f30f101402                       movss xmm2, dword ptr [rdx + rax]
00004d4c 0f2ed7                           ucomiss xmm2, xmm7
00004d4f 7456                             je 0x4da7
00004d51 488b8640c90300                   mov rax, qword ptr [rsi + 0x3c940]
00004d58 f30f104401f4                     movss xmm0, dword ptr [rcx + rax - 0xc]
00004d5e f30f5e0401                       divss xmm0, dword ptr [rcx + rax]
00004d63 488b4638                         mov rax, qword ptr [rsi + 0x38]
00004d67 f30f114401f4                     movss dword ptr [rcx + rax - 0xc], xmm0
00004d6d 488b8640c90300                   mov rax, qword ptr [rsi + 0x3c940]
00004d74 f30f104c01f8                     movss xmm1, dword ptr [rcx + rax - 8]
00004d7a f30f5e0c01                       divss xmm1, dword ptr [rcx + rax]
00004d7f 488b4638                         mov rax, qword ptr [rsi + 0x38]
00004d83 f30f114c01f8                     movss dword ptr [rcx + rax - 8], xmm1
00004d89 488b8640c90300                   mov rax, qword ptr [rsi + 0x3c940]
00004d90 f30f104401fc                     movss xmm0, dword ptr [rcx + rax - 4]
00004d96 f30f5e0401                       divss xmm0, dword ptr [rcx + rax]
00004d9b 488b4638                         mov rax, qword ptr [rsi + 0x38]
00004d9f f30f114401fc                     movss dword ptr [rcx + rax - 4], xmm0
00004da5 eb1e                             jmp 0x4dc5
00004da7 488b4638                         mov rax, qword ptr [rsi + 0x38]
00004dab 4533ff                           xor r15d, r15d
00004dae 44897c01f4                       mov dword ptr [rcx + rax - 0xc], r15d
00004db3 488b4638                         mov rax, qword ptr [rsi + 0x38]
00004db7 44897c01f8                       mov dword ptr [rcx + rax - 8], r15d
00004dbc 488b4638                         mov rax, qword ptr [rsi + 0x38]
00004dc0 44897c01fc                       mov dword ptr [rcx + rax - 4], r15d
00004dc5 488b4638                         mov rax, qword ptr [rsi + 0x38]
00004dc9 f30f111401                       movss dword ptr [rcx + rax], xmm2
00004dce 4883c204                         add rdx, 4
00004dd2 4883c110                         add rcx, 0x10
00004dd6 4983e801                         sub r8, 1
00004dda 0f8560ffffff                     jne 0x4d40
00004de0 4d03cc                           add r9, r12
00004de3 4c03d3                           add r10, rbx
00004de6 4983eb01                         sub r11, 1
00004dea 0f8533ffffff                     jne 0x4d23
00004df0 4533ff                           xor r15d, r15d
00004df3 4d8b4608                         mov r8, qword ptr [r14 + 8]
00004df7 45397828                         cmp dword ptr [r8 + 0x28], r15d
00004dfb 0f8ee8000000                     jle 0x4ee9
00004e01 0f1f4000                         nop dword ptr [rax]
00004e05 6666660f1f840000000000           nop word ptr [rax + rax]
00004e10 418b5024                         mov edx, dword ptr [r8 + 0x24]
00004e14 418bc7                           mov eax, r15d
00004e17 0fafc2                           imul eax, edx
00004e1a c1e002                           shl eax, 2
00004e1d 4863c8                           movsxd rcx, eax
00004e20 498b86a0000000                   mov rax, qword ptr [r14 + 0xa0]
00004e27 488d3c88                         lea rdi, [rax + rcx*4]
00004e2b 33db                             xor ebx, ebx
00004e2d 85d2                             test edx, edx
00004e2f 0f8ea7000000                     jle 0x4edc
00004e35 66450f6ec7                       movd xmm8, r15d
00004e3a 450f5bc0                         cvtdq2ps xmm8, xmm8
00004e3e 66410f6ef5                       movd xmm6, r13d
00004e43 0f5bf6                           cvtdq2ps xmm6, xmm6
00004e46 66660f1f840000000000             nop word ptr [rax + rax]
00004e50 660f6ecb                         movd xmm1, ebx
00004e54 0f5bc9                           cvtdq2ps xmm1, xmm1
00004e57 488d8580000000                   lea rax, [rbp + 0x80]
00004e5e 4889442420                       mov qword ptr [rsp + 0x20], rax
00004e63 4c8d8d88000000                   lea r9, [rbp + 0x88]
00004e6a 410f28d0                         movaps xmm2, xmm8
00004e6e 488bce                           mov rcx, rsi
00004e71 e89accffff                       call 0x1b10
00004e76 f30f108d80000000                 movss xmm1, dword ptr [rbp + 0x80]
00004e7e f30f594e08                       mulss xmm1, dword ptr [rsi + 8]
00004e83 0f2fce                           comiss xmm1, xmm6
00004e86 7204                             jb 0x4e8c
00004e88 f30f5cce                         subss xmm1, xmm6
00004e8c 660f6e460c                       movd xmm0, dword ptr [rsi + 0xc]
00004e91 0f5bc0                           cvtdq2ps xmm0, xmm0
00004e94 f30f109588000000                 movss xmm2, dword ptr [rbp + 0x88]
00004e9c f30f5cd0                         subss xmm2, xmm0
00004ea0 0f2fd7                           comiss xmm2, xmm7
00004ea3 7227                             jb 0x4ecc
00004ea5 468d0cad00000000                 lea r9d, [r13*4]
00004ead f30f11542428                     movss dword ptr [rsp + 0x28], xmm2
00004eb3 f30f114c2420                     movss dword ptr [rsp + 0x20], xmm1
00004eb9 458bc5                           mov r8d, r13d
00004ebc 488bd7                           mov rdx, rdi
00004ebf 488b4e38                         mov rcx, qword ptr [rsi + 0x38]
00004ec3 e838c1ffff                       call 0x1000
00004ec8 4883c710                         add rdi, 0x10
00004ecc ffc3                             inc ebx
00004ece 4d8b4608                         mov r8, qword ptr [r14 + 8]
00004ed2 413b5824                         cmp ebx, dword ptr [r8 + 0x24]
00004ed6 0f8c74ffffff                     jl 0x4e50
00004edc 41ffc7                           inc r15d
00004edf 453b7828                         cmp r15d, dword ptr [r8 + 0x28]
00004ee3 0f8c27ffffff                     jl 0x4e10
00004ee9 498b06                           mov rax, qword ptr [r14]
00004eec 488d3585c60100                   lea rsi, [rip + 0x1c685]
00004ef3 4889742470                       mov qword ptr [rsp + 0x70], rsi
00004ef8 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00004f00 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00004f07 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00004f0c 488b03                           mov rax, qword ptr [rbx]
00004f0f 4c8d8588000000                   lea r8, [rbp + 0x88]
00004f16 ba02000000                       mov edx, 2
00004f1b 488bce                           mov rcx, rsi
00004f1e ffd0                             call rax
00004f20 85c0                             test eax, eax
00004f22 0f8500060000                     jne 0x5528
00004f28 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
00004f2f 4889442460                       mov qword ptr [rsp + 0x60], rax
00004f34 488b4010                         mov rax, qword ptr [rax + 0x10]
00004f38 488b7db8                         mov rdi, qword ptr [rbp - 0x48]
00004f3c 488bcf                           mov rcx, rdi
00004f3f ffd0                             call rax
00004f41 90                               nop 
00004f42 488b4308                         mov rax, qword ptr [rbx + 8]
00004f46 ba02000000                       mov edx, 2
00004f4b 488bce                           mov rcx, rsi
00004f4e ffd0                             call rax
00004f50 90                               nop 
00004f51 498b06                           mov rax, qword ptr [r14]
00004f54 4c8d3d2dc60100                   lea r15, [rip + 0x1c62d]
00004f5b 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00004f60 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00004f68 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00004f6f 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00004f74 488b03                           mov rax, qword ptr [rbx]
00004f77 4c8d8588000000                   lea r8, [rbp + 0x88]
00004f7e ba02000000                       mov edx, 2
00004f83 498bcf                           mov rcx, r15
00004f86 ffd0                             call rax
00004f88 85c0                             test eax, eax
00004f8a 0f85b6050000                     jne 0x5546
00004f90 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
00004f97 4889442460                       mov qword ptr [rsp + 0x60], rax
00004f9c 488b4018                         mov rax, qword ptr [rax + 0x18]
00004fa0 488bcf                           mov rcx, rdi
00004fa3 ffd0                             call rax
00004fa5 90                               nop 
00004fa6 488b4308                         mov rax, qword ptr [rbx + 8]
00004faa ba02000000                       mov edx, 2
00004faf 498bcf                           mov rcx, r15
00004fb2 ffd0                             call rax
00004fb4 90                               nop 
00004fb5 498b06                           mov rax, qword ptr [r14]
00004fb8 4889742470                       mov qword ptr [rsp + 0x70], rsi
00004fbd c744247802000000                 mov dword ptr [rsp + 0x78], 2
00004fc5 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00004fcc 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00004fd1 488b03                           mov rax, qword ptr [rbx]
00004fd4 4c8d8588000000                   lea r8, [rbp + 0x88]
00004fdb ba02000000                       mov edx, 2
00004fe0 488bce                           mov rcx, rsi
00004fe3 ffd0                             call rax
00004fe5 85c0                             test eax, eax
00004fe7 0f8577050000                     jne 0x5564
00004fed 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
00004ff4 4889442460                       mov qword ptr [rsp + 0x60], rax
00004ff9 488b4010                         mov rax, qword ptr [rax + 0x10]
00004ffd 488b7dc0                         mov rdi, qword ptr [rbp - 0x40]
00005001 488bcf                           mov rcx, rdi
00005004 ffd0                             call rax
00005006 90                               nop 
00005007 488b4308                         mov rax, qword ptr [rbx + 8]
0000500b ba02000000                       mov edx, 2
00005010 488bce                           mov rcx, rsi
00005013 ffd0                             call rax
00005015 90                               nop 
00005016 498b06                           mov rax, qword ptr [r14]
00005019 4c897c2470                       mov qword ptr [rsp + 0x70], r15
0000501e c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005026 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
0000502d 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00005032 488b03                           mov rax, qword ptr [rbx]
00005035 4c8d8588000000                   lea r8, [rbp + 0x88]
0000503c ba02000000                       mov edx, 2
00005041 498bcf                           mov rcx, r15
00005044 ffd0                             call rax
00005046 85c0                             test eax, eax
00005048 0f8534050000                     jne 0x5582
0000504e 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
00005055 4889442460                       mov qword ptr [rsp + 0x60], rax
0000505a 488b4018                         mov rax, qword ptr [rax + 0x18]
0000505e 488bcf                           mov rcx, rdi
00005061 ffd0                             call rax
00005063 90                               nop 
00005064 488b4308                         mov rax, qword ptr [rbx + 8]
00005068 ba02000000                       mov edx, 2
0000506d 498bcf                           mov rcx, r15
00005070 ffd0                             call rax
00005072 90                               nop 
00005073 498b06                           mov rax, qword ptr [r14]
00005076 4889742470                       mov qword ptr [rsp + 0x70], rsi
0000507b c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005083 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
0000508a 48895c2468                       mov qword ptr [rsp + 0x68], rbx
0000508f 488b03                           mov rax, qword ptr [rbx]
00005092 4c8d8588000000                   lea r8, [rbp + 0x88]
00005099 ba02000000                       mov edx, 2
0000509e 488bce                           mov rcx, rsi
000050a1 ffd0                             call rax
000050a3 85c0                             test eax, eax
000050a5 0f85f5040000                     jne 0x55a0
000050ab 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
000050b2 4889442460                       mov qword ptr [rsp + 0x60], rax
000050b7 488b4010                         mov rax, qword ptr [rax + 0x10]
000050bb 488b7dc8                         mov rdi, qword ptr [rbp - 0x38]
000050bf 488bcf                           mov rcx, rdi
000050c2 ffd0                             call rax
000050c4 90                               nop 
000050c5 488b4308                         mov rax, qword ptr [rbx + 8]
000050c9 ba02000000                       mov edx, 2
000050ce 488bce                           mov rcx, rsi
000050d1 ffd0                             call rax
000050d3 90                               nop 
000050d4 498b06                           mov rax, qword ptr [r14]
000050d7 4c897c2470                       mov qword ptr [rsp + 0x70], r15
000050dc c744247802000000                 mov dword ptr [rsp + 0x78], 2
000050e4 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
000050eb 48895c2468                       mov qword ptr [rsp + 0x68], rbx
000050f0 488b03                           mov rax, qword ptr [rbx]
000050f3 4c8d8588000000                   lea r8, [rbp + 0x88]
000050fa ba02000000                       mov edx, 2
000050ff 498bcf                           mov rcx, r15
00005102 ffd0                             call rax
00005104 85c0                             test eax, eax
00005106 0f85b2040000                     jne 0x55be
0000510c 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
00005113 4889442460                       mov qword ptr [rsp + 0x60], rax
00005118 488b4018                         mov rax, qword ptr [rax + 0x18]
0000511c 488bcf                           mov rcx, rdi
0000511f ffd0                             call rax
00005121 90                               nop 
00005122 488b4308                         mov rax, qword ptr [rbx + 8]
00005126 ba02000000                       mov edx, 2
0000512b 498bcf                           mov rcx, r15
0000512e ffd0                             call rax
00005130 90                               nop 
00005131 498b06                           mov rax, qword ptr [r14]
00005134 4889742470                       mov qword ptr [rsp + 0x70], rsi
00005139 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005141 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005148 48895c2468                       mov qword ptr [rsp + 0x68], rbx
0000514d 488b03                           mov rax, qword ptr [rbx]
00005150 4c8d8588000000                   lea r8, [rbp + 0x88]
00005157 ba02000000                       mov edx, 2
0000515c 488bce                           mov rcx, rsi
0000515f ffd0                             call rax
00005161 85c0                             test eax, eax
00005163 0f8573040000                     jne 0x55dc
00005169 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
00005170 4889442460                       mov qword ptr [rsp + 0x60], rax
00005175 488b4010                         mov rax, qword ptr [rax + 0x10]
00005179 488b7dd0                         mov rdi, qword ptr [rbp - 0x30]
0000517d 488bcf                           mov rcx, rdi
00005180 ffd0                             call rax
00005182 90                               nop 
00005183 488b4308                         mov rax, qword ptr [rbx + 8]
00005187 ba02000000                       mov edx, 2
0000518c 488bce                           mov rcx, rsi
0000518f ffd0                             call rax
00005191 90                               nop 
00005192 498b06                           mov rax, qword ptr [r14]
00005195 4c897c2470                       mov qword ptr [rsp + 0x70], r15
0000519a c744247802000000                 mov dword ptr [rsp + 0x78], 2
000051a2 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
000051a9 48895c2468                       mov qword ptr [rsp + 0x68], rbx
000051ae 488b03                           mov rax, qword ptr [rbx]
000051b1 4c8d8588000000                   lea r8, [rbp + 0x88]
000051b8 ba02000000                       mov edx, 2
000051bd 498bcf                           mov rcx, r15
000051c0 ffd0                             call rax
000051c2 85c0                             test eax, eax
000051c4 0f8530040000                     jne 0x55fa
000051ca 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
000051d1 4889442460                       mov qword ptr [rsp + 0x60], rax
000051d6 488b4018                         mov rax, qword ptr [rax + 0x18]
000051da 488bcf                           mov rcx, rdi
000051dd ffd0                             call rax
000051df 90                               nop 
000051e0 488b4308                         mov rax, qword ptr [rbx + 8]
000051e4 ba02000000                       mov edx, 2
000051e9 498bcf                           mov rcx, r15
000051ec ffd0                             call rax
000051ee 90                               nop 
000051ef 498b06                           mov rax, qword ptr [r14]
000051f2 4889742470                       mov qword ptr [rsp + 0x70], rsi
000051f7 c744247802000000                 mov dword ptr [rsp + 0x78], 2
000051ff 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005206 48895c2468                       mov qword ptr [rsp + 0x68], rbx
0000520b 488b03                           mov rax, qword ptr [rbx]
0000520e 4c8d8588000000                   lea r8, [rbp + 0x88]
00005215 ba02000000                       mov edx, 2
0000521a 488bce                           mov rcx, rsi
0000521d ffd0                             call rax
0000521f 85c0                             test eax, eax
00005221 0f85f1030000                     jne 0x5618
00005227 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
0000522e 4889442460                       mov qword ptr [rsp + 0x60], rax
00005233 488b4010                         mov rax, qword ptr [rax + 0x10]
00005237 488b7dd8                         mov rdi, qword ptr [rbp - 0x28]
0000523b 488bcf                           mov rcx, rdi
0000523e ffd0                             call rax
00005240 90                               nop 
00005241 488b4308                         mov rax, qword ptr [rbx + 8]
00005245 ba02000000                       mov edx, 2
0000524a 488bce                           mov rcx, rsi
0000524d ffd0                             call rax
0000524f 90                               nop 
00005250 498b06                           mov rax, qword ptr [r14]
00005253 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00005258 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005260 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005267 48895c2468                       mov qword ptr [rsp + 0x68], rbx
0000526c 488b03                           mov rax, qword ptr [rbx]
0000526f 4c8d8588000000                   lea r8, [rbp + 0x88]
00005276 ba02000000                       mov edx, 2
0000527b 498bcf                           mov rcx, r15
0000527e ffd0                             call rax
00005280 85c0                             test eax, eax
00005282 0f85ae030000                     jne 0x5636
00005288 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
0000528f 4889442460                       mov qword ptr [rsp + 0x60], rax
00005294 488b4018                         mov rax, qword ptr [rax + 0x18]
00005298 488bcf                           mov rcx, rdi
0000529b ffd0                             call rax
0000529d 90                               nop 
0000529e 488b4308                         mov rax, qword ptr [rbx + 8]
000052a2 ba02000000                       mov edx, 2
000052a7 498bcf                           mov rcx, r15
000052aa ffd0                             call rax
000052ac 90                               nop 
000052ad 498b06                           mov rax, qword ptr [r14]
000052b0 4889742470                       mov qword ptr [rsp + 0x70], rsi
000052b5 c744247802000000                 mov dword ptr [rsp + 0x78], 2
000052bd 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
000052c4 48895c2468                       mov qword ptr [rsp + 0x68], rbx
000052c9 488b03                           mov rax, qword ptr [rbx]
000052cc 4c8d8588000000                   lea r8, [rbp + 0x88]
000052d3 ba02000000                       mov edx, 2
000052d8 488bce                           mov rcx, rsi
000052db ffd0                             call rax
000052dd 85c0                             test eax, eax
000052df 0f856f030000                     jne 0x5654
000052e5 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
000052ec 4889442460                       mov qword ptr [rsp + 0x60], rax
000052f1 488b4010                         mov rax, qword ptr [rax + 0x10]
000052f5 488b7de0                         mov rdi, qword ptr [rbp - 0x20]
000052f9 488bcf                           mov rcx, rdi
000052fc ffd0                             call rax
000052fe 90                               nop 
000052ff 488b4308                         mov rax, qword ptr [rbx + 8]
00005303 ba02000000                       mov edx, 2
00005308 488bce                           mov rcx, rsi
0000530b ffd0                             call rax
0000530d 90                               nop 
0000530e 498b06                           mov rax, qword ptr [r14]
00005311 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00005316 c744247802000000                 mov dword ptr [rsp + 0x78], 2
0000531e 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005325 48895c2468                       mov qword ptr [rsp + 0x68], rbx
0000532a 488b03                           mov rax, qword ptr [rbx]
0000532d 4c8d8588000000                   lea r8, [rbp + 0x88]
00005334 ba02000000                       mov edx, 2
00005339 498bcf                           mov rcx, r15
0000533c ffd0                             call rax
0000533e 85c0                             test eax, eax
00005340 0f852c030000                     jne 0x5672
00005346 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
0000534d 4889442460                       mov qword ptr [rsp + 0x60], rax
00005352 488b4018                         mov rax, qword ptr [rax + 0x18]
00005356 488bcf                           mov rcx, rdi
00005359 ffd0                             call rax
0000535b 90                               nop 
0000535c 488b4308                         mov rax, qword ptr [rbx + 8]
00005360 ba02000000                       mov edx, 2
00005365 498bcf                           mov rcx, r15
00005368 ffd0                             call rax
0000536a 90                               nop 
0000536b 498b06                           mov rax, qword ptr [r14]
0000536e 4889742470                       mov qword ptr [rsp + 0x70], rsi
00005373 c744247802000000                 mov dword ptr [rsp + 0x78], 2
0000537b 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005382 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00005387 488b03                           mov rax, qword ptr [rbx]
0000538a 4c8d8588000000                   lea r8, [rbp + 0x88]
00005391 ba02000000                       mov edx, 2
00005396 488bce                           mov rcx, rsi
00005399 ffd0                             call rax
0000539b 85c0                             test eax, eax
0000539d 0f85ed020000                     jne 0x5690
000053a3 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
000053aa 4889442460                       mov qword ptr [rsp + 0x60], rax
000053af 488b4010                         mov rax, qword ptr [rax + 0x10]
000053b3 488b7de8                         mov rdi, qword ptr [rbp - 0x18]
000053b7 488bcf                           mov rcx, rdi
000053ba ffd0                             call rax
000053bc 90                               nop 
000053bd 488b4308                         mov rax, qword ptr [rbx + 8]
000053c1 ba02000000                       mov edx, 2
000053c6 488bce                           mov rcx, rsi
000053c9 ffd0                             call rax
000053cb 90                               nop 
000053cc 498b06                           mov rax, qword ptr [r14]
000053cf 4c897c2470                       mov qword ptr [rsp + 0x70], r15
000053d4 c744247802000000                 mov dword ptr [rsp + 0x78], 2
000053dc 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
000053e3 48895c2468                       mov qword ptr [rsp + 0x68], rbx
000053e8 488b03                           mov rax, qword ptr [rbx]
000053eb 4c8d8588000000                   lea r8, [rbp + 0x88]
000053f2 ba02000000                       mov edx, 2
000053f7 498bcf                           mov rcx, r15
000053fa ffd0                             call rax
000053fc 85c0                             test eax, eax
000053fe 0f85aa020000                     jne 0x56ae
00005404 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
0000540b 4889442460                       mov qword ptr [rsp + 0x60], rax
00005410 488b4018                         mov rax, qword ptr [rax + 0x18]
00005414 488bcf                           mov rcx, rdi
00005417 ffd0                             call rax
00005419 90                               nop 
0000541a 488b4308                         mov rax, qword ptr [rbx + 8]
0000541e ba02000000                       mov edx, 2
00005423 498bcf                           mov rcx, r15
00005426 ffd0                             call rax
00005428 90                               nop 
00005429 498b06                           mov rax, qword ptr [r14]
0000542c 4889742470                       mov qword ptr [rsp + 0x70], rsi
00005431 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005439 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005440 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00005445 488b03                           mov rax, qword ptr [rbx]
00005448 4c8d8588000000                   lea r8, [rbp + 0x88]
0000544f ba02000000                       mov edx, 2
00005454 488bce                           mov rcx, rsi
00005457 ffd0                             call rax
00005459 85c0                             test eax, eax
0000545b 0f856b020000                     jne 0x56cc
00005461 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
00005468 4889442460                       mov qword ptr [rsp + 0x60], rax
0000546d 488b4010                         mov rax, qword ptr [rax + 0x10]
00005471 488b7df0                         mov rdi, qword ptr [rbp - 0x10]
00005475 488bcf                           mov rcx, rdi
00005478 ffd0                             call rax
0000547a 90                               nop 
0000547b 488b4308                         mov rax, qword ptr [rbx + 8]
0000547f ba02000000                       mov edx, 2
00005484 488bce                           mov rcx, rsi
00005487 ffd0                             call rax
00005489 90                               nop 
0000548a 498b06                           mov rax, qword ptr [r14]
0000548d 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00005492 c744247802000000                 mov dword ptr [rsp + 0x78], 2
0000549a 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
000054a1 48895c2468                       mov qword ptr [rsp + 0x68], rbx
000054a6 488b03                           mov rax, qword ptr [rbx]
000054a9 4c8d8588000000                   lea r8, [rbp + 0x88]
000054b0 ba02000000                       mov edx, 2
000054b5 498bcf                           mov rcx, r15
000054b8 ffd0                             call rax
000054ba 85c0                             test eax, eax
000054bc 754c                             jne 0x550a
000054be 488b8588000000                   mov rax, qword ptr [rbp + 0x88]
000054c5 4889442460                       mov qword ptr [rsp + 0x60], rax
000054ca 488b4018                         mov rax, qword ptr [rax + 0x18]
000054ce 488bcf                           mov rcx, rdi
000054d1 ffd0                             call rax
000054d3 90                               nop 
000054d4 488b4308                         mov rax, qword ptr [rbx + 8]
000054d8 ba02000000                       mov edx, 2
000054dd 498bcf                           mov rcx, r15
000054e0 ffd0                             call rax
000054e2 90                               nop 
000054e3 4c8d9c2438010000                 lea r11, [rsp + 0x138]
000054eb 410f2873e8                       movaps xmm6, xmmword ptr [r11 - 0x18]
000054f0 410f287bd8                       movaps xmm7, xmmword ptr [r11 - 0x28]
000054f5 450f2843c8                       movaps xmm8, xmmword ptr [r11 - 0x38]
000054fa 498be3                           mov rsp, r11
000054fd 415f                             pop r15
000054ff 415e                             pop r14
00005501 415d                             pop r13
00005503 415c                             pop r12
00005505 5f                               pop rdi
00005506 5e                               pop rsi
00005507 5b                               pop rbx
00005508 5d                               pop rbp
00005509 c3                               ret 
0000550a c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
00005514 488d154d4a0200                   lea rdx, [rip + 0x24a4d]
0000551b 488d8d80000000                   lea rcx, [rbp + 0x80]
00005522 e8f39f0100                       call 0x1f51a
00005527 cc                               int3 
00005528 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
00005532 488d152f4a0200                   lea rdx, [rip + 0x24a2f]
00005539 488d8d80000000                   lea rcx, [rbp + 0x80]
00005540 e8d59f0100                       call 0x1f51a
00005545 cc                               int3 
00005546 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
00005550 488d15114a0200                   lea rdx, [rip + 0x24a11]
00005557 488d8d80000000                   lea rcx, [rbp + 0x80]
0000555e e8b79f0100                       call 0x1f51a
00005563 cc                               int3 
00005564 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
0000556e 488d15f3490200                   lea rdx, [rip + 0x249f3]
00005575 488d8d80000000                   lea rcx, [rbp + 0x80]
0000557c e8999f0100                       call 0x1f51a
00005581 cc                               int3 
00005582 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
0000558c 488d15d5490200                   lea rdx, [rip + 0x249d5]
00005593 488d8d80000000                   lea rcx, [rbp + 0x80]
0000559a e87b9f0100                       call 0x1f51a
0000559f cc                               int3 
000055a0 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
000055aa 488d15b7490200                   lea rdx, [rip + 0x249b7]
000055b1 488d8d80000000                   lea rcx, [rbp + 0x80]
000055b8 e85d9f0100                       call 0x1f51a
000055bd cc                               int3 
000055be c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
000055c8 488d1599490200                   lea rdx, [rip + 0x24999]
000055cf 488d8d80000000                   lea rcx, [rbp + 0x80]
000055d6 e83f9f0100                       call 0x1f51a
000055db cc                               int3 
000055dc c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
000055e6 488d157b490200                   lea rdx, [rip + 0x2497b]
000055ed 488d8d80000000                   lea rcx, [rbp + 0x80]
000055f4 e8219f0100                       call 0x1f51a
000055f9 cc                               int3 
000055fa c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
00005604 488d155d490200                   lea rdx, [rip + 0x2495d]
0000560b 488d8d80000000                   lea rcx, [rbp + 0x80]
00005612 e8039f0100                       call 0x1f51a
00005617 cc                               int3 
00005618 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
00005622 488d153f490200                   lea rdx, [rip + 0x2493f]
00005629 488d8d80000000                   lea rcx, [rbp + 0x80]
00005630 e8e59e0100                       call 0x1f51a
00005635 cc                               int3 
00005636 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
00005640 488d1521490200                   lea rdx, [rip + 0x24921]
00005647 488d8d80000000                   lea rcx, [rbp + 0x80]
0000564e e8c79e0100                       call 0x1f51a
00005653 cc                               int3 
00005654 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
0000565e 488d1503490200                   lea rdx, [rip + 0x24903]
00005665 488d8d80000000                   lea rcx, [rbp + 0x80]
0000566c e8a99e0100                       call 0x1f51a
00005671 cc                               int3 
00005672 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
0000567c 488d15e5480200                   lea rdx, [rip + 0x248e5]
00005683 488d8d80000000                   lea rcx, [rbp + 0x80]
0000568a e88b9e0100                       call 0x1f51a
0000568f cc                               int3 
00005690 c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
0000569a 488d15c7480200                   lea rdx, [rip + 0x248c7]
000056a1 488d8d80000000                   lea rcx, [rbp + 0x80]
000056a8 e86d9e0100                       call 0x1f51a
000056ad cc                               int3 
000056ae c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
000056b8 488d15a9480200                   lea rdx, [rip + 0x248a9]
000056bf 488d8d80000000                   lea rcx, [rbp + 0x80]
000056c6 e84f9e0100                       call 0x1f51a
000056cb cc                               int3 
000056cc c785800000000d000000             mov dword ptr [rbp + 0x80], 0xd
000056d6 488d158b480200                   lea rdx, [rip + 0x2488b]
000056dd 488d8d80000000                   lea rcx, [rbp + 0x80]
000056e4 e8319e0100                       call 0x1f51a
000056e9 cc                               int3 
000056ea cc                               int3 
000056eb cc                               int3 
000056ec cc                               int3 
000056ed cc                               int3 
000056ee cc                               int3 
000056ef cc                               int3 
000056f0 488bc4                           mov rax, rsp
000056f3 55                               push rbp
000056f4 53                               push rbx
000056f5 56                               push rsi
000056f6 57                               push rdi
000056f7 4154                             push r12
000056f9 4155                             push r13
000056fb 4156                             push r14
000056fd 4157                             push r15
000056ff 488d6898                         lea rbp, [rax - 0x68]
00005703 4881ec28010000                   sub rsp, 0x128
0000570a 0f2970a8                         movaps xmmword ptr [rax - 0x58], xmm6
0000570e 0f297898                         movaps xmmword ptr [rax - 0x68], xmm7
00005712 440f294088                       movaps xmmword ptr [rax - 0x78], xmm8
00005717 440f298878ffffff                 movaps xmmword ptr [rax - 0x88], xmm9
0000571f 4c8bf2                           mov r14, rdx
00005722 488bf1                           mov rsi, rcx
00005725 ff15c5b90100                     call qword ptr [rip + 0x1b9c5]
0000572b b920000000                       mov ecx, 0x20
00005730 3bc1                             cmp eax, ecx
00005732 0f4fc1                           cmovg eax, ecx
00005735 898620420000                     mov dword ptr [rsi + 0x4220], eax
0000573b 418b4678                         mov eax, dword ptr [r14 + 0x78]
0000573f 894620                           mov dword ptr [rsi + 0x20], eax
00005742 66410f6e467c                     movd xmm0, dword ptr [r14 + 0x7c]
00005748 0f5bc0                           cvtdq2ps xmm0, xmm0
0000574b f30f114624                       movss dword ptr [rsi + 0x24], xmm0
00005750 66410f6e467c                     movd xmm0, dword ptr [r14 + 0x7c]
00005756 f30fe6c0                         cvtdq2pd xmm0, xmm0
0000575a e8099e0100                       call 0x1f568
0000575f f20f5ac0                         cvtsd2ss xmm0, xmm0
00005763 f30f114628                       movss dword ptr [rsi + 0x28], xmm0
00005768 66410f6e467c                     movd xmm0, dword ptr [r14 + 0x7c]
0000576e f30fe6c0                         cvtdq2pd xmm0, xmm0
00005772 e8f79d0100                       call 0x1f56e
00005777 f20f5ac0                         cvtsd2ss xmm0, xmm0
0000577b f30f11462c                       movss dword ptr [rsi + 0x2c], xmm0
00005780 f2410f104e28                     movsd xmm1, qword ptr [r14 + 0x28]
00005786 660f5ac9                         cvtpd2ps xmm1, xmm1
0000578a f30f118e08420000                 movss dword ptr [rsi + 0x4208], xmm1
00005792 f2410f104630                     movsd xmm0, qword ptr [r14 + 0x30]
00005798 660f5ac0                         cvtpd2ps xmm0, xmm0
0000579c f30f11860c420000                 movss dword ptr [rsi + 0x420c], xmm0
000057a4 66410f6e4e64                     movd xmm1, dword ptr [r14 + 0x64]
000057aa 0f5bc9                           cvtdq2ps xmm1, xmm1
000057ad f3410f594e48                     mulss xmm1, dword ptr [r14 + 0x48]
000057b3 f30f2cd1                         cvttss2si edx, xmm1
000057b7 8996d83e0000                     mov dword ptr [rsi + 0x3ed8], edx
000057bd 488d4e58                         lea rcx, [rsi + 0x58]
000057c1 e8ba5e0000                       call 0xb680
000057c6 66410f6e4668                     movd xmm0, dword ptr [r14 + 0x68]
000057cc 0f5bc0                           cvtdq2ps xmm0, xmm0
000057cf f3410f594648                     mulss xmm0, dword ptr [r14 + 0x48]
000057d5 f30f2cd0                         cvttss2si edx, xmm0
000057d9 8996dc3e0000                     mov dword ptr [rsi + 0x3edc], edx
000057df 488d8e981f0000                   lea rcx, [rsi + 0x1f98]
000057e6 e8955e0000                       call 0xb680
000057eb 66410f6e466c                     movd xmm0, dword ptr [r14 + 0x6c]
000057f1 0f5bc0                           cvtdq2ps xmm0, xmm0
000057f4 f3410f594648                     mulss xmm0, dword ptr [r14 + 0x48]
000057fa f30f2cd0                         cvttss2si edx, xmm0
000057fe 899600420000                     mov dword ptr [rsi + 0x4200], edx
00005804 488d8ee03e0000                   lea rcx, [rsi + 0x3ee0]
0000580b e8705e0000                       call 0xb680
00005810 66410f6e4670                     movd xmm0, dword ptr [r14 + 0x70]
00005816 0f5bc0                           cvtdq2ps xmm0, xmm0
00005819 f3410f594648                     mulss xmm0, dword ptr [r14 + 0x48]
0000581f f30f2cd0                         cvttss2si edx, xmm0
00005823 899604420000                     mov dword ptr [rsi + 0x4204], edx
00005829 488d8e70400000                   lea rcx, [rsi + 0x4070]
00005830 e84b5e0000                       call 0xb680
00005835 488d5e1c                         lea rbx, [rsi + 0x1c]
00005839 488d7e18                         lea rdi, [rsi + 0x18]
0000583d 498b4608                         mov rax, qword ptr [r14 + 8]
00005841 48895c2420                       mov qword ptr [rsp + 0x20], rbx
00005846 4c8bcf                           mov r9, rdi
00005849 448b4028                         mov r8d, dword ptr [rax + 0x28]
0000584d 8b5024                           mov edx, dword ptr [rax + 0x24]
00005850 488bce                           mov rcx, rsi
00005853 e898500000                       call 0xa8f0
00005858 660f6e07                         movd xmm0, dword ptr [rdi]
0000585c 0f5bc0                           cvtdq2ps xmm0, xmm0
0000585f f30f5e4620                       divss xmm0, dword ptr [rsi + 0x20]
00005864 f30f2cc8                         cvttss2si ecx, xmm0
00005868 83c1fe                           add ecx, -2
0000586b 890f                             mov dword ptr [rdi], ecx
0000586d c7457000000000                   mov dword ptr [rbp + 0x70], 0
00005874 488d4570                         lea rax, [rbp + 0x70]
00005878 480f49c7                         cmovns rax, rdi
0000587c 8b08                             mov ecx, dword ptr [rax]
0000587e 890f                             mov dword ptr [rdi], ecx
00005880 830302                           add dword ptr [rbx], 2
00005883 448b3b                           mov r15d, dword ptr [rbx]
00005886 f30f100596bd0100                 movss xmm0, dword ptr [rip + 0x1bd96]
0000588e f30f5e4610                       divss xmm0, dword ptr [rsi + 0x10]
00005893 f3440f2ce0                       cvttss2si r12d, xmm0
00005898 44896578                         mov dword ptr [rbp + 0x78], r12d
0000589c 442bf9                           sub r15d, ecx
0000589f 41ffc7                           inc r15d
000058a2 418bff                           mov edi, r15d
000058a5 410faffc                         imul edi, r12d
000058a9 8d1cbd00000000                   lea ebx, [rdi*4]
000058b0 8bd3                             mov edx, ebx
000058b2 498b0e                           mov rcx, qword ptr [r14]
000058b5 e8e6ecffff                       call 0x45a0
000058ba 488945a8                         mov qword ptr [rbp - 0x58], rax
000058be 488bd0                           mov rdx, rax
000058c1 498b0e                           mov rcx, qword ptr [r14]
000058c4 e8f7eaffff                       call 0x43c0
000058c9 48898610420000                   mov qword ptr [rsi + 0x4210], rax
000058d0 8bd7                             mov edx, edi
000058d2 498b0e                           mov rcx, qword ptr [r14]
000058d5 e8c6ecffff                       call 0x45a0
000058da 488945b0                         mov qword ptr [rbp - 0x50], rax
000058de 488bd0                           mov rdx, rax
000058e1 498b0e                           mov rcx, qword ptr [r14]
000058e4 e8d7eaffff                       call 0x43c0
000058e9 48898618420000                   mov qword ptr [rsi + 0x4218], rax
000058f0 8bd3                             mov edx, ebx
000058f2 498b0e                           mov rcx, qword ptr [r14]
000058f5 e8a6ecffff                       call 0x45a0
000058fa 488945b8                         mov qword ptr [rbp - 0x48], rax
000058fe 488bd0                           mov rdx, rax
00005901 498b0e                           mov rcx, qword ptr [r14]
00005904 e8b7eaffff                       call 0x43c0
00005909 48894638                         mov qword ptr [rsi + 0x38], rax
0000590d 8bd7                             mov edx, edi
0000590f 498b0e                           mov rcx, qword ptr [r14]
00005912 e889ecffff                       call 0x45a0
00005917 488945c0                         mov qword ptr [rbp - 0x40], rax
0000591b 488bd0                           mov rdx, rax
0000591e 498b0e                           mov rcx, qword ptr [r14]
00005921 e89aeaffff                       call 0x43c0
00005926 48894640                         mov qword ptr [rsi + 0x40], rax
0000592a 8bd7                             mov edx, edi
0000592c 498b0e                           mov rcx, qword ptr [r14]
0000592f e86cecffff                       call 0x45a0
00005934 488945c8                         mov qword ptr [rbp - 0x38], rax
00005938 488bd0                           mov rdx, rax
0000593b 498b0e                           mov rcx, qword ptr [r14]
0000593e e87deaffff                       call 0x43c0
00005943 48894648                         mov qword ptr [rsi + 0x48], rax
00005947 8bd7                             mov edx, edi
00005949 498b0e                           mov rcx, qword ptr [r14]
0000594c e84fecffff                       call 0x45a0
00005951 488945d0                         mov qword ptr [rbp - 0x30], rax
00005955 488bd0                           mov rdx, rax
00005958 498b0e                           mov rcx, qword ptr [r14]
0000595b e860eaffff                       call 0x43c0
00005960 48894650                         mov qword ptr [rsi + 0x50], rax
00005964 8bd7                             mov edx, edi
00005966 498b0e                           mov rcx, qword ptr [r14]
00005969 e8f2eaffff                       call 0x4460
0000596e 488945d8                         mov qword ptr [rbp - 0x28], rax
00005972 488bd0                           mov rdx, rax
00005975 498b0e                           mov rcx, qword ptr [r14]
00005978 e803e9ffff                       call 0x4280
0000597d 488bf8                           mov rdi, rax
00005980 488945a0                         mov qword ptr [rbp - 0x60], rax
00005984 410fb65674                       movzx edx, byte ptr [r14 + 0x74]
00005989 4c8d05104d0000                   lea r8, [rip + 0x4d10]
00005990 488d05b94b0000                   lea rax, [rip + 0x4bb9]
00005997 84d2                             test dl, dl
00005999 4c0f44c0                         cmove r8, rax
0000599d 488d0dcc480000                   lea rcx, [rip + 0x48cc]
000059a4 488d0515460000                   lea rax, [rip + 0x4615]
000059ab 480f44c8                         cmove rcx, rax
000059af 48890e                           mov qword ptr [rsi], rcx
000059b2 4c894608                         mov qword ptr [rsi + 8], r8
000059b6 33c9                             xor ecx, ecx
000059b8 894d70                           mov dword ptr [rbp + 0x70], ecx
000059bb 4585e4                           test r12d, r12d
000059be 0f8ede010000                     jle 0x5ba2
000059c4 4963c7                           movsxd rax, r15d
000059c7 48897d88                         mov qword ptr [rbp - 0x78], rdi
000059cb 33db                             xor ebx, ebx
000059cd 48895d80                         mov qword ptr [rbp - 0x80], rbx
000059d1 488d048500000000                 lea rax, [rax*4]
000059d9 48894598                         mov qword ptr [rbp - 0x68], rax
000059dd 4533ed                           xor r13d, r13d
000059e0 4c89ad88000000                   mov qword ptr [rbp + 0x88], r13
000059e7 428d04bd00000000                 lea eax, [r15*4]
000059ef 4898                             cdqe 
000059f1 48c1e002                         shl rax, 2
000059f5 48894590                         mov qword ptr [rbp - 0x70], rax
000059f9 0f1f8000000000                   nop dword ptr [rax]
00005a00 660f6ec9                         movd xmm1, ecx
00005a04 0f5bc9                           cvtdq2ps xmm1, xmm1
00005a07 f30f594e14                       mulss xmm1, dword ptr [rsi + 0x14]
00005a0c 0f28c1                           movaps xmm0, xmm1
00005a0f e84c760100                       call 0x1d060
00005a14 440f28c0                         movaps xmm8, xmm0
00005a18 440f28c8                         movaps xmm9, xmm0
00005a1c 440fc6c801                       shufps xmm9, xmm0, 1
00005a21 f3440f594620                     mulss xmm8, dword ptr [rsi + 0x20]
00005a27 4c8b6638                         mov r12, qword ptr [rsi + 0x38]
00005a2b 4d03e5                           add r12, r13
00005a2e 4c8b6e40                         mov r13, qword ptr [rsi + 0x40]
00005a32 4c03eb                           add r13, rbx
00005a35 48035e48                         add rbx, qword ptr [rsi + 0x48]
00005a39 4889bd80000000                   mov qword ptr [rbp + 0x80], rdi
00005a40 33ff                             xor edi, edi
00005a42 4585ff                           test r15d, r15d
00005a45 0f8e12010000                     jle 0x5b5d
00005a4b 0f1f440000                       nop dword ptr [rax + rax]
00005a50 8b4e18                           mov ecx, dword ptr [rsi + 0x18]
00005a53 03cf                             add ecx, edi
00005a55 660f6ed9                         movd xmm3, ecx
00005a59 0f5bdb                           cvtdq2ps xmm3, xmm3
00005a5c 0f28d3                           movaps xmm2, xmm3
00005a5f f3410f59d1                       mulss xmm2, xmm9
00005a64 f3410f59d8                       mulss xmm3, xmm8
00005a69 f30f104e28                       movss xmm1, dword ptr [rsi + 0x28]
00005a6e f30f10762c                       movss xmm6, dword ptr [rsi + 0x2c]
00005a73 0f28f9                           movaps xmm7, xmm1
00005a76 f30f59fa                         mulss xmm7, xmm2
00005a7a 0f28c6                           movaps xmm0, xmm6
00005a7d f30f59c3                         mulss xmm0, xmm3
00005a81 f30f5cf8                         subss xmm7, xmm0
00005a85 f30f58be08420000                 addss xmm7, dword ptr [rsi + 0x4208]
00005a8d f30f59f2                         mulss xmm6, xmm2
00005a91 f30f59cb                         mulss xmm1, xmm3
00005a95 f30f58f1                         addss xmm6, xmm1
00005a99 f30f58b60c420000                 addss xmm6, dword ptr [rsi + 0x420c]
00005aa1 4c8b16                           mov r10, qword ptr [rsi]
00005aa4 498b4e08                         mov rcx, qword ptr [r14 + 8]
00005aa8 448b4124                         mov r8d, dword ptr [rcx + 0x24]
00005aac 428d048500000000                 lea eax, [r8*4]
00005ab4 f30f11742430                     movss dword ptr [rsp + 0x30], xmm6
00005aba f30f117c2428                     movss dword ptr [rsp + 0x28], xmm7
00005ac0 89442420                         mov dword ptr [rsp + 0x20], eax
00005ac4 448b4928                         mov r9d, dword ptr [rcx + 0x28]
00005ac8 498bd4                           mov rdx, r12
00005acb 498b8e98000000                   mov rcx, qword ptr [r14 + 0x98]
00005ad2 41ffd2                           call r10
00005ad5 488b8d80000000                   mov rcx, qword ptr [rbp + 0x80]
00005adc 8801                             mov byte ptr [rcx], al
00005ade 4c8b5608                         mov r10, qword ptr [rsi + 8]
00005ae2 498b4608                         mov rax, qword ptr [r14 + 8]
00005ae6 f30f11742428                     movss dword ptr [rsp + 0x28], xmm6
00005aec f30f117c2420                     movss dword ptr [rsp + 0x20], xmm7
00005af2 448b4828                         mov r9d, dword ptr [rax + 0x28]
00005af6 448b4024                         mov r8d, dword ptr [rax + 0x24]
00005afa 498bd5                           mov rdx, r13
00005afd 498b8e90000000                   mov rcx, qword ptr [r14 + 0x90]
00005b04 41ffd2                           call r10
00005b07 41807e4400                       cmp byte ptr [r14 + 0x44], 0
00005b0c 742b                             je 0x5b39
00005b0e 4c8b5608                         mov r10, qword ptr [rsi + 8]
00005b12 498b4608                         mov rax, qword ptr [r14 + 8]
00005b16 f30f11742428                     movss dword ptr [rsp + 0x28], xmm6
00005b1c f30f117c2420                     movss dword ptr [rsp + 0x20], xmm7
00005b22 448b4828                         mov r9d, dword ptr [rax + 0x28]
00005b26 448b4024                         mov r8d, dword ptr [rax + 0x24]
00005b2a 488bd3                           mov rdx, rbx
00005b2d 498b8e88000000                   mov rcx, qword ptr [r14 + 0x88]
00005b34 41ffd2                           call r10
00005b37 eb06                             jmp 0x5b3f
00005b39 c7030000803f                     mov dword ptr [rbx], 0x3f800000
00005b3f ffc7                             inc edi
00005b41 4983c410                         add r12, 0x10
00005b45 4983c504                         add r13, 4
00005b49 4883c304                         add rbx, 4
00005b4d 48ff8580000000                   inc qword ptr [rbp + 0x80]
00005b54 413bff                           cmp edi, r15d
00005b57 0f8cf3feffff                     jl 0x5a50
00005b5d 8b4d70                           mov ecx, dword ptr [rbp + 0x70]
00005b60 ffc1                             inc ecx
00005b62 894d70                           mov dword ptr [rbp + 0x70], ecx
00005b65 4c8bad88000000                   mov r13, qword ptr [rbp + 0x88]
00005b6c 4c036d90                         add r13, qword ptr [rbp - 0x70]
00005b70 4c89ad88000000                   mov qword ptr [rbp + 0x88], r13
00005b77 488b5d80                         mov rbx, qword ptr [rbp - 0x80]
00005b7b 48035d98                         add rbx, qword ptr [rbp - 0x68]
00005b7f 48895d80                         mov qword ptr [rbp - 0x80], rbx
00005b83 488b7d88                         mov rdi, qword ptr [rbp - 0x78]
00005b87 4963c7                           movsxd rax, r15d
00005b8a 4803f8                           add rdi, rax
00005b8d 48897d88                         mov qword ptr [rbp - 0x78], rdi
00005b91 448b6578                         mov r12d, dword ptr [rbp + 0x78]
00005b95 413bcc                           cmp ecx, r12d
00005b98 0f8c62feffff                     jl 0x5a00
00005b9e 488b7da0                         mov rdi, qword ptr [rbp - 0x60]
00005ba2 8b8e20420000                     mov ecx, dword ptr [rsi + 0x4220]
00005ba8 418bc4                           mov eax, r12d
00005bab 99                               cdq 
00005bac f7f9                             idiv ecx
00005bae ffc0                             inc eax
00005bb0 660f6ef0                         movd xmm6, eax
00005bb4 0f5bf6                           cvtdq2ps xmm6, xmm6
00005bb7 33c0                             xor eax, eax
00005bb9 85c9                             test ecx, ecx
00005bbb 7e6e                             jle 0x5c2b
00005bbd 0f1f00                           nop dword ptr [rax]
00005bc0 8d5801                           lea ebx, [rax + 1]
00005bc3 660f6ec3                         movd xmm0, ebx
00005bc7 0f5bc0                           cvtdq2ps xmm0, xmm0
00005bca f30f59c6                         mulss xmm0, xmm6
00005bce f30f2cd0                         cvttss2si edx, xmm0
00005bd2 660f6ec8                         movd xmm1, eax
00005bd6 0f5bc9                           cvtdq2ps xmm1, xmm1
00005bd9 f30f59ce                         mulss xmm1, xmm6
00005bdd f30f2cc9                         cvttss2si ecx, xmm1
00005be1 488b8618420000                   mov rax, qword ptr [rsi + 0x4218]
00005be8 4889442448                       mov qword ptr [rsp + 0x48], rax
00005bed 488b8610420000                   mov rax, qword ptr [rsi + 0x4210]
00005bf4 4889442440                       mov qword ptr [rsp + 0x40], rax
00005bf9 89542438                         mov dword ptr [rsp + 0x38], edx
00005bfd 894c2430                         mov dword ptr [rsp + 0x30], ecx
00005c01 4489642428                       mov dword ptr [rsp + 0x28], r12d
00005c06 44897c2420                       mov dword ptr [rsp + 0x20], r15d
00005c0b 4c8b4e48                         mov r9, qword ptr [rsi + 0x48]
00005c0f 4c8b4650                         mov r8, qword ptr [rsi + 0x50]
00005c13 488b5638                         mov rdx, qword ptr [rsi + 0x38]
00005c17 488bce                           mov rcx, rsi
00005c1a e831550000                       call 0xb150
00005c1f 8bc3                             mov eax, ebx
00005c21 8b8e20420000                     mov ecx, dword ptr [rsi + 0x4220]
00005c27 3bd9                             cmp ebx, ecx
00005c29 7c95                             jl 0x5bc0
00005c2b 33c0                             xor eax, eax
00005c2d 85c9                             test ecx, ecx
00005c2f 7e6e                             jle 0x5c9f
00005c31 8d5801                           lea ebx, [rax + 1]
00005c34 660f6ec3                         movd xmm0, ebx
00005c38 0f5bc0                           cvtdq2ps xmm0, xmm0
00005c3b f30f59c6                         mulss xmm0, xmm6
00005c3f f30f2cd0                         cvttss2si edx, xmm0
00005c43 660f6ec8                         movd xmm1, eax
00005c47 0f5bc9                           cvtdq2ps xmm1, xmm1
00005c4a f30f59ce                         mulss xmm1, xmm6
00005c4e f30f2cc9                         cvttss2si ecx, xmm1
00005c52 488b8618420000                   mov rax, qword ptr [rsi + 0x4218]
00005c59 4889442450                       mov qword ptr [rsp + 0x50], rax
00005c5e 488b8610420000                   mov rax, qword ptr [rsi + 0x4210]
00005c65 4889442448                       mov qword ptr [rsp + 0x48], rax
00005c6a 89542440                         mov dword ptr [rsp + 0x40], edx
00005c6e 894c2438                         mov dword ptr [rsp + 0x38], ecx
00005c72 4489642430                       mov dword ptr [rsp + 0x30], r12d
00005c77 44897c2428                       mov dword ptr [rsp + 0x28], r15d
00005c7c 48897c2420                       mov qword ptr [rsp + 0x20], rdi
00005c81 4c8b4e40                         mov r9, qword ptr [rsi + 0x40]
00005c85 4c8b4650                         mov r8, qword ptr [rsi + 0x50]
00005c89 488b5638                         mov rdx, qword ptr [rsi + 0x38]
00005c8d 488bce                           mov rcx, rsi
00005c90 e83b4d0000                       call 0xa9d0
00005c95 8bc3                             mov eax, ebx
00005c97 3b9e20420000                     cmp ebx, dword ptr [rsi + 0x4220]
00005c9d 7c92                             jl 0x5c31
00005c9f 0f57f6                           xorps xmm6, xmm6
00005ca2 4585e4                           test r12d, r12d
00005ca5 0f8eeb000000                     jle 0x5d96
00005cab 4d63df                           movsxd r11, r15d
00005cae 4533c9                           xor r9d, r9d
00005cb1 498bfb                           mov rdi, r11
00005cb4 48c1e704                         shl rdi, 4
00005cb8 4e8d2c9d00000000                 lea r13, [r11*4]
00005cc0 458d510c                         lea r10d, [r9 + 0xc]
00005cc4 418bdc                           mov ebx, r12d
00005cc7 4585ff                           test r15d, r15d
00005cca 0f8eb6000000                     jle 0x5d86
00005cd0 498bd1                           mov rdx, r9
00005cd3 498bca                           mov rcx, r10
00005cd6 4d8bc3                           mov r8, r11
00005cd9 0f1f8000000000                   nop dword ptr [rax]
00005ce0 488b8618420000                   mov rax, qword ptr [rsi + 0x4218]
00005ce7 f30f101402                       movss xmm2, dword ptr [rdx + rax]
00005cec 0f2ed6                           ucomiss xmm2, xmm6
00005cef 7456                             je 0x5d47
00005cf1 488b8610420000                   mov rax, qword ptr [rsi + 0x4210]
00005cf8 f30f104408f4                     movss xmm0, dword ptr [rax + rcx - 0xc]
00005cfe f30f5e0408                       divss xmm0, dword ptr [rax + rcx]
00005d03 488b4638                         mov rax, qword ptr [rsi + 0x38]
00005d07 f30f114401f4                     movss dword ptr [rcx + rax - 0xc], xmm0
00005d0d 488b8610420000                   mov rax, qword ptr [rsi + 0x4210]
00005d14 f30f104c08f8                     movss xmm1, dword ptr [rax + rcx - 8]
00005d1a f30f5e0c08                       divss xmm1, dword ptr [rax + rcx]
00005d1f 488b4638                         mov rax, qword ptr [rsi + 0x38]
00005d23 f30f114c01f8                     movss dword ptr [rcx + rax - 8], xmm1
00005d29 488b8610420000                   mov rax, qword ptr [rsi + 0x4210]
00005d30 f30f104408fc                     movss xmm0, dword ptr [rax + rcx - 4]
00005d36 f30f5e0408                       divss xmm0, dword ptr [rax + rcx]
00005d3b 488b4638                         mov rax, qword ptr [rsi + 0x38]
00005d3f f30f114401fc                     movss dword ptr [rcx + rax - 4], xmm0
00005d45 eb24                             jmp 0x5d6b
00005d47 488b4638                         mov rax, qword ptr [rsi + 0x38]
00005d4b c74401f400000000                 mov dword ptr [rcx + rax - 0xc], 0
00005d53 488b4638                         mov rax, qword ptr [rsi + 0x38]
00005d57 c74401f800000000                 mov dword ptr [rcx + rax - 8], 0
00005d5f 488b4638                         mov rax, qword ptr [rsi + 0x38]
00005d63 c74401fc00000000                 mov dword ptr [rcx + rax - 4], 0
00005d6b 488b4638                         mov rax, qword ptr [rsi + 0x38]
00005d6f f30f111401                       movss dword ptr [rcx + rax], xmm2
00005d74 4883c204                         add rdx, 4
00005d78 4883c110                         add rcx, 0x10
00005d7c 4983e801                         sub r8, 1
00005d80 0f855affffff                     jne 0x5ce0
00005d86 4d03cd                           add r9, r13
00005d89 4c03d7                           add r10, rdi
00005d8c 4883eb01                         sub rbx, 1
00005d90 0f8531ffffff                     jne 0x5cc7
00005d96 4533ed                           xor r13d, r13d
00005d99 4d8b4608                         mov r8, qword ptr [r14 + 8]
00005d9d 45396828                         cmp dword ptr [r8 + 0x28], r13d
00005da1 0f8ee7000000                     jle 0x5e8e
00005da7 660f1f840000000000               nop word ptr [rax + rax]
00005db0 418b5024                         mov edx, dword ptr [r8 + 0x24]
00005db4 8bc2                             mov eax, edx
00005db6 410fafc5                         imul eax, r13d
00005dba c1e002                           shl eax, 2
00005dbd 4863c8                           movsxd rcx, eax
00005dc0 498b86a0000000                   mov rax, qword ptr [r14 + 0xa0]
00005dc7 488d3c88                         lea rdi, [rax + rcx*4]
00005dcb 33db                             xor ebx, ebx
00005dcd 85d2                             test edx, edx
00005dcf 0f8eac000000                     jle 0x5e81
00005dd5 66450f6ec5                       movd xmm8, r13d
00005dda 450f5bc0                         cvtdq2ps xmm8, xmm8
00005dde 66410f6efc                       movd xmm7, r12d
00005de3 0f5bff                           cvtdq2ps xmm7, xmm7
00005de6 66660f1f840000000000             nop word ptr [rax + rax]
00005df0 660f6ecb                         movd xmm1, ebx
00005df4 0f5bc9                           cvtdq2ps xmm1, xmm1
00005df7 488d4570                         lea rax, [rbp + 0x70]
00005dfb 4889442420                       mov qword ptr [rsp + 0x20], rax
00005e00 4c8d4d78                         lea r9, [rbp + 0x78]
00005e04 410f28d0                         movaps xmm2, xmm8
00005e08 488bce                           mov rcx, rsi
00005e0b e8404a0000                       call 0xa850
00005e10 f30f104d70                       movss xmm1, dword ptr [rbp + 0x70]
00005e15 0f2fce                           comiss xmm1, xmm6
00005e18 7305                             jae 0x5e1f
00005e1a 0f28ce                           movaps xmm1, xmm6
00005e1d eb05                             jmp 0x5e24
00005e1f f30f5e4e14                       divss xmm1, dword ptr [rsi + 0x14]
00005e24 0f2fcf                           comiss xmm1, xmm7
00005e27 7204                             jb 0x5e2d
00005e29 f30f5ccf                         subss xmm1, xmm7
00005e2d 660f6e4618                       movd xmm0, dword ptr [rsi + 0x18]
00005e32 0f5bc0                           cvtdq2ps xmm0, xmm0
00005e35 f30f105578                       movss xmm2, dword ptr [rbp + 0x78]
00005e3a f30f5cd0                         subss xmm2, xmm0
00005e3e 0f2fd6                           comiss xmm2, xmm6
00005e41 722e                             jb 0x5e71
00005e43 428d04bd00000000                 lea eax, [r15*4]
00005e4b f30f114c2430                     movss dword ptr [rsp + 0x30], xmm1
00005e51 f30f11542428                     movss dword ptr [rsp + 0x28], xmm2
00005e57 89442420                         mov dword ptr [rsp + 0x20], eax
00005e5b 458bcc                           mov r9d, r12d
00005e5e 458bc7                           mov r8d, r15d
00005e61 488bd7                           mov rdx, rdi
00005e64 488b4e38                         mov rcx, qword ptr [rsi + 0x38]
00005e68 e8133f0000                       call 0x9d80
00005e6d 4883c710                         add rdi, 0x10
00005e71 ffc3                             inc ebx
00005e73 4d8b4608                         mov r8, qword ptr [r14 + 8]
00005e77 413b5824                         cmp ebx, dword ptr [r8 + 0x24]
00005e7b 0f8c6fffffff                     jl 0x5df0
00005e81 41ffc5                           inc r13d
00005e84 453b6828                         cmp r13d, dword ptr [r8 + 0x28]
00005e88 0f8c22ffffff                     jl 0x5db0
00005e8e 498b06                           mov rax, qword ptr [r14]
00005e91 488d35e0b60100                   lea rsi, [rip + 0x1b6e0]
00005e98 4889742470                       mov qword ptr [rsp + 0x70], rsi
00005e9d c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005ea5 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005eac 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00005eb1 488b03                           mov rax, qword ptr [rbx]
00005eb4 4c8d4578                         lea r8, [rbp + 0x78]
00005eb8 ba02000000                       mov edx, 2
00005ebd 488bce                           mov rcx, rsi
00005ec0 ffd0                             call rax
00005ec2 85c0                             test eax, eax
00005ec4 0f85f0040000                     jne 0x63ba
00005eca 488b4578                         mov rax, qword ptr [rbp + 0x78]
00005ece 4889442460                       mov qword ptr [rsp + 0x60], rax
00005ed3 488b4010                         mov rax, qword ptr [rax + 0x10]
00005ed7 488b7da8                         mov rdi, qword ptr [rbp - 0x58]
00005edb 488bcf                           mov rcx, rdi
00005ede ffd0                             call rax
00005ee0 90                               nop 
00005ee1 488b4308                         mov rax, qword ptr [rbx + 8]
00005ee5 ba02000000                       mov edx, 2
00005eea 488bce                           mov rcx, rsi
00005eed ffd0                             call rax
00005eef 90                               nop 
00005ef0 498b06                           mov rax, qword ptr [r14]
00005ef3 4c8d3d8eb60100                   lea r15, [rip + 0x1b68e]
00005efa 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00005eff c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005f07 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005f0e 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00005f13 488b03                           mov rax, qword ptr [rbx]
00005f16 4c8d4578                         lea r8, [rbp + 0x78]
00005f1a ba02000000                       mov edx, 2
00005f1f 498bcf                           mov rcx, r15
00005f22 ffd0                             call rax
00005f24 85c0                             test eax, eax
00005f26 0f85a6040000                     jne 0x63d2
00005f2c 488b4578                         mov rax, qword ptr [rbp + 0x78]
00005f30 4889442460                       mov qword ptr [rsp + 0x60], rax
00005f35 488b4018                         mov rax, qword ptr [rax + 0x18]
00005f39 488bcf                           mov rcx, rdi
00005f3c ffd0                             call rax
00005f3e 90                               nop 
00005f3f 488b4308                         mov rax, qword ptr [rbx + 8]
00005f43 ba02000000                       mov edx, 2
00005f48 498bcf                           mov rcx, r15
00005f4b ffd0                             call rax
00005f4d 90                               nop 
00005f4e 498b06                           mov rax, qword ptr [r14]
00005f51 4889742470                       mov qword ptr [rsp + 0x70], rsi
00005f56 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005f5e 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005f65 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00005f6a 488b03                           mov rax, qword ptr [rbx]
00005f6d 4c8d4578                         lea r8, [rbp + 0x78]
00005f71 ba02000000                       mov edx, 2
00005f76 488bce                           mov rcx, rsi
00005f79 ffd0                             call rax
00005f7b 85c0                             test eax, eax
00005f7d 0f8567040000                     jne 0x63ea
00005f83 488b4578                         mov rax, qword ptr [rbp + 0x78]
00005f87 4889442460                       mov qword ptr [rsp + 0x60], rax
00005f8c 488b4010                         mov rax, qword ptr [rax + 0x10]
00005f90 488b7db0                         mov rdi, qword ptr [rbp - 0x50]
00005f94 488bcf                           mov rcx, rdi
00005f97 ffd0                             call rax
00005f99 90                               nop 
00005f9a 488b4308                         mov rax, qword ptr [rbx + 8]
00005f9e ba02000000                       mov edx, 2
00005fa3 488bce                           mov rcx, rsi
00005fa6 ffd0                             call rax
00005fa8 90                               nop 
00005fa9 498b06                           mov rax, qword ptr [r14]
00005fac 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00005fb1 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00005fb9 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00005fc0 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00005fc5 488b03                           mov rax, qword ptr [rbx]
00005fc8 4c8d4578                         lea r8, [rbp + 0x78]
00005fcc ba02000000                       mov edx, 2
00005fd1 498bcf                           mov rcx, r15
00005fd4 ffd0                             call rax
00005fd6 85c0                             test eax, eax
00005fd8 0f8524040000                     jne 0x6402
00005fde 488b4578                         mov rax, qword ptr [rbp + 0x78]
00005fe2 4889442460                       mov qword ptr [rsp + 0x60], rax
00005fe7 488b4018                         mov rax, qword ptr [rax + 0x18]
00005feb 488bcf                           mov rcx, rdi
00005fee ffd0                             call rax
00005ff0 90                               nop 
00005ff1 488b4308                         mov rax, qword ptr [rbx + 8]
00005ff5 ba02000000                       mov edx, 2
00005ffa 498bcf                           mov rcx, r15
00005ffd ffd0                             call rax
00005fff 90                               nop 
00006000 498b06                           mov rax, qword ptr [r14]
00006003 4889742470                       mov qword ptr [rsp + 0x70], rsi
00006008 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00006010 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00006017 48895c2468                       mov qword ptr [rsp + 0x68], rbx
0000601c 488b03                           mov rax, qword ptr [rbx]
0000601f 4c8d4578                         lea r8, [rbp + 0x78]
00006023 ba02000000                       mov edx, 2
00006028 488bce                           mov rcx, rsi
0000602b ffd0                             call rax
0000602d 85c0                             test eax, eax
0000602f 0f85e5030000                     jne 0x641a
00006035 488b4578                         mov rax, qword ptr [rbp + 0x78]
00006039 4889442460                       mov qword ptr [rsp + 0x60], rax
0000603e 488b4010                         mov rax, qword ptr [rax + 0x10]
00006042 488b7db8                         mov rdi, qword ptr [rbp - 0x48]
00006046 488bcf                           mov rcx, rdi
00006049 ffd0                             call rax
0000604b 90                               nop 
0000604c 488b4308                         mov rax, qword ptr [rbx + 8]
00006050 ba02000000                       mov edx, 2
00006055 488bce                           mov rcx, rsi
00006058 ffd0                             call rax
0000605a 90                               nop 
0000605b 498b06                           mov rax, qword ptr [r14]
0000605e 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00006063 c744247802000000                 mov dword ptr [rsp + 0x78], 2
0000606b 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00006072 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00006077 488b03                           mov rax, qword ptr [rbx]
0000607a 4c8d4578                         lea r8, [rbp + 0x78]
0000607e ba02000000                       mov edx, 2
00006083 498bcf                           mov rcx, r15
00006086 ffd0                             call rax
00006088 85c0                             test eax, eax
0000608a 0f85a2030000                     jne 0x6432
00006090 488b4578                         mov rax, qword ptr [rbp + 0x78]
00006094 4889442460                       mov qword ptr [rsp + 0x60], rax
00006099 488b4018                         mov rax, qword ptr [rax + 0x18]
0000609d 488bcf                           mov rcx, rdi
000060a0 ffd0                             call rax
000060a2 90                               nop 
000060a3 488b4308                         mov rax, qword ptr [rbx + 8]
000060a7 ba02000000                       mov edx, 2
000060ac 498bcf                           mov rcx, r15
000060af ffd0                             call rax
000060b1 90                               nop 
000060b2 498b06                           mov rax, qword ptr [r14]
000060b5 4889742470                       mov qword ptr [rsp + 0x70], rsi
000060ba c744247802000000                 mov dword ptr [rsp + 0x78], 2
000060c2 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
000060c9 48895c2468                       mov qword ptr [rsp + 0x68], rbx
000060ce 488b03                           mov rax, qword ptr [rbx]
000060d1 4c8d4578                         lea r8, [rbp + 0x78]
000060d5 ba02000000                       mov edx, 2
000060da 488bce                           mov rcx, rsi
000060dd ffd0                             call rax
000060df 85c0                             test eax, eax
000060e1 0f8563030000                     jne 0x644a
000060e7 488b4578                         mov rax, qword ptr [rbp + 0x78]
000060eb 4889442460                       mov qword ptr [rsp + 0x60], rax
000060f0 488b4010                         mov rax, qword ptr [rax + 0x10]
000060f4 488b7dc0                         mov rdi, qword ptr [rbp - 0x40]
000060f8 488bcf                           mov rcx, rdi
000060fb ffd0                             call rax
000060fd 90                               nop 
000060fe 488b4308                         mov rax, qword ptr [rbx + 8]
00006102 ba02000000                       mov edx, 2
00006107 488bce                           mov rcx, rsi
0000610a ffd0                             call rax
0000610c 90                               nop 
0000610d 498b06                           mov rax, qword ptr [r14]
00006110 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00006115 c744247802000000                 mov dword ptr [rsp + 0x78], 2
0000611d 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00006124 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00006129 488b03                           mov rax, qword ptr [rbx]
0000612c 4c8d4578                         lea r8, [rbp + 0x78]
00006130 ba02000000                       mov edx, 2
00006135 498bcf                           mov rcx, r15
00006138 ffd0                             call rax
0000613a 85c0                             test eax, eax
0000613c 0f8520030000                     jne 0x6462
00006142 488b4578                         mov rax, qword ptr [rbp + 0x78]
00006146 4889442460                       mov qword ptr [rsp + 0x60], rax
0000614b 488b4018                         mov rax, qword ptr [rax + 0x18]
0000614f 488bcf                           mov rcx, rdi
00006152 ffd0                             call rax
00006154 90                               nop 
00006155 488b4308                         mov rax, qword ptr [rbx + 8]
00006159 ba02000000                       mov edx, 2
0000615e 498bcf                           mov rcx, r15
00006161 ffd0                             call rax
00006163 90                               nop 
00006164 498b06                           mov rax, qword ptr [r14]
00006167 4889742470                       mov qword ptr [rsp + 0x70], rsi
0000616c c744247802000000                 mov dword ptr [rsp + 0x78], 2
00006174 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
0000617b 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00006180 488b03                           mov rax, qword ptr [rbx]
00006183 4c8d4578                         lea r8, [rbp + 0x78]
00006187 ba02000000                       mov edx, 2
0000618c 488bce                           mov rcx, rsi
0000618f ffd0                             call rax
00006191 85c0                             test eax, eax
00006193 0f85e1020000                     jne 0x647a
00006199 488b4578                         mov rax, qword ptr [rbp + 0x78]
0000619d 4889442460                       mov qword ptr [rsp + 0x60], rax
000061a2 488b4010                         mov rax, qword ptr [rax + 0x10]
000061a6 488b7dc8                         mov rdi, qword ptr [rbp - 0x38]
000061aa 488bcf                           mov rcx, rdi
000061ad ffd0                             call rax
000061af 90                               nop 
000061b0 488b4308                         mov rax, qword ptr [rbx + 8]
000061b4 ba02000000                       mov edx, 2
000061b9 488bce                           mov rcx, rsi
000061bc ffd0                             call rax
000061be 90                               nop 
000061bf 498b06                           mov rax, qword ptr [r14]
000061c2 4c897c2470                       mov qword ptr [rsp + 0x70], r15
000061c7 c744247802000000                 mov dword ptr [rsp + 0x78], 2
000061cf 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
000061d6 48895c2468                       mov qword ptr [rsp + 0x68], rbx
000061db 488b03                           mov rax, qword ptr [rbx]
000061de 4c8d4578                         lea r8, [rbp + 0x78]
000061e2 ba02000000                       mov edx, 2
000061e7 498bcf                           mov rcx, r15
000061ea ffd0                             call rax
000061ec 85c0                             test eax, eax
000061ee 0f859e020000                     jne 0x6492
000061f4 488b4578                         mov rax, qword ptr [rbp + 0x78]
000061f8 4889442460                       mov qword ptr [rsp + 0x60], rax
000061fd 488b4018                         mov rax, qword ptr [rax + 0x18]
00006201 488bcf                           mov rcx, rdi
00006204 ffd0                             call rax
00006206 90                               nop 
00006207 488b4308                         mov rax, qword ptr [rbx + 8]
0000620b ba02000000                       mov edx, 2
00006210 498bcf                           mov rcx, r15
00006213 ffd0                             call rax
00006215 90                               nop 
00006216 498b06                           mov rax, qword ptr [r14]
00006219 4889742470                       mov qword ptr [rsp + 0x70], rsi
0000621e c744247802000000                 mov dword ptr [rsp + 0x78], 2
00006226 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
0000622d 48895c2468                       mov qword ptr [rsp + 0x68], rbx
00006232 488b03                           mov rax, qword ptr [rbx]
00006235 4c8d4578                         lea r8, [rbp + 0x78]
00006239 ba02000000                       mov edx, 2
0000623e 488bce                           mov rcx, rsi
00006241 ffd0                             call rax
00006243 85c0                             test eax, eax
00006245 0f855f020000                     jne 0x64aa
0000624b 488b4578                         mov rax, qword ptr [rbp + 0x78]
0000624f 4889442460                       mov qword ptr [rsp + 0x60], rax
00006254 488b4010                         mov rax, qword ptr [rax + 0x10]
00006258 488b7dd0                         mov rdi, qword ptr [rbp - 0x30]
0000625c 488bcf                           mov rcx, rdi
0000625f ffd0                             call rax
00006261 90                               nop 
00006262 488b4308                         mov rax, qword ptr [rbx + 8]
00006266 ba02000000                       mov edx, 2
0000626b 488bce                           mov rcx, rsi
0000626e ffd0                             call rax
00006270 90                               nop 
00006271 498b06                           mov rax, qword ptr [r14]
00006274 4c897c2470                       mov qword ptr [rsp + 0x70], r15
00006279 c744247802000000                 mov dword ptr [rsp + 0x78], 2
00006281 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
00006288 48895c2468                       mov qword ptr [rsp + 0x68], rbx
0000628d 488b03                           mov rax, qword ptr [rbx]
00006290 4c8d4578                         lea r8, [rbp + 0x78]
00006294 ba02000000                       mov edx, 2
00006299 498bcf                           mov rcx, r15
0000629c ffd0                             call rax
0000629e 85c0                             test eax, eax
000062a0 0f851c020000                     jne 0x64c2
000062a6 488b4578                         mov rax, qword ptr [rbp + 0x78]
000062aa 4889442460                       mov qword ptr [rsp + 0x60], rax
000062af 488b4018                         mov rax, qword ptr [rax + 0x18]
000062b3 488bcf                           mov rcx, rdi
000062b6 ffd0                             call rax
000062b8 90                               nop 
000062b9 488b4308                         mov rax, qword ptr [rbx + 8]
000062bd ba02000000                       mov edx, 2
000062c2 498bcf                           mov rcx, r15
000062c5 ffd0                             call rax
000062c7 90                               nop 
000062c8 498b06                           mov rax, qword ptr [r14]
000062cb 4889742470                       mov qword ptr [rsp + 0x70], rsi
000062d0 c744247802000000                 mov dword ptr [rsp + 0x78], 2
000062d8 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
000062df 48895c2468                       mov qword ptr [rsp + 0x68], rbx
000062e4 488b03                           mov rax, qword ptr [rbx]
000062e7 4c8d4578                         lea r8, [rbp + 0x78]
000062eb ba02000000                       mov edx, 2
000062f0 488bce                           mov rcx, rsi
000062f3 ffd0                             call rax
000062f5 85c0                             test eax, eax
000062f7 0f85dd010000                     jne 0x64da
000062fd 488b4578                         mov rax, qword ptr [rbp + 0x78]
00006301 4889442460                       mov qword ptr [rsp + 0x60], rax
00006306 488b4010                         mov rax, qword ptr [rax + 0x10]
0000630a 488b7dd8                         mov rdi, qword ptr [rbp - 0x28]
0000630e 488bcf                           mov rcx, rdi
00006311 ffd0                             call rax
00006313 90                               nop 
00006314 488b4308                         mov rax, qword ptr [rbx + 8]
00006318 ba02000000                       mov edx, 2
0000631d 488bce                           mov rcx, rsi
00006320 ffd0                             call rax
00006322 90                               nop 
00006323 498b06                           mov rax, qword ptr [r14]
00006326 4c897c2470                       mov qword ptr [rsp + 0x70], r15
0000632b c744247802000000                 mov dword ptr [rsp + 0x78], 2
00006333 488b9880010000                   mov rbx, qword ptr [rax + 0x180]
0000633a 48895c2468                       mov qword ptr [rsp + 0x68], rbx
0000633f 488b03                           mov rax, qword ptr [rbx]
00006342 4c8d4578                         lea r8, [rbp + 0x78]
00006346 ba02000000                       mov edx, 2
0000634b 498bcf                           mov rcx, r15
0000634e ffd0                             call rax
00006350 85c0                             test eax, eax
00006352 754e                             jne 0x63a2
00006354 488b4578                         mov rax, qword ptr [rbp + 0x78]
00006358 4889442460                       mov qword ptr [rsp + 0x60], rax
0000635d 488b4018                         mov rax, qword ptr [rax + 0x18]
00006361 488bcf                           mov rcx, rdi
00006364 ffd0                             call rax
00006366 90                               nop 
00006367 488b4308                         mov rax, qword ptr [rbx + 8]
0000636b ba02000000                       mov edx, 2
00006370 498bcf                           mov rcx, r15
00006373 ffd0                             call rax
00006375 90                               nop 
00006376 4c8d9c2428010000                 lea r11, [rsp + 0x128]
0000637e 410f2873e8                       movaps xmm6, xmmword ptr [r11 - 0x18]
00006383 410f287bd8                       movaps xmm7, xmmword ptr [r11 - 0x28]
00006388 450f2843c8                       movaps xmm8, xmmword ptr [r11 - 0x38]
0000638d 450f284bb8                       movaps xmm9, xmmword ptr [r11 - 0x48]
00006392 498be3                           mov rsp, r11
00006395 415f                             pop r15
00006397 415e                             pop r14
00006399 415d                             pop r13
0000639b 415c                             pop r12
0000639d 5f                               pop rdi
0000639e 5e                               pop rsi
0000639f 5b                               pop rbx
000063a0 5d                               pop rbp
000063a1 c3                               ret 
000063a2 c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
000063a9 488d15b83b0200                   lea rdx, [rip + 0x23bb8]
000063b0 488d4d70                         lea rcx, [rbp + 0x70]
000063b4 e861910100                       call 0x1f51a
000063b9 cc                               int3 
000063ba c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
000063c1 488d15a03b0200                   lea rdx, [rip + 0x23ba0]
000063c8 488d4d70                         lea rcx, [rbp + 0x70]
000063cc e849910100                       call 0x1f51a
000063d1 cc                               int3 
000063d2 c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
000063d9 488d15883b0200                   lea rdx, [rip + 0x23b88]
000063e0 488d4d70                         lea rcx, [rbp + 0x70]
000063e4 e831910100                       call 0x1f51a
000063e9 cc                               int3 
000063ea c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
000063f1 488d15703b0200                   lea rdx, [rip + 0x23b70]
000063f8 488d4d70                         lea rcx, [rbp + 0x70]
000063fc e819910100                       call 0x1f51a
00006401 cc                               int3 
00006402 c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
00006409 488d15583b0200                   lea rdx, [rip + 0x23b58]
00006410 488d4d70                         lea rcx, [rbp + 0x70]
00006414 e801910100                       call 0x1f51a
00006419 cc                               int3 
0000641a c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
00006421 488d15403b0200                   lea rdx, [rip + 0x23b40]
00006428 488d4d70                         lea rcx, [rbp + 0x70]
0000642c e8e9900100                       call 0x1f51a
00006431 cc                               int3 
00006432 c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
00006439 488d15283b0200                   lea rdx, [rip + 0x23b28]
00006440 488d4d70                         lea rcx, [rbp + 0x70]
00006444 e8d1900100                       call 0x1f51a
00006449 cc                               int3 
0000644a c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
00006451 488d15103b0200                   lea rdx, [rip + 0x23b10]
00006458 488d4d70                         lea rcx, [rbp + 0x70]
0000645c e8b9900100                       call 0x1f51a
00006461 cc                               int3 
00006462 c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
00006469 488d15f83a0200                   lea rdx, [rip + 0x23af8]
00006470 488d4d70                         lea rcx, [rbp + 0x70]
00006474 e8a1900100                       call 0x1f51a
00006479 cc                               int3 
0000647a c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
00006481 488d15e03a0200                   lea rdx, [rip + 0x23ae0]
00006488 488d4d70                         lea rcx, [rbp + 0x70]
0000648c e889900100                       call 0x1f51a
00006491 cc                               int3 
00006492 c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
00006499 488d15c83a0200                   lea rdx, [rip + 0x23ac8]
000064a0 488d4d70                         lea rcx, [rbp + 0x70]
000064a4 e871900100                       call 0x1f51a
000064a9 cc                               int3 
000064aa c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
000064b1 488d15b03a0200                   lea rdx, [rip + 0x23ab0]
000064b8 488d4d70                         lea rcx, [rbp + 0x70]
000064bc e859900100                       call 0x1f51a
000064c1 cc                               int3 
000064c2 c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
000064c9 488d15983a0200                   lea rdx, [rip + 0x23a98]
000064d0 488d4d70                         lea rcx, [rbp + 0x70]
000064d4 e841900100                       call 0x1f51a
000064d9 cc                               int3 
000064da c745700d000000                   mov dword ptr [rbp + 0x70], 0xd
000064e1 488d15803a0200                   lea rdx, [rip + 0x23a80]
000064e8 488d4d70                         lea rcx, [rbp + 0x70]
000064ec e829900100                       call 0x1f51a
000064f1 cc                               int3 
000064f2 cc                               int3 
000064f3 cc                               int3 
000064f4 cc                               int3 
000064f5 cc                               int3 
000064f6 cc                               int3 
000064f7 cc                               int3 
000064f8 cc                               int3 
000064f9 cc                               int3 
000064fa cc                               int3 
000064fb cc                               int3 
000064fc cc                               int3 
000064fd cc                               int3 
000064fe cc                               int3 
000064ff cc                               int3 
00006500 4057                             push rdi
00006502 4883ec20                         sub rsp, 0x20
00006506 488bf9                           mov rdi, rcx
00006509 85d2                             test edx, edx

# RVA 65c0..8540
000065c0 48895c2418                       mov qword ptr [rsp + 0x18], rbx
000065c5 55                               push rbp
000065c6 56                               push rsi
000065c7 57                               push rdi
000065c8 4156                             push r14
000065ca 4157                             push r15
000065cc 4883ec70                         sub rsp, 0x70
000065d0 0f29742460                       movaps xmmword ptr [rsp + 0x60], xmm6
000065d5 488b059c4b0200                   mov rax, qword ptr [rip + 0x24b9c]
000065dc 4833c4                           xor rax, rsp
000065df 4889442450                       mov qword ptr [rsp + 0x50], rax
000065e4 83795003                         cmp dword ptr [rcx + 0x50], 3
000065e8 488bd9                           mov rbx, rcx
000065eb 0f856d010000                     jne 0x675e
000065f1 4883b9a800000000                 cmp qword ptr [rcx + 0xa8], 0
000065f9 0f840b020000                     je 0x680a
000065ff 4c8b4108                         mov r8, qword ptr [rcx + 8]
00006603 4533ff                           xor r15d, r15d
00006606 45397828                         cmp dword ptr [r8 + 0x28], r15d
0000660a 0f8efa010000                     jle 0x680a
00006610 f30f1035bcac0100                 movss xmm6, dword ptr [rip + 0x1acbc]
00006618 4c89a424a8000000                 mov qword ptr [rsp + 0xa8], r12
00006620 418b5024                         mov edx, dword ptr [r8 + 0x24]
00006624 33ff                             xor edi, edi
00006626 418b706c                         mov esi, dword ptr [r8 + 0x6c]
0000662a 8bc2                             mov eax, edx
0000662c 410fafc7                         imul eax, r15d
00006630 4863c8                           movsxd rcx, eax
00006633 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
0000663a 488d2c88                         lea rbp, [rax + rcx*4]
0000663e 488b8390000000                   mov rax, qword ptr [rbx + 0x90]
00006645 4c8d3488                         lea r14, [rax + rcx*4]
00006649 488b8ba8000000                   mov rcx, qword ptr [rbx + 0xa8]
00006650 2b716c                           sub esi, dword ptr [rcx + 0x6c]
00006653 4103f7                           add esi, r15d
00006656 8bc6                             mov eax, esi
00006658 0faf4120                         imul eax, dword ptr [rcx + 0x20]
0000665c 4c63e0                           movsxd r12, eax
0000665f 498bc0                           mov rax, r8
00006662 4c036118                         add r12, qword ptr [rcx + 0x18]
00006666 85d2                             test edx, edx
00006668 0f8ed3000000                     jle 0x6741
0000666e 6690                             nop 
00006670 488b8ba8000000                   mov rcx, qword ptr [rbx + 0xa8]
00006677 85f6                             test esi, esi
00006679 0f8884000000                     js 0x6703
0000667f 3b7128                           cmp esi, dword ptr [rcx + 0x28]
00006682 7d7f                             jge 0x6703
00006684 418b4068                         mov eax, dword ptr [r8 + 0x68]
00006688 2b4168                           sub eax, dword ptr [rcx + 0x68]
0000668b 03c7                             add eax, edi
0000668d 7874                             js 0x6703
0000668f 3b4124                           cmp eax, dword ptr [rcx + 0x24]
00006692 7d6f                             jge 0x6703
00006694 4898                             cdqe 
00006696 4c8d4c2440                       lea r9, [rsp + 0x40]
0000669b 4c8d44244c                       lea r8, [rsp + 0x4c]
000066a0 488d542448                       lea rdx, [rsp + 0x48]
000066a5 498d0cc4                         lea rcx, [r12 + rax*8]
000066a9 48894c2420                       mov qword ptr [rsp + 0x20], rcx
000066ae 488d4c2444                       lea rcx, [rsp + 0x44]
000066b3 e8a80c0100                       call 0x17360
000066b8 f30f10542440                     movss xmm2, dword ptr [rsp + 0x40]
000066be 4c8d442430                       lea r8, [rsp + 0x30]
000066c3 f30f104c2448                     movss xmm1, dword ptr [rsp + 0x48]
000066c9 488d542434                       lea rdx, [rsp + 0x34]
000066ce 0f28c2                           movaps xmm0, xmm2
000066d1 f30f59ca                         mulss xmm1, xmm2
000066d5 488d4c2438                       lea rcx, [rsp + 0x38]
000066da f30f5944244c                     mulss xmm0, dword ptr [rsp + 0x4c]
000066e0 f30f114c2434                     movss dword ptr [rsp + 0x34], xmm1
000066e6 f30f11442430                     movss dword ptr [rsp + 0x30], xmm0
000066ec f30f10442444                     movss xmm0, dword ptr [rsp + 0x44]
000066f2 f30f59c2                         mulss xmm0, xmm2
000066f6 f30f11442438                     movss dword ptr [rsp + 0x38], xmm0
000066fc e82f4f0000                       call 0xb630
00006701 eb03                             jmp 0x6706
00006703 0f57c0                           xorps xmm0, xmm0
00006706 f30f104b3c                       movss xmm1, dword ptr [rbx + 0x3c]
0000670b ffc7                             inc edi
0000670d 0f28d1                           movaps xmm2, xmm1
00006710 f30f59d0                         mulss xmm2, xmm0
00006714 0f28c6                           movaps xmm0, xmm6
00006717 f30f5cc1                         subss xmm0, xmm1
0000671b f30f58d0                         addss xmm2, xmm0
0000671f f30f595500                       mulss xmm2, dword ptr [rbp]
00006724 4883c504                         add rbp, 4
00006728 f3410f1116                       movss dword ptr [r14], xmm2
0000672d 4983c604                         add r14, 4
00006731 488b4308                         mov rax, qword ptr [rbx + 8]
00006735 4c8bc0                           mov r8, rax
00006738 3b7824                           cmp edi, dword ptr [rax + 0x24]
0000673b 0f8c2fffffff                     jl 0x6670
00006741 41ffc7                           inc r15d
00006744 4c8bc0                           mov r8, rax
00006747 443b7828                         cmp r15d, dword ptr [rax + 0x28]
0000674b 0f8ccffeffff                     jl 0x6620
00006751 4c8ba424a8000000                 mov r12, qword ptr [rsp + 0xa8]
00006759 e9ac000000                       jmp 0x680a
0000675e 4c8b4108                         mov r8, qword ptr [rcx + 8]
00006762 33f6                             xor esi, esi
00006764 41397028                         cmp dword ptr [r8 + 0x28], esi
00006768 0f8e9c000000                     jle 0x680a
0000676e f30f10355eab0100                 movss xmm6, dword ptr [rip + 0x1ab5e]
00006776 66660f1f840000000000             nop word ptr [rax + rax]
00006780 418b5024                         mov edx, dword ptr [r8 + 0x24]
00006784 33ff                             xor edi, edi
00006786 8bc2                             mov eax, edx
00006788 0fafc6                           imul eax, esi
0000678b 4863c8                           movsxd rcx, eax
0000678e 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
00006795 488d2c88                         lea rbp, [rax + rcx*4]
00006799 488b8390000000                   mov rax, qword ptr [rbx + 0x90]
000067a0 4c8d3488                         lea r14, [rax + rcx*4]
000067a4 85d2                             test edx, edx
000067a6 7e56                             jle 0x67fe
000067a8 0f1f840000000000                 nop dword ptr [rax + rax]
000067b0 440fb68bf8000000                 movzx r9d, byte ptr [rbx + 0xf8]
000067b8 488d8bb0000000                   lea rcx, [rbx + 0xb0]
000067bf 448bc6                           mov r8d, esi
000067c2 8bd7                             mov edx, edi
000067c4 e8b72e0000                       call 0x9680
000067c9 f30f10533c                       movss xmm2, dword ptr [rbx + 0x3c]
000067ce 0f28ce                           movaps xmm1, xmm6
000067d1 0f28da                           movaps xmm3, xmm2
000067d4 f30f5cca                         subss xmm1, xmm2
000067d8 f30f59d8                         mulss xmm3, xmm0
000067dc ffc7                             inc edi
000067de f30f58d9                         addss xmm3, xmm1
000067e2 f30f595d00                       mulss xmm3, dword ptr [rbp]
000067e7 4883c504                         add rbp, 4
000067eb f3410f111e                       movss dword ptr [r14], xmm3
000067f0 4983c604                         add r14, 4
000067f4 4c8b4308                         mov r8, qword ptr [rbx + 8]
000067f8 413b7824                         cmp edi, dword ptr [r8 + 0x24]
000067fc 7cb2                             jl 0x67b0
000067fe ffc6                             inc esi
00006800 413b7028                         cmp esi, dword ptr [r8 + 0x28]
00006804 0f8c76ffffff                     jl 0x6780
0000680a 488b4c2450                       mov rcx, qword ptr [rsp + 0x50]
0000680f 4833cc                           xor rcx, rsp
00006812 e8a9680100                       call 0x1d0c0
00006817 488b9c24b0000000                 mov rbx, qword ptr [rsp + 0xb0]
0000681f 0f28742460                       movaps xmm6, xmmword ptr [rsp + 0x60]
00006824 4883c470                         add rsp, 0x70
00006828 415f                             pop r15
0000682a 415e                             pop r14
0000682c 5f                               pop rdi
0000682d 5e                               pop rsi
0000682e 5d                               pop rbp
0000682f c3                               ret 
00006830 48895c2418                       mov qword ptr [rsp + 0x18], rbx
00006835 55                               push rbp
00006836 56                               push rsi
00006837 57                               push rdi
00006838 4156                             push r14
0000683a 4157                             push r15
0000683c 4883ec70                         sub rsp, 0x70
00006840 0f29742460                       movaps xmmword ptr [rsp + 0x60], xmm6
00006845 488b052c490200                   mov rax, qword ptr [rip + 0x2492c]
0000684c 4833c4                           xor rax, rsp
0000684f 4889442450                       mov qword ptr [rsp + 0x50], rax
00006854 83795003                         cmp dword ptr [rcx + 0x50], 3
00006858 488bd9                           mov rbx, rcx
0000685b 0f856d010000                     jne 0x69ce
00006861 4883b9a800000000                 cmp qword ptr [rcx + 0xa8], 0
00006869 0f840b020000                     je 0x6a7a
0000686f 4c8b4108                         mov r8, qword ptr [rcx + 8]
00006873 4533ff                           xor r15d, r15d
00006876 45397828                         cmp dword ptr [r8 + 0x28], r15d
0000687a 0f8efa010000                     jle 0x6a7a
00006880 f30f10354caa0100                 movss xmm6, dword ptr [rip + 0x1aa4c]
00006888 4c89a424a8000000                 mov qword ptr [rsp + 0xa8], r12
00006890 418b5024                         mov edx, dword ptr [r8 + 0x24]
00006894 33ff                             xor edi, edi
00006896 418b706c                         mov esi, dword ptr [r8 + 0x6c]
0000689a 8bc2                             mov eax, edx
0000689c 410fafc7                         imul eax, r15d
000068a0 4863c8                           movsxd rcx, eax
000068a3 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
000068aa 488d2c88                         lea rbp, [rax + rcx*4]
000068ae 488b8390000000                   mov rax, qword ptr [rbx + 0x90]
000068b5 4c8d3488                         lea r14, [rax + rcx*4]
000068b9 488b8ba8000000                   mov rcx, qword ptr [rbx + 0xa8]
000068c0 2b716c                           sub esi, dword ptr [rcx + 0x6c]
000068c3 4103f7                           add esi, r15d
000068c6 8bc6                             mov eax, esi
000068c8 0faf4120                         imul eax, dword ptr [rcx + 0x20]
000068cc 4c63e0                           movsxd r12, eax
000068cf 498bc0                           mov rax, r8
000068d2 4c036118                         add r12, qword ptr [rcx + 0x18]
000068d6 85d2                             test edx, edx
000068d8 0f8ed3000000                     jle 0x69b1
000068de 6690                             nop 
000068e0 488b8ba8000000                   mov rcx, qword ptr [rbx + 0xa8]
000068e7 85f6                             test esi, esi
000068e9 0f8884000000                     js 0x6973
000068ef 3b7128                           cmp esi, dword ptr [rcx + 0x28]
000068f2 7d7f                             jge 0x6973
000068f4 418b4068                         mov eax, dword ptr [r8 + 0x68]
000068f8 2b4168                           sub eax, dword ptr [rcx + 0x68]
000068fb 03c7                             add eax, edi
000068fd 7874                             js 0x6973
000068ff 3b4124                           cmp eax, dword ptr [rcx + 0x24]
00006902 7d6f                             jge 0x6973
00006904 4898                             cdqe 
00006906 4c8d4c2440                       lea r9, [rsp + 0x40]
0000690b 4c8d44244c                       lea r8, [rsp + 0x4c]
00006910 488d542448                       lea rdx, [rsp + 0x48]
00006915 498d0c84                         lea rcx, [r12 + rax*4]
00006919 48894c2420                       mov qword ptr [rsp + 0x20], rcx
0000691e 488d4c2444                       lea rcx, [rsp + 0x44]
00006923 e8c8090100                       call 0x172f0
00006928 f30f10542440                     movss xmm2, dword ptr [rsp + 0x40]
0000692e 4c8d442430                       lea r8, [rsp + 0x30]
00006933 f30f104c2448                     movss xmm1, dword ptr [rsp + 0x48]
00006939 488d542434                       lea rdx, [rsp + 0x34]
0000693e 0f28c2                           movaps xmm0, xmm2
00006941 f30f59ca                         mulss xmm1, xmm2
00006945 488d4c2438                       lea rcx, [rsp + 0x38]
0000694a f30f5944244c                     mulss xmm0, dword ptr [rsp + 0x4c]
00006950 f30f114c2434                     movss dword ptr [rsp + 0x34], xmm1
00006956 f30f11442430                     movss dword ptr [rsp + 0x30], xmm0
0000695c f30f10442444                     movss xmm0, dword ptr [rsp + 0x44]
00006962 f30f59c2                         mulss xmm0, xmm2
00006966 f30f11442438                     movss dword ptr [rsp + 0x38], xmm0
0000696c e8bf4c0000                       call 0xb630
00006971 eb03                             jmp 0x6976
00006973 0f57c0                           xorps xmm0, xmm0
00006976 f30f104b3c                       movss xmm1, dword ptr [rbx + 0x3c]
0000697b ffc7                             inc edi
0000697d 0f28d1                           movaps xmm2, xmm1
00006980 f30f59d0                         mulss xmm2, xmm0
00006984 0f28c6                           movaps xmm0, xmm6
00006987 f30f5cc1                         subss xmm0, xmm1
0000698b f30f58d0                         addss xmm2, xmm0
0000698f f30f595500                       mulss xmm2, dword ptr [rbp]
00006994 4883c504                         add rbp, 4
00006998 f3410f1116                       movss dword ptr [r14], xmm2
0000699d 4983c604                         add r14, 4
000069a1 488b4308                         mov rax, qword ptr [rbx + 8]
000069a5 4c8bc0                           mov r8, rax
000069a8 3b7824                           cmp edi, dword ptr [rax + 0x24]
000069ab 0f8c2fffffff                     jl 0x68e0
000069b1 41ffc7                           inc r15d
000069b4 4c8bc0                           mov r8, rax
000069b7 443b7828                         cmp r15d, dword ptr [rax + 0x28]
000069bb 0f8ccffeffff                     jl 0x6890
000069c1 4c8ba424a8000000                 mov r12, qword ptr [rsp + 0xa8]
000069c9 e9ac000000                       jmp 0x6a7a
000069ce 4c8b4108                         mov r8, qword ptr [rcx + 8]
000069d2 33f6                             xor esi, esi
000069d4 41397028                         cmp dword ptr [r8 + 0x28], esi
000069d8 0f8e9c000000                     jle 0x6a7a
000069de f30f1035eea80100                 movss xmm6, dword ptr [rip + 0x1a8ee]
000069e6 66660f1f840000000000             nop word ptr [rax + rax]
000069f0 418b5024                         mov edx, dword ptr [r8 + 0x24]
000069f4 33ff                             xor edi, edi
000069f6 8bc2                             mov eax, edx
000069f8 0fafc6                           imul eax, esi
000069fb 4863c8                           movsxd rcx, eax
000069fe 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
00006a05 488d2c88                         lea rbp, [rax + rcx*4]
00006a09 488b8390000000                   mov rax, qword ptr [rbx + 0x90]
00006a10 4c8d3488                         lea r14, [rax + rcx*4]
00006a14 85d2                             test edx, edx
00006a16 7e56                             jle 0x6a6e
00006a18 0f1f840000000000                 nop dword ptr [rax + rax]
00006a20 440fb68bf8000000                 movzx r9d, byte ptr [rbx + 0xf8]
00006a28 488d8bb0000000                   lea rcx, [rbx + 0xb0]
00006a2f 448bc6                           mov r8d, esi
00006a32 8bd7                             mov edx, edi
00006a34 e8472c0000                       call 0x9680
00006a39 f30f10533c                       movss xmm2, dword ptr [rbx + 0x3c]
00006a3e 0f28ce                           movaps xmm1, xmm6
00006a41 0f28da                           movaps xmm3, xmm2
00006a44 f30f5cca                         subss xmm1, xmm2
00006a48 f30f59d8                         mulss xmm3, xmm0
00006a4c ffc7                             inc edi
00006a4e f30f58d9                         addss xmm3, xmm1
00006a52 f30f595d00                       mulss xmm3, dword ptr [rbp]
00006a57 4883c504                         add rbp, 4
00006a5b f3410f111e                       movss dword ptr [r14], xmm3
00006a60 4983c604                         add r14, 4
00006a64 4c8b4308                         mov r8, qword ptr [rbx + 8]
00006a68 413b7824                         cmp edi, dword ptr [r8 + 0x24]
00006a6c 7cb2                             jl 0x6a20
00006a6e ffc6                             inc esi
00006a70 413b7028                         cmp esi, dword ptr [r8 + 0x28]
00006a74 0f8c76ffffff                     jl 0x69f0
00006a7a 488b4c2450                       mov rcx, qword ptr [rsp + 0x50]
00006a7f 4833cc                           xor rcx, rsp
00006a82 e839660100                       call 0x1d0c0
00006a87 488b9c24b0000000                 mov rbx, qword ptr [rsp + 0xb0]
00006a8f 0f28742460                       movaps xmm6, xmmword ptr [rsp + 0x60]
00006a94 4883c470                         add rsp, 0x70
00006a98 415f                             pop r15
00006a9a 415e                             pop r14
00006a9c 5f                               pop rdi
00006a9d 5e                               pop rsi
00006a9e 5d                               pop rbp
00006a9f c3                               ret 
00006aa0 48895c2418                       mov qword ptr [rsp + 0x18], rbx
00006aa5 55                               push rbp
00006aa6 56                               push rsi
00006aa7 57                               push rdi
00006aa8 4156                             push r14
00006aaa 4157                             push r15
00006aac 4883ec70                         sub rsp, 0x70
00006ab0 0f29742460                       movaps xmmword ptr [rsp + 0x60], xmm6
00006ab5 488b05bc460200                   mov rax, qword ptr [rip + 0x246bc]
00006abc 4833c4                           xor rax, rsp
00006abf 4889442450                       mov qword ptr [rsp + 0x50], rax
00006ac4 83795003                         cmp dword ptr [rcx + 0x50], 3
00006ac8 488bd9                           mov rbx, rcx
00006acb 0f8574010000                     jne 0x6c45
00006ad1 4883b9a800000000                 cmp qword ptr [rcx + 0xa8], 0
00006ad9 0f840b020000                     je 0x6cea
00006adf 4c8b4108                         mov r8, qword ptr [rcx + 8]
00006ae3 4533ff                           xor r15d, r15d
00006ae6 45397828                         cmp dword ptr [r8 + 0x28], r15d
00006aea 0f8efa010000                     jle 0x6cea
00006af0 f30f1035dca70100                 movss xmm6, dword ptr [rip + 0x1a7dc]
00006af8 4c89a424a8000000                 mov qword ptr [rsp + 0xa8], r12
00006b00 418b5024                         mov edx, dword ptr [r8 + 0x24]
00006b04 33ff                             xor edi, edi
00006b06 418b706c                         mov esi, dword ptr [r8 + 0x6c]
00006b0a 8bc2                             mov eax, edx
00006b0c 410fafc7                         imul eax, r15d
00006b10 4863c8                           movsxd rcx, eax
00006b13 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
00006b1a 488d2c88                         lea rbp, [rax + rcx*4]
00006b1e 488b8390000000                   mov rax, qword ptr [rbx + 0x90]
00006b25 4c8d3488                         lea r14, [rax + rcx*4]
00006b29 488b8ba8000000                   mov rcx, qword ptr [rbx + 0xa8]
00006b30 2b716c                           sub esi, dword ptr [rcx + 0x6c]
00006b33 4103f7                           add esi, r15d
00006b36 8bc6                             mov eax, esi
00006b38 0faf4120                         imul eax, dword ptr [rcx + 0x20]
00006b3c 4c63e0                           movsxd r12, eax
00006b3f 498bc0                           mov rax, r8
00006b42 4c036118                         add r12, qword ptr [rcx + 0x18]
00006b46 85d2                             test edx, edx
00006b48 0f8eda000000                     jle 0x6c28
00006b4e 6690                             nop 
00006b50 488b8ba8000000                   mov rcx, qword ptr [rbx + 0xa8]
00006b57 85f6                             test esi, esi
00006b59 0f888b000000                     js 0x6bea
00006b5f 3b7128                           cmp esi, dword ptr [rcx + 0x28]
00006b62 0f8d82000000                     jge 0x6bea
00006b68 418b4068                         mov eax, dword ptr [r8 + 0x68]
00006b6c 2b4168                           sub eax, dword ptr [rcx + 0x68]
00006b6f 03c7                             add eax, edi
00006b71 7877                             js 0x6bea
00006b73 3b4124                           cmp eax, dword ptr [rcx + 0x24]
00006b76 7d72                             jge 0x6bea
00006b78 4898                             cdqe 
00006b7a 4c8d4c2440                       lea r9, [rsp + 0x40]
00006b7f 48c1e004                         shl rax, 4
00006b83 4c8d44244c                       lea r8, [rsp + 0x4c]
00006b88 4903c4                           add rax, r12
00006b8b 488d542448                       lea rdx, [rsp + 0x48]
00006b90 488d4c2444                       lea rcx, [rsp + 0x44]
00006b95 4889442420                       mov qword ptr [rsp + 0x20], rax
00006b9a e831080100                       call 0x173d0
00006b9f f30f10542440                     movss xmm2, dword ptr [rsp + 0x40]
00006ba5 4c8d442430                       lea r8, [rsp + 0x30]
00006baa f30f104c2448                     movss xmm1, dword ptr [rsp + 0x48]
00006bb0 488d542434                       lea rdx, [rsp + 0x34]
00006bb5 0f28c2                           movaps xmm0, xmm2
00006bb8 f30f59ca                         mulss xmm1, xmm2
00006bbc 488d4c2438                       lea rcx, [rsp + 0x38]
00006bc1 f30f5944244c                     mulss xmm0, dword ptr [rsp + 0x4c]
00006bc7 f30f114c2434                     movss dword ptr [rsp + 0x34], xmm1
00006bcd f30f11442430                     movss dword ptr [rsp + 0x30], xmm0
00006bd3 f30f10442444                     movss xmm0, dword ptr [rsp + 0x44]
00006bd9 f30f59c2                         mulss xmm0, xmm2
00006bdd f30f11442438                     movss dword ptr [rsp + 0x38], xmm0
00006be3 e8484a0000                       call 0xb630
00006be8 eb03                             jmp 0x6bed
00006bea 0f57c0                           xorps xmm0, xmm0
00006bed f30f104b3c                       movss xmm1, dword ptr [rbx + 0x3c]
00006bf2 ffc7                             inc edi
00006bf4 0f28d1                           movaps xmm2, xmm1
00006bf7 f30f59d0                         mulss xmm2, xmm0
00006bfb 0f28c6                           movaps xmm0, xmm6
00006bfe f30f5cc1                         subss xmm0, xmm1
00006c02 f30f58d0                         addss xmm2, xmm0
00006c06 f30f595500                       mulss xmm2, dword ptr [rbp]
00006c0b 4883c504                         add rbp, 4
00006c0f f3410f1116                       movss dword ptr [r14], xmm2
00006c14 4983c604                         add r14, 4
00006c18 488b4308                         mov rax, qword ptr [rbx + 8]
00006c1c 4c8bc0                           mov r8, rax
00006c1f 3b7824                           cmp edi, dword ptr [rax + 0x24]
00006c22 0f8c28ffffff                     jl 0x6b50
00006c28 41ffc7                           inc r15d
00006c2b 4c8bc0                           mov r8, rax
00006c2e 443b7828                         cmp r15d, dword ptr [rax + 0x28]
00006c32 0f8cc8feffff                     jl 0x6b00
00006c38 4c8ba424a8000000                 mov r12, qword ptr [rsp + 0xa8]
00006c40 e9a5000000                       jmp 0x6cea
00006c45 4c8b4108                         mov r8, qword ptr [rcx + 8]
00006c49 33f6                             xor esi, esi
00006c4b 41397028                         cmp dword ptr [r8 + 0x28], esi
00006c4f 0f8e95000000                     jle 0x6cea
00006c55 f30f103577a60100                 movss xmm6, dword ptr [rip + 0x1a677]
00006c5d 0f1f00                           nop dword ptr [rax]
00006c60 418b5024                         mov edx, dword ptr [r8 + 0x24]
00006c64 33ff                             xor edi, edi
00006c66 8bc2                             mov eax, edx
00006c68 0fafc6                           imul eax, esi
00006c6b 4863c8                           movsxd rcx, eax
00006c6e 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
00006c75 488d2c88                         lea rbp, [rax + rcx*4]
00006c79 488b8390000000                   mov rax, qword ptr [rbx + 0x90]
00006c80 4c8d3488                         lea r14, [rax + rcx*4]
00006c84 85d2                             test edx, edx
00006c86 7e56                             jle 0x6cde
00006c88 0f1f840000000000                 nop dword ptr [rax + rax]
00006c90 440fb68bf8000000                 movzx r9d, byte ptr [rbx + 0xf8]
00006c98 488d8bb0000000                   lea rcx, [rbx + 0xb0]
00006c9f 448bc6                           mov r8d, esi
00006ca2 8bd7                             mov edx, edi
00006ca4 e8d7290000                       call 0x9680
00006ca9 f30f10533c                       movss xmm2, dword ptr [rbx + 0x3c]
00006cae 0f28ce                           movaps xmm1, xmm6
00006cb1 0f28da                           movaps xmm3, xmm2
00006cb4 f30f5cca                         subss xmm1, xmm2
00006cb8 f30f59d8                         mulss xmm3, xmm0
00006cbc ffc7                             inc edi
00006cbe f30f58d9                         addss xmm3, xmm1
00006cc2 f30f595d00                       mulss xmm3, dword ptr [rbp]
00006cc7 4883c504                         add rbp, 4
00006ccb f3410f111e                       movss dword ptr [r14], xmm3
00006cd0 4983c604                         add r14, 4
00006cd4 4c8b4308                         mov r8, qword ptr [rbx + 8]
00006cd8 413b7824                         cmp edi, dword ptr [r8 + 0x24]
00006cdc 7cb2                             jl 0x6c90
00006cde ffc6                             inc esi
00006ce0 413b7028                         cmp esi, dword ptr [r8 + 0x28]
00006ce4 0f8c76ffffff                     jl 0x6c60
00006cea 488b4c2450                       mov rcx, qword ptr [rsp + 0x50]
00006cef 4833cc                           xor rcx, rsp
00006cf2 e8c9630100                       call 0x1d0c0
00006cf7 488b9c24b0000000                 mov rbx, qword ptr [rsp + 0xb0]
00006cff 0f28742460                       movaps xmm6, xmmword ptr [rsp + 0x60]
00006d04 4883c470                         add rsp, 0x70
00006d08 415f                             pop r15
00006d0a 415e                             pop r14
00006d0c 5f                               pop rdi
00006d0d 5e                               pop rsi
00006d0e 5d                               pop rbp
00006d0f c3                               ret 
00006d10 48895c2410                       mov qword ptr [rsp + 0x10], rbx
00006d15 55                               push rbp
00006d16 56                               push rsi
00006d17 57                               push rdi
00006d18 4154                             push r12
00006d1a 4155                             push r13
00006d1c 4156                             push r14
00006d1e 4157                             push r15
00006d20 488dac24f035fcff                 lea rbp, [rsp - 0x3ca10]
00006d28 b810cb0300                       mov eax, 0x3cb10
00006d2d e8be620100                       call 0x1cff0
00006d32 482be0                           sub rsp, rax
00006d35 0f29b42400cb0300                 movaps xmmword ptr [rsp + 0x3cb00], xmm6
00006d3d 0f29bc24f0ca0300                 movaps xmmword ptr [rsp + 0x3caf0], xmm7
00006d45 440f298424e0ca0300               movaps xmmword ptr [rsp + 0x3cae0], xmm8
00006d4e 440f298c24d0ca0300               movaps xmmword ptr [rsp + 0x3cad0], xmm9
00006d57 440f299424c0ca0300               movaps xmmword ptr [rsp + 0x3cac0], xmm10
00006d60 440f299c24b0ca0300               movaps xmmword ptr [rsp + 0x3cab0], xmm11
00006d69 488b0508440200                   mov rax, qword ptr [rip + 0x24408]
00006d70 4833c4                           xor rax, rsp
00006d73 488985a0c90300                   mov qword ptr [rbp + 0x3c9a0], rax
00006d7a 4d8be9                           mov r13, r9
00006d7d 4d8bf8                           mov r15, r8
00006d80 488bf9                           mov rdi, rcx
00006d83 48894c2448                       mov qword ptr [rsp + 0x48], rcx
00006d88 488b9d70ca0300                   mov rbx, qword ptr [rbp + 0x3ca70]
00006d8f 488b81b0000000                   mov rax, qword ptr [rcx + 0xb0]
00006d96 4c8b5040                         mov r10, qword ptr [rax + 0x40]
00006d9a 48c744242000000000               mov qword ptr [rsp + 0x20], 0
00006da3 4533c9                           xor r9d, r9d
00006da6 4d8bc5                           mov r8, r13
00006da9 498bd7                           mov rdx, r15
00006dac 488b89b8000000                   mov rcx, qword ptr [rcx + 0xb8]
00006db3 41ffd2                           call r10
00006db6 8bc8                             mov ecx, eax
00006db8 e823a00000                       call 0x10de0
00006dbd 48893b                           mov qword ptr [rbx], rdi
00006dc0 4c897b08                         mov qword ptr [rbx + 8], r15
00006dc4 4c896b10                         mov qword ptr [rbx + 0x10], r13
00006dc8 66410f6e4768                     movd xmm0, dword ptr [r15 + 0x68]
00006dce f30fe6c0                         cvtdq2pd xmm0, xmm0
00006dd2 f20f106328                       movsd xmm4, qword ptr [rbx + 0x28]
00006dd7 f20f5ce0                         subsd xmm4, xmm0
00006ddb f20f116328                       movsd qword ptr [rbx + 0x28], xmm4
00006de0 66410f6e476c                     movd xmm0, dword ptr [r15 + 0x6c]
00006de6 f30fe6c0                         cvtdq2pd xmm0, xmm0
00006dea f20f105b30                       movsd xmm3, qword ptr [rbx + 0x30]
00006def f20f5cd8                         subsd xmm3, xmm0
00006df3 f20f115b30                       movsd qword ptr [rbx + 0x30], xmm3
00006df8 660f6e8f1c010000                 movd xmm1, dword ptr [rdi + 0x11c]
00006e00 0f5bc9                           cvtdq2ps xmm1, xmm1
00006e03 8b8720010000                     mov eax, dword ptr [rdi + 0x120]
00006e09 0f57c0                           xorps xmm0, xmm0
00006e0c f3480f2ac0                       cvtsi2ss xmm0, rax
00006e11 f30f5ec8                         divss xmm1, xmm0
00006e15 f30f114b48                       movss dword ptr [rbx + 0x48], xmm1
00006e1a 0f28c1                           movaps xmm0, xmm1
00006e1d f30f598304010000                 mulss xmm0, dword ptr [rbx + 0x104]
00006e25 f30f118304010000                 movss dword ptr [rbx + 0x104], xmm0
00006e2d 0f5ad1                           cvtps2pd xmm2, xmm1
00006e30 0f28ca                           movaps xmm1, xmm2
00006e33 f20f59cc                         mulsd xmm1, xmm4
00006e37 f20f114b28                       movsd qword ptr [rbx + 0x28], xmm1
00006e3c f20f59d3                         mulsd xmm2, xmm3
00006e40 f20f115330                       movsd qword ptr [rbx + 0x30], xmm2
00006e45 837b6400                         cmp dword ptr [rbx + 0x64], 0
00006e49 7522                             jne 0x6e6d
00006e4b 837b5800                         cmp dword ptr [rbx + 0x58], 0
00006e4f 751c                             jne 0x6e6d
00006e51 837b6800                         cmp dword ptr [rbx + 0x68], 0
00006e55 7516                             jne 0x6e6d
00006e57 837b6000                         cmp dword ptr [rbx + 0x60], 0
00006e5b 7510                             jne 0x6e6d
00006e5d 837b7000                         cmp dword ptr [rbx + 0x70], 0
00006e61 750a                             jne 0x6e6d
00006e63 837b6c00                         cmp dword ptr [rbx + 0x6c], 0
00006e67 0f8466060000                     je 0x74d3
00006e6d 418b5728                         mov edx, dword ptr [r15 + 0x28]
00006e71 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00006e76 c1e202                           shl edx, 2
00006e79 488bcf                           mov rcx, rdi
00006e7c e81fd7ffff                       call 0x45a0
00006e81 4889442458                       mov qword ptr [rsp + 0x58], rax
00006e86 488bd0                           mov rdx, rax
00006e89 488bcf                           mov rcx, rdi
00006e8c e82fd5ffff                       call 0x43c0
00006e91 48898398000000                   mov qword ptr [rbx + 0x98], rax
00006e98 418b5728                         mov edx, dword ptr [r15 + 0x28]
00006e9c 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00006ea1 c1e202                           shl edx, 2
00006ea4 488bcf                           mov rcx, rdi
00006ea7 e8f4d6ffff                       call 0x45a0
00006eac 4889442460                       mov qword ptr [rsp + 0x60], rax
00006eb1 488bd0                           mov rdx, rax
00006eb4 488bcf                           mov rcx, rdi
00006eb7 e804d5ffff                       call 0x43c0
00006ebc 488983a0000000                   mov qword ptr [rbx + 0xa0], rax
00006ec3 418b5728                         mov edx, dword ptr [r15 + 0x28]
00006ec7 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00006ecc 488bcf                           mov rcx, rdi
00006ecf e8ccd6ffff                       call 0x45a0
00006ed4 488bd0                           mov rdx, rax
00006ed7 488bcf                           mov rcx, rdi
00006eda e8e1d4ffff                       call 0x43c0
00006edf 48898388000000                   mov qword ptr [rbx + 0x88], rax
00006ee6 418b5728                         mov edx, dword ptr [r15 + 0x28]
00006eea 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00006eef 488bcf                           mov rcx, rdi
00006ef2 e8a9d6ffff                       call 0x45a0
00006ef7 4889442468                       mov qword ptr [rsp + 0x68], rax
00006efc 488bd0                           mov rdx, rax
00006eff 488bcf                           mov rcx, rdi
00006f02 e8b9d4ffff                       call 0x43c0
00006f07 48898390000000                   mov qword ptr [rbx + 0x90], rax
00006f0e 488b4b08                         mov rcx, qword ptr [rbx + 8]
00006f12 8b5128                           mov edx, dword ptr [rcx + 0x28]
00006f15 0faf5124                         imul edx, dword ptr [rcx + 0x24]
00006f19 488bcf                           mov rcx, rdi
00006f1c e8dfd5ffff                       call 0x4500
00006f21 4889442470                       mov qword ptr [rsp + 0x70], rax
00006f26 488bd0                           mov rdx, rax
00006f29 488bcf                           mov rcx, rdi
00006f2c e8efd3ffff                       call 0x4320
00006f31 488bf0                           mov rsi, rax
00006f34 4889442450                       mov qword ptr [rsp + 0x50], rax
00006f39 488b4b08                         mov rcx, qword ptr [rbx + 8]
00006f3d 8b5128                           mov edx, dword ptr [rcx + 0x28]
00006f40 0faf5124                         imul edx, dword ptr [rcx + 0x24]
00006f44 488bcf                           mov rcx, rdi
00006f47 e854d6ffff                       call 0x45a0
00006f4c 4889442478                       mov qword ptr [rsp + 0x78], rax
00006f51 488bd0                           mov rdx, rax
00006f54 488bcf                           mov rcx, rdi
00006f57 e864d4ffff                       call 0x43c0
00006f5c 48898308010000                   mov qword ptr [rbx + 0x108], rax
00006f63 4533c0                           xor r8d, r8d
00006f66 458be0                           mov r12d, r8d
00006f69 458b4f28                         mov r9d, dword ptr [r15 + 0x28]
00006f6d 4585c9                           test r9d, r9d
00006f70 0f8ee2000000                     jle 0x7058
00006f76 418b5724                         mov edx, dword ptr [r15 + 0x24]
00006f7a 660f1f440000                     nop word ptr [rax + rax]
00006f80 8bc2                             mov eax, edx
00006f82 410fafc4                         imul eax, r12d
00006f86 c1e002                           shl eax, 2
00006f89 4863c8                           movsxd rcx, eax
00006f8c 488b8398000000                   mov rax, qword ptr [rbx + 0x98]
00006f93 488d3c88                         lea rdi, [rax + rcx*4]
00006f97 488b83a0000000                   mov rax, qword ptr [rbx + 0xa0]
00006f9e 488d3488                         lea rsi, [rax + rcx*4]
00006fa2 418bc4                           mov eax, r12d
00006fa5 410faf4720                       imul eax, dword ptr [r15 + 0x20]
00006faa 4863c8                           movsxd rcx, eax
00006fad 49034f18                         add rcx, qword ptr [r15 + 0x18]
00006fb1 48894c2440                       mov qword ptr [rsp + 0x40], rcx
00006fb6 458bf0                           mov r14d, r8d
00006fb9 85d2                             test edx, edx
00006fbb 0f8e7d000000                     jle 0x703e
00006fc1 4c8d4c2440                       lea r9, [rsp + 0x40]
00006fc6 458bc4                           mov r8d, r12d
00006fc9 418bd6                           mov edx, r14d
00006fcc 498bcf                           mov rcx, r15
00006fcf e8bc020100                       call 0x17290
00006fd4 488b442440                       mov rax, qword ptr [rsp + 0x40]
00006fd9 4889442420                       mov qword ptr [rsp + 0x20], rax
00006fde 4c8d4d80                         lea r9, [rbp - 0x80]
00006fe2 4c8d458c                         lea r8, [rbp - 0x74]
00006fe6 488d5588                         lea rdx, [rbp - 0x78]
00006fea 488d4d84                         lea rcx, [rbp - 0x7c]
00006fee e86d030100                       call 0x17360
00006ff3 f30f104584                       movss xmm0, dword ptr [rbp - 0x7c]
00006ff8 f30f1107                         movss dword ptr [rdi], xmm0
00006ffc f30f104d88                       movss xmm1, dword ptr [rbp - 0x78]
00007001 f30f114f04                       movss dword ptr [rdi + 4], xmm1
00007006 f30f10458c                       movss xmm0, dword ptr [rbp - 0x74]
0000700b f30f114708                       movss dword ptr [rdi + 8], xmm0
00007010 f30f104d80                       movss xmm1, dword ptr [rbp - 0x80]
00007015 f30f114f0c                       movss dword ptr [rdi + 0xc], xmm1
0000701a 4533c0                           xor r8d, r8d
0000701d 4c8906                           mov qword ptr [rsi], r8
00007020 4c894608                         mov qword ptr [rsi + 8], r8
00007024 41ffc6                           inc r14d
00007027 488d7f10                         lea rdi, [rdi + 0x10]
0000702b 488d7610                         lea rsi, [rsi + 0x10]
0000702f 488344244008                     add qword ptr [rsp + 0x40], 8
00007035 418b5724                         mov edx, dword ptr [r15 + 0x24]
00007039 443bf2                           cmp r14d, edx
0000703c 7c83                             jl 0x6fc1
0000703e 41ffc4                           inc r12d
00007041 458b4f28                         mov r9d, dword ptr [r15 + 0x28]
00007045 453be1                           cmp r12d, r9d
00007048 0f8c32ffffff                     jl 0x6f80
0000704e 488b7c2448                       mov rdi, qword ptr [rsp + 0x48]
00007053 488b742450                       mov rsi, qword ptr [rsp + 0x50]
00007058 837b5003                         cmp dword ptr [rbx + 0x50], 3
0000705c 0f85a7000000                     jne 0x7109
00007062 f30f105348                       movss xmm2, dword ptr [rbx + 0x48]
00007067 660f6e8f00010000                 movd xmm1, dword ptr [rdi + 0x100]
0000706f 0f5bc9                           cvtdq2ps xmm1, xmm1
00007072 f30f59ca                         mulss xmm1, xmm2
00007076 f30f2cc9                         cvttss2si ecx, xmm1
0000707a 81f900000080                     cmp ecx, 0x80000000
00007080 7421                             je 0x70a3
00007082 660f6ec1                         movd xmm0, ecx
00007086 0f5bc0                           cvtdq2ps xmm0, xmm0
00007089 0f2ec1                           ucomiss xmm0, xmm1
0000708c 7415                             je 0x70a3
0000708e 0f14c9                           unpcklps xmm1, xmm1
00007091 0f50c1                           movmskps eax, xmm1
00007094 83e001                           and eax, 1
00007097 83f001                           xor eax, 1
0000709a 03c8                             add ecx, eax
0000709c 660f6ec9                         movd xmm1, ecx
000070a0 0f5bc9                           cvtdq2ps xmm1, xmm1
000070a3 488b93a8000000                   mov rdx, qword ptr [rbx + 0xa8]
000070aa 660f6e4228                       movd xmm0, dword ptr [rdx + 0x28]
000070af 0f5bc0                           cvtdq2ps xmm0, xmm0
000070b2 0f2ec1                           ucomiss xmm0, xmm1
000070b5 7549                             jne 0x7100
000070b7 660f6e8ffc000000                 movd xmm1, dword ptr [rdi + 0xfc]
000070bf 0f5bc9                           cvtdq2ps xmm1, xmm1
000070c2 f30f59ca                         mulss xmm1, xmm2
000070c6 f30f2cc9                         cvttss2si ecx, xmm1
000070ca 81f900000080                     cmp ecx, 0x80000000
000070d0 7421                             je 0x70f3
000070d2 660f6ec1                         movd xmm0, ecx
000070d6 0f5bc0                           cvtdq2ps xmm0, xmm0
000070d9 0f2ec1                           ucomiss xmm0, xmm1
000070dc 7415                             je 0x70f3
000070de 0f14c9                           unpcklps xmm1, xmm1
000070e1 0f50c1                           movmskps eax, xmm1
000070e4 83e001                           and eax, 1
000070e7 83f001                           xor eax, 1
000070ea 03c8                             add ecx, eax
000070ec 660f6ec9                         movd xmm1, ecx
000070f0 0f5bc9                           cvtdq2ps xmm1, xmm1
000070f3 660f6e4224                       movd xmm0, dword ptr [rdx + 0x24]
000070f8 0f5bc0                           cvtdq2ps xmm0, xmm0
000070fb 0f2ec1                           ucomiss xmm0, xmm1
000070fe 744f                             je 0x714f
00007100 4c8983a8000000                   mov qword ptr [rbx + 0xa8], r8
00007107 eb46                             jmp 0x714f
00007109 488d8bb0000000                   lea rcx, [rbx + 0xb0]
00007110 8b83fc000000                     mov eax, dword ptr [rbx + 0xfc]
00007116 89442430                         mov dword ptr [rsp + 0x30], eax
0000711a f30f108300010000                 movss xmm0, dword ptr [rbx + 0x100]
00007122 f30f11442428                     movss dword ptr [rsp + 0x28], xmm0
00007128 f30f108b04010000                 movss xmm1, dword ptr [rbx + 0x104]
00007130 f30f114c2420                     movss dword ptr [rsp + 0x20], xmm1
00007136 458b4724                         mov r8d, dword ptr [r15 + 0x24]
0000713a 488bd7                           mov rdx, rdi
0000713d e83e220000                       call 0x9380
00007142 837b5001                         cmp dword ptr [rbx + 0x50], 1
00007146 0f94c0                           sete al
00007149 8883f8000000                     mov byte ptr [rbx + 0xf8], al
0000714f 4c8b4308                         mov r8, qword ptr [rbx + 8]
00007153 f3440f101d78a10100               movss xmm11, dword ptr [rip + 0x1a178]
0000715c 0f57f6                           xorps xmm6, xmm6
0000715f 807b4400                         cmp byte ptr [rbx + 0x44], 0
00007163 0f84a2000000                     je 0x720b
00007169 4533d2                           xor r10d, r10d
0000716c 45395028                         cmp dword ptr [r8 + 0x28], r10d
00007170 7e64                             jle 0x71d6
00007172 0f1f4000                         nop dword ptr [rax]
00007176 66660f1f840000000000             nop word ptr [rax + rax]
00007180 418b4824                         mov ecx, dword ptr [r8 + 0x24]
00007184 8bc1                             mov eax, ecx
00007186 410fafc2                         imul eax, r10d
0000718a 4863d0                           movsxd rdx, eax
0000718d 4803d6                           add rdx, rsi
00007190 8d048500000000                   lea eax, [rax*4]
00007197 4c63d8                           movsxd r11, eax
0000719a 488b8398000000                   mov rax, qword ptr [rbx + 0x98]
000071a1 4533c9                           xor r9d, r9d
000071a4 85c9                             test ecx, ecx
000071a6 7e25                             jle 0x71cd
000071a8 488d480c                         lea rcx, [rax + 0xc]
000071ac 4a8d0c99                         lea rcx, [rcx + r11*4]
000071b0 0f2f31                           comiss xmm6, dword ptr [rcx]
000071b3 0f92c0                           setb al
000071b6 8802                             mov byte ptr [rdx], al
000071b8 41ffc1                           inc r9d
000071bb 488d5201                         lea rdx, [rdx + 1]
000071bf 488d4910                         lea rcx, [rcx + 0x10]
000071c3 4c8b4308                         mov r8, qword ptr [rbx + 8]
000071c7 453b4824                         cmp r9d, dword ptr [r8 + 0x24]
000071cb 7ce3                             jl 0x71b0
000071cd 41ffc2                           inc r10d
000071d0 453b5028                         cmp r10d, dword ptr [r8 + 0x28]
000071d4 7caa                             jl 0x7180
000071d6 48897d80                         mov qword ptr [rbp - 0x80], rdi
000071da 48c7458800000000                 mov qword ptr [rbp - 0x78], 0
000071e2 418b4028                         mov eax, dword ptr [r8 + 0x28]
000071e6 89442420                         mov dword ptr [rsp + 0x20], eax
000071ea 458b4824                         mov r9d, dword ptr [r8 + 0x24]
000071ee 4c8b8308010000                   mov r8, qword ptr [rbx + 0x108]
000071f5 488bd6                           mov rdx, rsi
000071f8 488d4d80                         lea rcx, [rbp - 0x80]
000071fc e82f170000                       call 0x8930
00007201 660f6e458c                       movd xmm0, dword ptr [rbp - 0x74]
00007206 0f5bc0                           cvtdq2ps xmm0, xmm0
00007209 eb26                             jmp 0x7231
0000720b c74424400000803f                 mov dword ptr [rsp + 0x40], 0x3f800000
00007213 418b5024                         mov edx, dword ptr [r8 + 0x24]
00007217 410faf5028                       imul edx, dword ptr [r8 + 0x28]
0000721c 4c8d442440                       lea r8, [rsp + 0x40]
00007221 488b8b08010000                   mov rcx, qword ptr [rbx + 0x108]
00007228 e8d3f2ffff                       call 0x6500
0000722d 410f28c3                         movaps xmm0, xmm11
00007231 f30f11434c                       movss dword ptr [rbx + 0x4c], xmm0
00007236 4533d2                           xor r10d, r10d
00007239 4c8b4b08                         mov r9, qword ptr [rbx + 8]
0000723d 45395128                         cmp dword ptr [r9 + 0x28], r10d
00007241 0f8e84000000                     jle 0x72cb
00007247 660f1f840000000000               nop word ptr [rax + rax]
00007250 458b5924                         mov r11d, dword ptr [r9 + 0x24]
00007254 418bc3                           mov eax, r11d
00007257 410fafc2                         imul eax, r10d
0000725b 4863c8                           movsxd rcx, eax
0000725e 488b8308010000                   mov rax, qword ptr [rbx + 0x108]
00007265 488d1488                         lea rdx, [rax + rcx*4]
00007269 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
00007270 4c8d0488                         lea r8, [rax + rcx*4]
00007274 410f28db                         movaps xmm3, xmm11
00007278 f30f10434c                       movss xmm0, dword ptr [rbx + 0x4c]
0000727d 0f2fc6                           comiss xmm0, xmm6
00007280 7604                             jbe 0x7286
00007282 f30f5ed8                         divss xmm3, xmm0
00007286 33c0                             xor eax, eax
00007288 4585db                           test r11d, r11d
0000728b 7e35                             jle 0x72c2
0000728d 0f1f00                           nop dword ptr [rax]
00007290 0f28d3                           movaps xmm2, xmm3
00007293 f30f5912                         mulss xmm2, dword ptr [rdx]
00007297 f30f595340                       mulss xmm2, dword ptr [rbx + 0x40]
0000729c 410f28c3                         movaps xmm0, xmm11
000072a0 f30f5c4340                       subss xmm0, dword ptr [rbx + 0x40]
000072a5 f30f58d0                         addss xmm2, xmm0
000072a9 f3410f1110                       movss dword ptr [r8], xmm2
000072ae ffc0                             inc eax
000072b0 4883c204                         add rdx, 4
000072b4 4983c004                         add r8, 4
000072b8 4c8b4b08                         mov r9, qword ptr [rbx + 8]
000072bc 413b4124                         cmp eax, dword ptr [r9 + 0x24]
000072c0 7cce                             jl 0x7290
000072c2 41ffc2                           inc r10d
000072c5 453b5128                         cmp r10d, dword ptr [r9 + 0x28]
000072c9 7c85                             jl 0x7250
000072cb 488bcb                           mov rcx, rbx
000072ce e8edf2ffff                       call 0x65c0
000072d3 8b4320                           mov eax, dword ptr [rbx + 0x20]
000072d6 83f801                           cmp eax, 1
000072d9 7533                             jne 0x730e
000072db 488d4d40                         lea rcx, [rbp + 0x40]
000072df e8fc340000                       call 0xa7e0
000072e4 90                               nop 
000072e5 f30f108b80000000                 movss xmm1, dword ptr [rbx + 0x80]
000072ed 488d4d40                         lea rcx, [rbp + 0x40]
000072f1 e81a350000                       call 0xa810
000072f6 488bd3                           mov rdx, rbx
000072f9 488d4d40                         lea rcx, [rbp + 0x40]
000072fd e8eee3ffff                       call 0x56f0
00007302 90                               nop 
00007303 488d4d40                         lea rcx, [rbp + 0x40]
00007307 e8f4340000                       call 0xa800
0000730c eb36                             jmp 0x7344
0000730e 83f802                           cmp eax, 2
00007311 7531                             jne 0x7344
00007313 488d4d40                         lea rcx, [rbp + 0x40]
00007317 e874a7ffff                       call 0x1a90
0000731c 90                               nop 
0000731d f30f108b80000000                 movss xmm1, dword ptr [rbx + 0x80]
00007325 488d4d40                         lea rcx, [rbp + 0x40]
00007329 e892a7ffff                       call 0x1ac0
0000732e 488bd3                           mov rdx, rbx
00007331 488d4d40                         lea rcx, [rbp + 0x40]
00007335 e806d3ffff                       call 0x4640
0000733a 90                               nop 
0000733b 488d4d40                         lea rcx, [rbp + 0x40]
0000733f e86ca7ffff                       call 0x1ab0
00007344 4533f6                           xor r14d, r14d
00007347 45397528                         cmp dword ptr [r13 + 0x28], r14d
0000734b 0f8ede000000                     jle 0x742f
00007351 418b5524                         mov edx, dword ptr [r13 + 0x24]
00007355 6666660f1f840000000000           nop word ptr [rax + rax]
00007360 418bc6                           mov eax, r14d
00007363 0fafc2                           imul eax, edx
00007366 c1e002                           shl eax, 2
00007369 4863c8                           movsxd rcx, eax
0000736c 488b83a0000000                   mov rax, qword ptr [rbx + 0xa0]
00007373 488d3c88                         lea rdi, [rax + rcx*4]
00007377 418bc6                           mov eax, r14d
0000737a 410faf4520                       imul eax, dword ptr [r13 + 0x20]
0000737f 4863c8                           movsxd rcx, eax
00007382 49034d18                         add rcx, qword ptr [r13 + 0x18]
00007386 48894c2440                       mov qword ptr [rsp + 0x40], rcx
0000738b 33f6                             xor esi, esi
0000738d 85d2                             test edx, edx
0000738f 0f8e88000000                     jle 0x741d
00007395 6666660f1f840000000000           nop word ptr [rax + rax]
000073a0 f30f107338                       movss xmm6, dword ptr [rbx + 0x38]
000073a5 f3440f1017                       movss xmm10, dword ptr [rdi]
000073aa f3440f104f04                     movss xmm9, dword ptr [rdi + 4]
000073b0 f3440f104708                     movss xmm8, dword ptr [rdi + 8]
000073b6 f30f107f0c                       movss xmm7, dword ptr [rdi + 0xc]
000073bb 4c8d4c2440                       lea r9, [rsp + 0x40]
000073c0 458bc6                           mov r8d, r14d
000073c3 8bd6                             mov edx, esi
000073c5 498bcd                           mov rcx, r13
000073c8 e8c3fe0000                       call 0x17290
000073cd f3440f59c6                       mulss xmm8, xmm6
000073d2 f3450f5dc3                       minss xmm8, xmm11
000073d7 f3440f59ce                       mulss xmm9, xmm6
000073dc f3450f5dcb                       minss xmm9, xmm11
000073e1 f3440f59d6                       mulss xmm10, xmm6
000073e6 f3450f5dd3                       minss xmm10, xmm11
000073eb 488b442440                       mov rax, qword ptr [rsp + 0x40]
000073f0 4889442420                       mov qword ptr [rsp + 0x20], rax
000073f5 0f28df                           movaps xmm3, xmm7
000073f8 410f28d0                         movaps xmm2, xmm8
000073fc 410f28c9                         movaps xmm1, xmm9
00007400 410f28c2                         movaps xmm0, xmm10
00007404 e837000100                       call 0x17440
00007409 ffc6                             inc esi
0000740b 488d7f10                         lea rdi, [rdi + 0x10]
0000740f 488344244008                     add qword ptr [rsp + 0x40], 8
00007415 418b5524                         mov edx, dword ptr [r13 + 0x24]
00007419 3bf2                             cmp esi, edx
0000741b 7c83                             jl 0x73a0
0000741d 41ffc6                           inc r14d
00007420 453b7528                         cmp r14d, dword ptr [r13 + 0x28]
00007424 0f8c36ffffff                     jl 0x7360
0000742a 488b7c2448                       mov rdi, qword ptr [rsp + 0x48]
0000742f 488b542458                       mov rdx, qword ptr [rsp + 0x58]
00007434 488bcf                           mov rcx, rdi
00007437 e814110000                       call 0x8550
0000743c 488b542458                       mov rdx, qword ptr [rsp + 0x58]
00007441 488bcf                           mov rcx, rdi
00007444 e8a7110000                       call 0x85f0
00007449 488b542460                       mov rdx, qword ptr [rsp + 0x60]
0000744e 488bcf                           mov rcx, rdi
00007451 e8fa100000                       call 0x8550
00007456 488b542460                       mov rdx, qword ptr [rsp + 0x60]
0000745b 488bcf                           mov rcx, rdi
0000745e e88d110000                       call 0x85f0
00007463 488b542468                       mov rdx, qword ptr [rsp + 0x68]
00007468 488bcf                           mov rcx, rdi
0000746b e8e0100000                       call 0x8550
00007470 488b542468                       mov rdx, qword ptr [rsp + 0x68]
00007475 488bcf                           mov rcx, rdi
00007478 e873110000                       call 0x85f0
0000747d 488b542470                       mov rdx, qword ptr [rsp + 0x70]
00007482 488bcf                           mov rcx, rdi
00007485 e8c6100000                       call 0x8550
0000748a 488b542470                       mov rdx, qword ptr [rsp + 0x70]
0000748f 488bcf                           mov rcx, rdi
00007492 e859110000                       call 0x85f0
00007497 488b542478                       mov rdx, qword ptr [rsp + 0x78]
0000749c 488bcf                           mov rcx, rdi
0000749f e8ac100000                       call 0x8550
000074a4 488b542478                       mov rdx, qword ptr [rsp + 0x78]
000074a9 488bcf                           mov rcx, rdi
000074ac e83f110000                       call 0x85f0
000074b1 837b5003                         cmp dword ptr [rbx + 0x50], 3
000074b5 7510                             jne 0x74c7
000074b7 488d5590                         lea rdx, [rbp - 0x70]
000074bb 488b8fb8000000                   mov rcx, qword ptr [rdi + 0xb8]
000074c2 ff5708                           call qword ptr [rdi + 8]
000074c5 eb0c                             jmp 0x74d3
000074c7 488d8bb0000000                   lea rcx, [rbx + 0xb0]
000074ce e8dd220000                       call 0x97b0
000074d3 488b8da0c90300                   mov rcx, qword ptr [rbp + 0x3c9a0]
000074da 4833cc                           xor rcx, rsp
000074dd e8de5b0100                       call 0x1d0c0
000074e2 4c8d9c2410cb0300                 lea r11, [rsp + 0x3cb10]
000074ea 498b5b48                         mov rbx, qword ptr [r11 + 0x48]
000074ee 410f2873f0                       movaps xmm6, xmmword ptr [r11 - 0x10]
000074f3 410f287be0                       movaps xmm7, xmmword ptr [r11 - 0x20]
000074f8 450f2843d0                       movaps xmm8, xmmword ptr [r11 - 0x30]
000074fd 450f284bc0                       movaps xmm9, xmmword ptr [r11 - 0x40]
00007502 450f2853b0                       movaps xmm10, xmmword ptr [r11 - 0x50]
00007507 450f285ba0                       movaps xmm11, xmmword ptr [r11 - 0x60]
0000750c 498be3                           mov rsp, r11
0000750f 415f                             pop r15
00007511 415e                             pop r14
00007513 415d                             pop r13
00007515 415c                             pop r12
00007517 5f                               pop rdi
00007518 5e                               pop rsi
00007519 5d                               pop rbp
0000751a c3                               ret 
0000751b cc                               int3 
0000751c cc                               int3 
0000751d cc                               int3 
0000751e cc                               int3 
0000751f cc                               int3 
00007520 48895c2410                       mov qword ptr [rsp + 0x10], rbx
00007525 55                               push rbp
00007526 56                               push rsi
00007527 57                               push rdi
00007528 4154                             push r12
0000752a 4155                             push r13
0000752c 4156                             push r14
0000752e 4157                             push r15
00007530 488dac24f035fcff                 lea rbp, [rsp - 0x3ca10]
00007538 b810cb0300                       mov eax, 0x3cb10
0000753d e8ae5a0100                       call 0x1cff0
00007542 482be0                           sub rsp, rax
00007545 0f29b42400cb0300                 movaps xmmword ptr [rsp + 0x3cb00], xmm6
0000754d 0f29bc24f0ca0300                 movaps xmmword ptr [rsp + 0x3caf0], xmm7
00007555 440f298424e0ca0300               movaps xmmword ptr [rsp + 0x3cae0], xmm8
0000755e 440f298c24d0ca0300               movaps xmmword ptr [rsp + 0x3cad0], xmm9
00007567 440f299424c0ca0300               movaps xmmword ptr [rsp + 0x3cac0], xmm10
00007570 440f299c24b0ca0300               movaps xmmword ptr [rsp + 0x3cab0], xmm11
00007579 488b05f83b0200                   mov rax, qword ptr [rip + 0x23bf8]
00007580 4833c4                           xor rax, rsp
00007583 488985a0c90300                   mov qword ptr [rbp + 0x3c9a0], rax
0000758a 4d8be9                           mov r13, r9
0000758d 4d8bf8                           mov r15, r8
00007590 488bf9                           mov rdi, rcx
00007593 48894c2448                       mov qword ptr [rsp + 0x48], rcx
00007598 488b9d70ca0300                   mov rbx, qword ptr [rbp + 0x3ca70]
0000759f 488b81b0000000                   mov rax, qword ptr [rcx + 0xb0]
000075a6 4c8b5040                         mov r10, qword ptr [rax + 0x40]
000075aa 48c744242000000000               mov qword ptr [rsp + 0x20], 0
000075b3 4533c9                           xor r9d, r9d
000075b6 4d8bc5                           mov r8, r13
000075b9 498bd7                           mov rdx, r15
000075bc 488b89b8000000                   mov rcx, qword ptr [rcx + 0xb8]
000075c3 41ffd2                           call r10
000075c6 8bc8                             mov ecx, eax
000075c8 e813980000                       call 0x10de0
000075cd 48893b                           mov qword ptr [rbx], rdi
000075d0 4c897b08                         mov qword ptr [rbx + 8], r15
000075d4 4c896b10                         mov qword ptr [rbx + 0x10], r13
000075d8 66410f6e4768                     movd xmm0, dword ptr [r15 + 0x68]
000075de f30fe6c0                         cvtdq2pd xmm0, xmm0
000075e2 f20f106328                       movsd xmm4, qword ptr [rbx + 0x28]
000075e7 f20f5ce0                         subsd xmm4, xmm0
000075eb f20f116328                       movsd qword ptr [rbx + 0x28], xmm4
000075f0 66410f6e476c                     movd xmm0, dword ptr [r15 + 0x6c]
000075f6 f30fe6c0                         cvtdq2pd xmm0, xmm0
000075fa f20f105b30                       movsd xmm3, qword ptr [rbx + 0x30]
000075ff f20f5cd8                         subsd xmm3, xmm0
00007603 f20f115b30                       movsd qword ptr [rbx + 0x30], xmm3
00007608 660f6e8f1c010000                 movd xmm1, dword ptr [rdi + 0x11c]
00007610 0f5bc9                           cvtdq2ps xmm1, xmm1
00007613 8b8720010000                     mov eax, dword ptr [rdi + 0x120]
00007619 0f57c0                           xorps xmm0, xmm0
0000761c f3480f2ac0                       cvtsi2ss xmm0, rax
00007621 f30f5ec8                         divss xmm1, xmm0
00007625 f30f114b48                       movss dword ptr [rbx + 0x48], xmm1
0000762a 0f28c1                           movaps xmm0, xmm1
0000762d f30f598304010000                 mulss xmm0, dword ptr [rbx + 0x104]
00007635 f30f118304010000                 movss dword ptr [rbx + 0x104], xmm0
0000763d 0f5ad1                           cvtps2pd xmm2, xmm1
00007640 0f28ca                           movaps xmm1, xmm2
00007643 f20f59cc                         mulsd xmm1, xmm4
00007647 f20f114b28                       movsd qword ptr [rbx + 0x28], xmm1
0000764c f20f59d3                         mulsd xmm2, xmm3
00007650 f20f115330                       movsd qword ptr [rbx + 0x30], xmm2
00007655 837b6400                         cmp dword ptr [rbx + 0x64], 0
00007659 7522                             jne 0x767d
0000765b 837b5800                         cmp dword ptr [rbx + 0x58], 0
0000765f 751c                             jne 0x767d
00007661 837b6800                         cmp dword ptr [rbx + 0x68], 0
00007665 7516                             jne 0x767d
00007667 837b6000                         cmp dword ptr [rbx + 0x60], 0
0000766b 7510                             jne 0x767d
0000766d 837b7000                         cmp dword ptr [rbx + 0x70], 0
00007671 750a                             jne 0x767d
00007673 837b6c00                         cmp dword ptr [rbx + 0x6c], 0
00007677 0f8466060000                     je 0x7ce3
0000767d 418b5728                         mov edx, dword ptr [r15 + 0x28]
00007681 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00007686 c1e202                           shl edx, 2
00007689 488bcf                           mov rcx, rdi
0000768c e80fcfffff                       call 0x45a0
00007691 4889442458                       mov qword ptr [rsp + 0x58], rax
00007696 488bd0                           mov rdx, rax
00007699 488bcf                           mov rcx, rdi
0000769c e81fcdffff                       call 0x43c0
000076a1 48898398000000                   mov qword ptr [rbx + 0x98], rax
000076a8 418b5728                         mov edx, dword ptr [r15 + 0x28]
000076ac 410faf5724                       imul edx, dword ptr [r15 + 0x24]
000076b1 c1e202                           shl edx, 2
000076b4 488bcf                           mov rcx, rdi
000076b7 e8e4ceffff                       call 0x45a0
000076bc 4889442460                       mov qword ptr [rsp + 0x60], rax
000076c1 488bd0                           mov rdx, rax
000076c4 488bcf                           mov rcx, rdi
000076c7 e8f4ccffff                       call 0x43c0
000076cc 488983a0000000                   mov qword ptr [rbx + 0xa0], rax
000076d3 418b5728                         mov edx, dword ptr [r15 + 0x28]
000076d7 410faf5724                       imul edx, dword ptr [r15 + 0x24]
000076dc 488bcf                           mov rcx, rdi
000076df e8bcceffff                       call 0x45a0
000076e4 488bd0                           mov rdx, rax
000076e7 488bcf                           mov rcx, rdi
000076ea e8d1ccffff                       call 0x43c0
000076ef 48898388000000                   mov qword ptr [rbx + 0x88], rax
000076f6 418b5728                         mov edx, dword ptr [r15 + 0x28]
000076fa 410faf5724                       imul edx, dword ptr [r15 + 0x24]
000076ff 488bcf                           mov rcx, rdi
00007702 e899ceffff                       call 0x45a0
00007707 4889442468                       mov qword ptr [rsp + 0x68], rax
0000770c 488bd0                           mov rdx, rax
0000770f 488bcf                           mov rcx, rdi
00007712 e8a9ccffff                       call 0x43c0
00007717 48898390000000                   mov qword ptr [rbx + 0x90], rax
0000771e 488b4b08                         mov rcx, qword ptr [rbx + 8]
00007722 8b5128                           mov edx, dword ptr [rcx + 0x28]
00007725 0faf5124                         imul edx, dword ptr [rcx + 0x24]
00007729 488bcf                           mov rcx, rdi
0000772c e8cfcdffff                       call 0x4500
00007731 4889442470                       mov qword ptr [rsp + 0x70], rax
00007736 488bd0                           mov rdx, rax
00007739 488bcf                           mov rcx, rdi
0000773c e8dfcbffff                       call 0x4320
00007741 488bf0                           mov rsi, rax
00007744 4889442450                       mov qword ptr [rsp + 0x50], rax
00007749 488b4b08                         mov rcx, qword ptr [rbx + 8]
0000774d 8b5128                           mov edx, dword ptr [rcx + 0x28]
00007750 0faf5124                         imul edx, dword ptr [rcx + 0x24]
00007754 488bcf                           mov rcx, rdi
00007757 e844ceffff                       call 0x45a0
0000775c 4889442478                       mov qword ptr [rsp + 0x78], rax
00007761 488bd0                           mov rdx, rax
00007764 488bcf                           mov rcx, rdi
00007767 e854ccffff                       call 0x43c0
0000776c 48898308010000                   mov qword ptr [rbx + 0x108], rax
00007773 4533c0                           xor r8d, r8d
00007776 458be0                           mov r12d, r8d
00007779 458b4f28                         mov r9d, dword ptr [r15 + 0x28]
0000777d 4585c9                           test r9d, r9d
00007780 0f8ee2000000                     jle 0x7868
00007786 418b5724                         mov edx, dword ptr [r15 + 0x24]
0000778a 660f1f440000                     nop word ptr [rax + rax]
00007790 8bc2                             mov eax, edx
00007792 410fafc4                         imul eax, r12d
00007796 c1e002                           shl eax, 2
00007799 4863c8                           movsxd rcx, eax
0000779c 488b8398000000                   mov rax, qword ptr [rbx + 0x98]
000077a3 488d3c88                         lea rdi, [rax + rcx*4]
000077a7 488b83a0000000                   mov rax, qword ptr [rbx + 0xa0]
000077ae 488d3488                         lea rsi, [rax + rcx*4]
000077b2 418bc4                           mov eax, r12d
000077b5 410faf4720                       imul eax, dword ptr [r15 + 0x20]
000077ba 4863c8                           movsxd rcx, eax
000077bd 49034f18                         add rcx, qword ptr [r15 + 0x18]
000077c1 48894c2440                       mov qword ptr [rsp + 0x40], rcx
000077c6 458bf0                           mov r14d, r8d
000077c9 85d2                             test edx, edx
000077cb 0f8e7d000000                     jle 0x784e
000077d1 4c8d4c2440                       lea r9, [rsp + 0x40]
000077d6 458bc4                           mov r8d, r12d
000077d9 418bd6                           mov edx, r14d
000077dc 498bcf                           mov rcx, r15
000077df e87cfa0000                       call 0x17260
000077e4 488b442440                       mov rax, qword ptr [rsp + 0x40]
000077e9 4889442420                       mov qword ptr [rsp + 0x20], rax
000077ee 4c8d4d80                         lea r9, [rbp - 0x80]
000077f2 4c8d458c                         lea r8, [rbp - 0x74]
000077f6 488d5588                         lea rdx, [rbp - 0x78]
000077fa 488d4d84                         lea rcx, [rbp - 0x7c]
000077fe e8edfa0000                       call 0x172f0
00007803 f30f104584                       movss xmm0, dword ptr [rbp - 0x7c]
00007808 f30f1107                         movss dword ptr [rdi], xmm0
0000780c f30f104d88                       movss xmm1, dword ptr [rbp - 0x78]
00007811 f30f114f04                       movss dword ptr [rdi + 4], xmm1
00007816 f30f10458c                       movss xmm0, dword ptr [rbp - 0x74]
0000781b f30f114708                       movss dword ptr [rdi + 8], xmm0
00007820 f30f104d80                       movss xmm1, dword ptr [rbp - 0x80]
00007825 f30f114f0c                       movss dword ptr [rdi + 0xc], xmm1
0000782a 4533c0                           xor r8d, r8d
0000782d 4c8906                           mov qword ptr [rsi], r8
00007830 4c894608                         mov qword ptr [rsi + 8], r8
00007834 41ffc6                           inc r14d
00007837 488d7f10                         lea rdi, [rdi + 0x10]
0000783b 488d7610                         lea rsi, [rsi + 0x10]
0000783f 488344244004                     add qword ptr [rsp + 0x40], 4
00007845 418b5724                         mov edx, dword ptr [r15 + 0x24]
00007849 443bf2                           cmp r14d, edx
0000784c 7c83                             jl 0x77d1
0000784e 41ffc4                           inc r12d
00007851 458b4f28                         mov r9d, dword ptr [r15 + 0x28]
00007855 453be1                           cmp r12d, r9d
00007858 0f8c32ffffff                     jl 0x7790
0000785e 488b7c2448                       mov rdi, qword ptr [rsp + 0x48]
00007863 488b742450                       mov rsi, qword ptr [rsp + 0x50]
00007868 837b5003                         cmp dword ptr [rbx + 0x50], 3
0000786c 0f85a7000000                     jne 0x7919
00007872 f30f105348                       movss xmm2, dword ptr [rbx + 0x48]
00007877 660f6e8f00010000                 movd xmm1, dword ptr [rdi + 0x100]
0000787f 0f5bc9                           cvtdq2ps xmm1, xmm1
00007882 f30f59ca                         mulss xmm1, xmm2
00007886 f30f2cc9                         cvttss2si ecx, xmm1
0000788a 81f900000080                     cmp ecx, 0x80000000
00007890 7421                             je 0x78b3
00007892 660f6ec1                         movd xmm0, ecx
00007896 0f5bc0                           cvtdq2ps xmm0, xmm0
00007899 0f2ec1                           ucomiss xmm0, xmm1
0000789c 7415                             je 0x78b3
0000789e 0f14c9                           unpcklps xmm1, xmm1
000078a1 0f50c1                           movmskps eax, xmm1
000078a4 83e001                           and eax, 1
000078a7 83f001                           xor eax, 1
000078aa 03c8                             add ecx, eax
000078ac 660f6ec9                         movd xmm1, ecx
000078b0 0f5bc9                           cvtdq2ps xmm1, xmm1
000078b3 488b93a8000000                   mov rdx, qword ptr [rbx + 0xa8]
000078ba 660f6e4228                       movd xmm0, dword ptr [rdx + 0x28]
000078bf 0f5bc0                           cvtdq2ps xmm0, xmm0
000078c2 0f2ec1                           ucomiss xmm0, xmm1
000078c5 7549                             jne 0x7910
000078c7 660f6e8ffc000000                 movd xmm1, dword ptr [rdi + 0xfc]
000078cf 0f5bc9                           cvtdq2ps xmm1, xmm1
000078d2 f30f59ca                         mulss xmm1, xmm2
000078d6 f30f2cc9                         cvttss2si ecx, xmm1
000078da 81f900000080                     cmp ecx, 0x80000000
000078e0 7421                             je 0x7903
000078e2 660f6ec1                         movd xmm0, ecx
000078e6 0f5bc0                           cvtdq2ps xmm0, xmm0
000078e9 0f2ec1                           ucomiss xmm0, xmm1
000078ec 7415                             je 0x7903
000078ee 0f14c9                           unpcklps xmm1, xmm1
000078f1 0f50c1                           movmskps eax, xmm1
000078f4 83e001                           and eax, 1
000078f7 83f001                           xor eax, 1
000078fa 03c8                             add ecx, eax
000078fc 660f6ec9                         movd xmm1, ecx
00007900 0f5bc9                           cvtdq2ps xmm1, xmm1
00007903 660f6e4224                       movd xmm0, dword ptr [rdx + 0x24]
00007908 0f5bc0                           cvtdq2ps xmm0, xmm0
0000790b 0f2ec1                           ucomiss xmm0, xmm1
0000790e 744f                             je 0x795f
00007910 4c8983a8000000                   mov qword ptr [rbx + 0xa8], r8
00007917 eb46                             jmp 0x795f
00007919 488d8bb0000000                   lea rcx, [rbx + 0xb0]
00007920 8b83fc000000                     mov eax, dword ptr [rbx + 0xfc]
00007926 89442430                         mov dword ptr [rsp + 0x30], eax
0000792a f30f108300010000                 movss xmm0, dword ptr [rbx + 0x100]
00007932 f30f11442428                     movss dword ptr [rsp + 0x28], xmm0
00007938 f30f108b04010000                 movss xmm1, dword ptr [rbx + 0x104]
00007940 f30f114c2420                     movss dword ptr [rsp + 0x20], xmm1
00007946 458b4724                         mov r8d, dword ptr [r15 + 0x24]
0000794a 488bd7                           mov rdx, rdi
0000794d e82e1a0000                       call 0x9380
00007952 837b5001                         cmp dword ptr [rbx + 0x50], 1
00007956 0f94c0                           sete al
00007959 8883f8000000                     mov byte ptr [rbx + 0xf8], al
0000795f 4c8b4308                         mov r8, qword ptr [rbx + 8]
00007963 f3440f101d68990100               movss xmm11, dword ptr [rip + 0x19968]
0000796c 0f57f6                           xorps xmm6, xmm6
0000796f 807b4400                         cmp byte ptr [rbx + 0x44], 0
00007973 0f84a2000000                     je 0x7a1b
00007979 4533d2                           xor r10d, r10d
0000797c 45395028                         cmp dword ptr [r8 + 0x28], r10d
00007980 7e64                             jle 0x79e6
00007982 0f1f4000                         nop dword ptr [rax]
00007986 66660f1f840000000000             nop word ptr [rax + rax]
00007990 418b4824                         mov ecx, dword ptr [r8 + 0x24]
00007994 8bc1                             mov eax, ecx
00007996 410fafc2                         imul eax, r10d
0000799a 4863d0                           movsxd rdx, eax
0000799d 4803d6                           add rdx, rsi
000079a0 8d048500000000                   lea eax, [rax*4]
000079a7 4c63d8                           movsxd r11, eax
000079aa 488b8398000000                   mov rax, qword ptr [rbx + 0x98]
000079b1 4533c9                           xor r9d, r9d
000079b4 85c9                             test ecx, ecx
000079b6 7e25                             jle 0x79dd
000079b8 488d480c                         lea rcx, [rax + 0xc]
000079bc 4a8d0c99                         lea rcx, [rcx + r11*4]
000079c0 0f2f31                           comiss xmm6, dword ptr [rcx]
000079c3 0f92c0                           setb al
000079c6 8802                             mov byte ptr [rdx], al
000079c8 41ffc1                           inc r9d
000079cb 488d5201                         lea rdx, [rdx + 1]
000079cf 488d4910                         lea rcx, [rcx + 0x10]
000079d3 4c8b4308                         mov r8, qword ptr [rbx + 8]
000079d7 453b4824                         cmp r9d, dword ptr [r8 + 0x24]
000079db 7ce3                             jl 0x79c0
000079dd 41ffc2                           inc r10d
000079e0 453b5028                         cmp r10d, dword ptr [r8 + 0x28]
000079e4 7caa                             jl 0x7990
000079e6 48897d80                         mov qword ptr [rbp - 0x80], rdi
000079ea 48c7458800000000                 mov qword ptr [rbp - 0x78], 0
000079f2 418b4028                         mov eax, dword ptr [r8 + 0x28]
000079f6 89442420                         mov dword ptr [rsp + 0x20], eax
000079fa 458b4824                         mov r9d, dword ptr [r8 + 0x24]
000079fe 4c8b8308010000                   mov r8, qword ptr [rbx + 0x108]
00007a05 488bd6                           mov rdx, rsi
00007a08 488d4d80                         lea rcx, [rbp - 0x80]
00007a0c e81f0f0000                       call 0x8930
00007a11 660f6e458c                       movd xmm0, dword ptr [rbp - 0x74]
00007a16 0f5bc0                           cvtdq2ps xmm0, xmm0
00007a19 eb26                             jmp 0x7a41
00007a1b c74424400000803f                 mov dword ptr [rsp + 0x40], 0x3f800000
00007a23 418b5024                         mov edx, dword ptr [r8 + 0x24]
00007a27 410faf5028                       imul edx, dword ptr [r8 + 0x28]
00007a2c 4c8d442440                       lea r8, [rsp + 0x40]
00007a31 488b8b08010000                   mov rcx, qword ptr [rbx + 0x108]
00007a38 e8c3eaffff                       call 0x6500
00007a3d 410f28c3                         movaps xmm0, xmm11
00007a41 f30f11434c                       movss dword ptr [rbx + 0x4c], xmm0
00007a46 4533d2                           xor r10d, r10d
00007a49 4c8b4b08                         mov r9, qword ptr [rbx + 8]
00007a4d 45395128                         cmp dword ptr [r9 + 0x28], r10d
00007a51 0f8e84000000                     jle 0x7adb
00007a57 660f1f840000000000               nop word ptr [rax + rax]
00007a60 458b5924                         mov r11d, dword ptr [r9 + 0x24]
00007a64 418bc3                           mov eax, r11d
00007a67 410fafc2                         imul eax, r10d
00007a6b 4863c8                           movsxd rcx, eax
00007a6e 488b8308010000                   mov rax, qword ptr [rbx + 0x108]
00007a75 488d1488                         lea rdx, [rax + rcx*4]
00007a79 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
00007a80 4c8d0488                         lea r8, [rax + rcx*4]
00007a84 410f28db                         movaps xmm3, xmm11
00007a88 f30f10434c                       movss xmm0, dword ptr [rbx + 0x4c]
00007a8d 0f2fc6                           comiss xmm0, xmm6
00007a90 7604                             jbe 0x7a96
00007a92 f30f5ed8                         divss xmm3, xmm0
00007a96 33c0                             xor eax, eax
00007a98 4585db                           test r11d, r11d
00007a9b 7e35                             jle 0x7ad2
00007a9d 0f1f00                           nop dword ptr [rax]
00007aa0 0f28d3                           movaps xmm2, xmm3
00007aa3 f30f5912                         mulss xmm2, dword ptr [rdx]
00007aa7 f30f595340                       mulss xmm2, dword ptr [rbx + 0x40]
00007aac 410f28c3                         movaps xmm0, xmm11
00007ab0 f30f5c4340                       subss xmm0, dword ptr [rbx + 0x40]
00007ab5 f30f58d0                         addss xmm2, xmm0
00007ab9 f3410f1110                       movss dword ptr [r8], xmm2
00007abe ffc0                             inc eax
00007ac0 4883c204                         add rdx, 4
00007ac4 4983c004                         add r8, 4
00007ac8 4c8b4b08                         mov r9, qword ptr [rbx + 8]
00007acc 413b4124                         cmp eax, dword ptr [r9 + 0x24]
00007ad0 7cce                             jl 0x7aa0
00007ad2 41ffc2                           inc r10d
00007ad5 453b5128                         cmp r10d, dword ptr [r9 + 0x28]
00007ad9 7c85                             jl 0x7a60
00007adb 488bcb                           mov rcx, rbx
00007ade e84dedffff                       call 0x6830
00007ae3 8b4320                           mov eax, dword ptr [rbx + 0x20]
00007ae6 83f801                           cmp eax, 1
00007ae9 7533                             jne 0x7b1e
00007aeb 488d4d40                         lea rcx, [rbp + 0x40]
00007aef e8ec2c0000                       call 0xa7e0
00007af4 90                               nop 
00007af5 f30f108b80000000                 movss xmm1, dword ptr [rbx + 0x80]
00007afd 488d4d40                         lea rcx, [rbp + 0x40]
00007b01 e80a2d0000                       call 0xa810
00007b06 488bd3                           mov rdx, rbx
00007b09 488d4d40                         lea rcx, [rbp + 0x40]
00007b0d e8dedbffff                       call 0x56f0
00007b12 90                               nop 
00007b13 488d4d40                         lea rcx, [rbp + 0x40]
00007b17 e8e42c0000                       call 0xa800
00007b1c eb36                             jmp 0x7b54
00007b1e 83f802                           cmp eax, 2
00007b21 7531                             jne 0x7b54
00007b23 488d4d40                         lea rcx, [rbp + 0x40]
00007b27 e8649fffff                       call 0x1a90
00007b2c 90                               nop 
00007b2d f30f108b80000000                 movss xmm1, dword ptr [rbx + 0x80]
00007b35 488d4d40                         lea rcx, [rbp + 0x40]
00007b39 e8829fffff                       call 0x1ac0
00007b3e 488bd3                           mov rdx, rbx
00007b41 488d4d40                         lea rcx, [rbp + 0x40]
00007b45 e8f6caffff                       call 0x4640
00007b4a 90                               nop 
00007b4b 488d4d40                         lea rcx, [rbp + 0x40]
00007b4f e85c9fffff                       call 0x1ab0
00007b54 4533f6                           xor r14d, r14d
00007b57 45397528                         cmp dword ptr [r13 + 0x28], r14d
00007b5b 0f8ede000000                     jle 0x7c3f
00007b61 418b5524                         mov edx, dword ptr [r13 + 0x24]
00007b65 6666660f1f840000000000           nop word ptr [rax + rax]
00007b70 418bc6                           mov eax, r14d
00007b73 0fafc2                           imul eax, edx
00007b76 c1e002                           shl eax, 2
00007b79 4863c8                           movsxd rcx, eax
00007b7c 488b83a0000000                   mov rax, qword ptr [rbx + 0xa0]
00007b83 488d3c88                         lea rdi, [rax + rcx*4]
00007b87 418bc6                           mov eax, r14d
00007b8a 410faf4520                       imul eax, dword ptr [r13 + 0x20]
00007b8f 4863c8                           movsxd rcx, eax
00007b92 49034d18                         add rcx, qword ptr [r13 + 0x18]
00007b96 48894c2440                       mov qword ptr [rsp + 0x40], rcx
00007b9b 33f6                             xor esi, esi
00007b9d 85d2                             test edx, edx
00007b9f 0f8e88000000                     jle 0x7c2d
00007ba5 6666660f1f840000000000           nop word ptr [rax + rax]
00007bb0 f30f107338                       movss xmm6, dword ptr [rbx + 0x38]
00007bb5 f3440f1017                       movss xmm10, dword ptr [rdi]
00007bba f3440f104f04                     movss xmm9, dword ptr [rdi + 4]
00007bc0 f3440f104708                     movss xmm8, dword ptr [rdi + 8]
00007bc6 f30f107f0c                       movss xmm7, dword ptr [rdi + 0xc]
00007bcb 4c8d4c2440                       lea r9, [rsp + 0x40]
00007bd0 458bc6                           mov r8d, r14d
00007bd3 8bd6                             mov edx, esi
00007bd5 498bcd                           mov rcx, r13
00007bd8 e883f60000                       call 0x17260
00007bdd f3440f59c6                       mulss xmm8, xmm6
00007be2 f3450f5dc3                       minss xmm8, xmm11
00007be7 f3440f59ce                       mulss xmm9, xmm6
00007bec f3450f5dcb                       minss xmm9, xmm11
00007bf1 f3440f59d6                       mulss xmm10, xmm6
00007bf6 f3450f5dd3                       minss xmm10, xmm11
00007bfb 488b442440                       mov rax, qword ptr [rsp + 0x40]
00007c00 4889442420                       mov qword ptr [rsp + 0x20], rax
00007c05 0f28df                           movaps xmm3, xmm7
00007c08 410f28d0                         movaps xmm2, xmm8
00007c0c 410f28c9                         movaps xmm1, xmm9
00007c10 410f28c2                         movaps xmm0, xmm10
00007c14 e8e7f70000                       call 0x17400
00007c19 ffc6                             inc esi
00007c1b 488d7f10                         lea rdi, [rdi + 0x10]
00007c1f 488344244004                     add qword ptr [rsp + 0x40], 4
00007c25 418b5524                         mov edx, dword ptr [r13 + 0x24]
00007c29 3bf2                             cmp esi, edx
00007c2b 7c83                             jl 0x7bb0
00007c2d 41ffc6                           inc r14d
00007c30 453b7528                         cmp r14d, dword ptr [r13 + 0x28]
00007c34 0f8c36ffffff                     jl 0x7b70
00007c3a 488b7c2448                       mov rdi, qword ptr [rsp + 0x48]
00007c3f 488b542458                       mov rdx, qword ptr [rsp + 0x58]
00007c44 488bcf                           mov rcx, rdi
00007c47 e804090000                       call 0x8550
00007c4c 488b542458                       mov rdx, qword ptr [rsp + 0x58]
00007c51 488bcf                           mov rcx, rdi
00007c54 e897090000                       call 0x85f0
00007c59 488b542460                       mov rdx, qword ptr [rsp + 0x60]
00007c5e 488bcf                           mov rcx, rdi
00007c61 e8ea080000                       call 0x8550
00007c66 488b542460                       mov rdx, qword ptr [rsp + 0x60]
00007c6b 488bcf                           mov rcx, rdi
00007c6e e87d090000                       call 0x85f0
00007c73 488b542468                       mov rdx, qword ptr [rsp + 0x68]
00007c78 488bcf                           mov rcx, rdi
00007c7b e8d0080000                       call 0x8550
00007c80 488b542468                       mov rdx, qword ptr [rsp + 0x68]
00007c85 488bcf                           mov rcx, rdi
00007c88 e863090000                       call 0x85f0
00007c8d 488b542470                       mov rdx, qword ptr [rsp + 0x70]
00007c92 488bcf                           mov rcx, rdi
00007c95 e8b6080000                       call 0x8550
00007c9a 488b542470                       mov rdx, qword ptr [rsp + 0x70]
00007c9f 488bcf                           mov rcx, rdi
00007ca2 e849090000                       call 0x85f0
00007ca7 488b542478                       mov rdx, qword ptr [rsp + 0x78]
00007cac 488bcf                           mov rcx, rdi
00007caf e89c080000                       call 0x8550
00007cb4 488b542478                       mov rdx, qword ptr [rsp + 0x78]
00007cb9 488bcf                           mov rcx, rdi
00007cbc e82f090000                       call 0x85f0
00007cc1 837b5003                         cmp dword ptr [rbx + 0x50], 3
00007cc5 7510                             jne 0x7cd7
00007cc7 488d5590                         lea rdx, [rbp - 0x70]
00007ccb 488b8fb8000000                   mov rcx, qword ptr [rdi + 0xb8]
00007cd2 ff5708                           call qword ptr [rdi + 8]
00007cd5 eb0c                             jmp 0x7ce3
00007cd7 488d8bb0000000                   lea rcx, [rbx + 0xb0]
00007cde e8cd1a0000                       call 0x97b0
00007ce3 488b8da0c90300                   mov rcx, qword ptr [rbp + 0x3c9a0]
00007cea 4833cc                           xor rcx, rsp
00007ced e8ce530100                       call 0x1d0c0
00007cf2 4c8d9c2410cb0300                 lea r11, [rsp + 0x3cb10]
00007cfa 498b5b48                         mov rbx, qword ptr [r11 + 0x48]
00007cfe 410f2873f0                       movaps xmm6, xmmword ptr [r11 - 0x10]
00007d03 410f287be0                       movaps xmm7, xmmword ptr [r11 - 0x20]
00007d08 450f2843d0                       movaps xmm8, xmmword ptr [r11 - 0x30]
00007d0d 450f284bc0                       movaps xmm9, xmmword ptr [r11 - 0x40]
00007d12 450f2853b0                       movaps xmm10, xmmword ptr [r11 - 0x50]
00007d17 450f285ba0                       movaps xmm11, xmmword ptr [r11 - 0x60]
00007d1c 498be3                           mov rsp, r11
00007d1f 415f                             pop r15
00007d21 415e                             pop r14
00007d23 415d                             pop r13
00007d25 415c                             pop r12
00007d27 5f                               pop rdi
00007d28 5e                               pop rsi
00007d29 5d                               pop rbp
00007d2a c3                               ret 
00007d2b cc                               int3 
00007d2c cc                               int3 
00007d2d cc                               int3 
00007d2e cc                               int3 
00007d2f cc                               int3 
00007d30 48895c2410                       mov qword ptr [rsp + 0x10], rbx
00007d35 55                               push rbp
00007d36 56                               push rsi
00007d37 57                               push rdi
00007d38 4154                             push r12
00007d3a 4155                             push r13
00007d3c 4156                             push r14
00007d3e 4157                             push r15
00007d40 488dac24f035fcff                 lea rbp, [rsp - 0x3ca10]
00007d48 b810cb0300                       mov eax, 0x3cb10
00007d4d e89e520100                       call 0x1cff0
00007d52 482be0                           sub rsp, rax
00007d55 0f29b42400cb0300                 movaps xmmword ptr [rsp + 0x3cb00], xmm6
00007d5d 0f29bc24f0ca0300                 movaps xmmword ptr [rsp + 0x3caf0], xmm7
00007d65 440f298424e0ca0300               movaps xmmword ptr [rsp + 0x3cae0], xmm8
00007d6e 440f298c24d0ca0300               movaps xmmword ptr [rsp + 0x3cad0], xmm9
00007d77 440f299424c0ca0300               movaps xmmword ptr [rsp + 0x3cac0], xmm10
00007d80 440f299c24b0ca0300               movaps xmmword ptr [rsp + 0x3cab0], xmm11
00007d89 488b05e8330200                   mov rax, qword ptr [rip + 0x233e8]
00007d90 4833c4                           xor rax, rsp
00007d93 488985a0c90300                   mov qword ptr [rbp + 0x3c9a0], rax
00007d9a 4d8be9                           mov r13, r9
00007d9d 4d8bf8                           mov r15, r8
00007da0 488bf9                           mov rdi, rcx
00007da3 48894c2448                       mov qword ptr [rsp + 0x48], rcx
00007da8 488b9d70ca0300                   mov rbx, qword ptr [rbp + 0x3ca70]
00007daf 488b81b0000000                   mov rax, qword ptr [rcx + 0xb0]
00007db6 4c8b5040                         mov r10, qword ptr [rax + 0x40]
00007dba 48c744242000000000               mov qword ptr [rsp + 0x20], 0
00007dc3 4533c9                           xor r9d, r9d
00007dc6 4d8bc5                           mov r8, r13
00007dc9 498bd7                           mov rdx, r15
00007dcc 488b89b8000000                   mov rcx, qword ptr [rcx + 0xb8]
00007dd3 41ffd2                           call r10
00007dd6 8bc8                             mov ecx, eax
00007dd8 e803900000                       call 0x10de0
00007ddd 48893b                           mov qword ptr [rbx], rdi
00007de0 4c897b08                         mov qword ptr [rbx + 8], r15
00007de4 4c896b10                         mov qword ptr [rbx + 0x10], r13
00007de8 66410f6e4768                     movd xmm0, dword ptr [r15 + 0x68]
00007dee f30fe6c0                         cvtdq2pd xmm0, xmm0
00007df2 f20f106328                       movsd xmm4, qword ptr [rbx + 0x28]
00007df7 f20f5ce0                         subsd xmm4, xmm0
00007dfb f20f116328                       movsd qword ptr [rbx + 0x28], xmm4
00007e00 66410f6e476c                     movd xmm0, dword ptr [r15 + 0x6c]
00007e06 f30fe6c0                         cvtdq2pd xmm0, xmm0
00007e0a f20f105b30                       movsd xmm3, qword ptr [rbx + 0x30]
00007e0f f20f5cd8                         subsd xmm3, xmm0
00007e13 f20f115b30                       movsd qword ptr [rbx + 0x30], xmm3
00007e18 660f6e8f1c010000                 movd xmm1, dword ptr [rdi + 0x11c]
00007e20 0f5bc9                           cvtdq2ps xmm1, xmm1
00007e23 8b8720010000                     mov eax, dword ptr [rdi + 0x120]
00007e29 0f57c0                           xorps xmm0, xmm0
00007e2c f3480f2ac0                       cvtsi2ss xmm0, rax
00007e31 f30f5ec8                         divss xmm1, xmm0
00007e35 f30f114b48                       movss dword ptr [rbx + 0x48], xmm1
00007e3a 0f28c1                           movaps xmm0, xmm1
00007e3d f30f598304010000                 mulss xmm0, dword ptr [rbx + 0x104]
00007e45 f30f118304010000                 movss dword ptr [rbx + 0x104], xmm0
00007e4d 0f5ad1                           cvtps2pd xmm2, xmm1
00007e50 0f28ca                           movaps xmm1, xmm2
00007e53 f20f59cc                         mulsd xmm1, xmm4
00007e57 f20f114b28                       movsd qword ptr [rbx + 0x28], xmm1
00007e5c f20f59d3                         mulsd xmm2, xmm3
00007e60 f20f115330                       movsd qword ptr [rbx + 0x30], xmm2
00007e65 837b6400                         cmp dword ptr [rbx + 0x64], 0
00007e69 7522                             jne 0x7e8d
00007e6b 837b5800                         cmp dword ptr [rbx + 0x58], 0
00007e6f 751c                             jne 0x7e8d
00007e71 837b6800                         cmp dword ptr [rbx + 0x68], 0
00007e75 7516                             jne 0x7e8d
00007e77 837b6000                         cmp dword ptr [rbx + 0x60], 0
00007e7b 7510                             jne 0x7e8d
00007e7d 837b7000                         cmp dword ptr [rbx + 0x70], 0
00007e81 750a                             jne 0x7e8d
00007e83 837b6c00                         cmp dword ptr [rbx + 0x6c], 0
00007e87 0f8466060000                     je 0x84f3
00007e8d 418b5728                         mov edx, dword ptr [r15 + 0x28]
00007e91 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00007e96 c1e202                           shl edx, 2
00007e99 488bcf                           mov rcx, rdi
00007e9c e8ffc6ffff                       call 0x45a0
00007ea1 4889442458                       mov qword ptr [rsp + 0x58], rax
00007ea6 488bd0                           mov rdx, rax
00007ea9 488bcf                           mov rcx, rdi
00007eac e80fc5ffff                       call 0x43c0
00007eb1 48898398000000                   mov qword ptr [rbx + 0x98], rax
00007eb8 418b5728                         mov edx, dword ptr [r15 + 0x28]
00007ebc 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00007ec1 c1e202                           shl edx, 2
00007ec4 488bcf                           mov rcx, rdi
00007ec7 e8d4c6ffff                       call 0x45a0
00007ecc 4889442460                       mov qword ptr [rsp + 0x60], rax
00007ed1 488bd0                           mov rdx, rax
00007ed4 488bcf                           mov rcx, rdi
00007ed7 e8e4c4ffff                       call 0x43c0
00007edc 488983a0000000                   mov qword ptr [rbx + 0xa0], rax
00007ee3 418b5728                         mov edx, dword ptr [r15 + 0x28]
00007ee7 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00007eec 488bcf                           mov rcx, rdi
00007eef e8acc6ffff                       call 0x45a0
00007ef4 488bd0                           mov rdx, rax
00007ef7 488bcf                           mov rcx, rdi
00007efa e8c1c4ffff                       call 0x43c0
00007eff 48898388000000                   mov qword ptr [rbx + 0x88], rax
00007f06 418b5728                         mov edx, dword ptr [r15 + 0x28]
00007f0a 410faf5724                       imul edx, dword ptr [r15 + 0x24]
00007f0f 488bcf                           mov rcx, rdi
00007f12 e889c6ffff                       call 0x45a0
00007f17 4889442468                       mov qword ptr [rsp + 0x68], rax
00007f1c 488bd0                           mov rdx, rax
00007f1f 488bcf                           mov rcx, rdi
00007f22 e899c4ffff                       call 0x43c0
00007f27 48898390000000                   mov qword ptr [rbx + 0x90], rax
00007f2e 488b4b08                         mov rcx, qword ptr [rbx + 8]
00007f32 8b5128                           mov edx, dword ptr [rcx + 0x28]
00007f35 0faf5124                         imul edx, dword ptr [rcx + 0x24]
00007f39 488bcf                           mov rcx, rdi
00007f3c e8bfc5ffff                       call 0x4500
00007f41 4889442470                       mov qword ptr [rsp + 0x70], rax
00007f46 488bd0                           mov rdx, rax
00007f49 488bcf                           mov rcx, rdi
00007f4c e8cfc3ffff                       call 0x4320
00007f51 488bf0                           mov rsi, rax
00007f54 4889442450                       mov qword ptr [rsp + 0x50], rax
00007f59 488b4b08                         mov rcx, qword ptr [rbx + 8]
00007f5d 8b5128                           mov edx, dword ptr [rcx + 0x28]
00007f60 0faf5124                         imul edx, dword ptr [rcx + 0x24]
00007f64 488bcf                           mov rcx, rdi
00007f67 e834c6ffff                       call 0x45a0
00007f6c 4889442478                       mov qword ptr [rsp + 0x78], rax
00007f71 488bd0                           mov rdx, rax
00007f74 488bcf                           mov rcx, rdi
00007f77 e844c4ffff                       call 0x43c0
00007f7c 48898308010000                   mov qword ptr [rbx + 0x108], rax
00007f83 4533c0                           xor r8d, r8d
00007f86 458be0                           mov r12d, r8d
00007f89 458b4f28                         mov r9d, dword ptr [r15 + 0x28]
00007f8d 4585c9                           test r9d, r9d
00007f90 0f8ee2000000                     jle 0x8078
00007f96 418b5724                         mov edx, dword ptr [r15 + 0x24]
00007f9a 660f1f440000                     nop word ptr [rax + rax]
00007fa0 8bc2                             mov eax, edx
00007fa2 410fafc4                         imul eax, r12d
00007fa6 c1e002                           shl eax, 2
00007fa9 4863c8                           movsxd rcx, eax
00007fac 488b8398000000                   mov rax, qword ptr [rbx + 0x98]
00007fb3 488d3c88                         lea rdi, [rax + rcx*4]
00007fb7 488b83a0000000                   mov rax, qword ptr [rbx + 0xa0]
00007fbe 488d3488                         lea rsi, [rax + rcx*4]
00007fc2 418bc4                           mov eax, r12d
00007fc5 410faf4720                       imul eax, dword ptr [r15 + 0x20]
00007fca 4863c8                           movsxd rcx, eax
00007fcd 49034f18                         add rcx, qword ptr [r15 + 0x18]
00007fd1 48894c2440                       mov qword ptr [rsp + 0x40], rcx
00007fd6 458bf0                           mov r14d, r8d
00007fd9 85d2                             test edx, edx
00007fdb 0f8e7d000000                     jle 0x805e
00007fe1 4c8d4c2440                       lea r9, [rsp + 0x40]
00007fe6 458bc4                           mov r8d, r12d
00007fe9 418bd6                           mov edx, r14d
00007fec 498bcf                           mov rcx, r15
00007fef e8ccf20000                       call 0x172c0
00007ff4 488b442440                       mov rax, qword ptr [rsp + 0x40]
00007ff9 4889442420                       mov qword ptr [rsp + 0x20], rax
00007ffe 4c8d4d80                         lea r9, [rbp - 0x80]
00008002 4c8d458c                         lea r8, [rbp - 0x74]
00008006 488d5588                         lea rdx, [rbp - 0x78]
0000800a 488d4d84                         lea rcx, [rbp - 0x7c]
0000800e e8bdf30000                       call 0x173d0
00008013 f30f104584                       movss xmm0, dword ptr [rbp - 0x7c]
00008018 f30f1107                         movss dword ptr [rdi], xmm0
0000801c f30f104d88                       movss xmm1, dword ptr [rbp - 0x78]
00008021 f30f114f04                       movss dword ptr [rdi + 4], xmm1
00008026 f30f10458c                       movss xmm0, dword ptr [rbp - 0x74]
0000802b f30f114708                       movss dword ptr [rdi + 8], xmm0
00008030 f30f104d80                       movss xmm1, dword ptr [rbp - 0x80]
00008035 f30f114f0c                       movss dword ptr [rdi + 0xc], xmm1
0000803a 4533c0                           xor r8d, r8d
0000803d 4c8906                           mov qword ptr [rsi], r8
00008040 4c894608                         mov qword ptr [rsi + 8], r8
00008044 41ffc6                           inc r14d
00008047 488d7f10                         lea rdi, [rdi + 0x10]
0000804b 488d7610                         lea rsi, [rsi + 0x10]
0000804f 488344244010                     add qword ptr [rsp + 0x40], 0x10
00008055 418b5724                         mov edx, dword ptr [r15 + 0x24]
00008059 443bf2                           cmp r14d, edx
0000805c 7c83                             jl 0x7fe1
0000805e 41ffc4                           inc r12d
00008061 458b4f28                         mov r9d, dword ptr [r15 + 0x28]
00008065 453be1                           cmp r12d, r9d
00008068 0f8c32ffffff                     jl 0x7fa0
0000806e 488b7c2448                       mov rdi, qword ptr [rsp + 0x48]
00008073 488b742450                       mov rsi, qword ptr [rsp + 0x50]
00008078 837b5003                         cmp dword ptr [rbx + 0x50], 3
0000807c 0f85a7000000                     jne 0x8129
00008082 f30f105348                       movss xmm2, dword ptr [rbx + 0x48]
00008087 660f6e8f00010000                 movd xmm1, dword ptr [rdi + 0x100]
0000808f 0f5bc9                           cvtdq2ps xmm1, xmm1
00008092 f30f59ca                         mulss xmm1, xmm2
00008096 f30f2cc9                         cvttss2si ecx, xmm1
0000809a 81f900000080                     cmp ecx, 0x80000000
000080a0 7421                             je 0x80c3
000080a2 660f6ec1                         movd xmm0, ecx
000080a6 0f5bc0                           cvtdq2ps xmm0, xmm0
000080a9 0f2ec1                           ucomiss xmm0, xmm1
000080ac 7415                             je 0x80c3
000080ae 0f14c9                           unpcklps xmm1, xmm1
000080b1 0f50c1                           movmskps eax, xmm1
000080b4 83e001                           and eax, 1
000080b7 83f001                           xor eax, 1
000080ba 03c8                             add ecx, eax
000080bc 660f6ec9                         movd xmm1, ecx
000080c0 0f5bc9                           cvtdq2ps xmm1, xmm1
000080c3 488b93a8000000                   mov rdx, qword ptr [rbx + 0xa8]
000080ca 660f6e4228                       movd xmm0, dword ptr [rdx + 0x28]
000080cf 0f5bc0                           cvtdq2ps xmm0, xmm0
000080d2 0f2ec1                           ucomiss xmm0, xmm1
000080d5 7549                             jne 0x8120
000080d7 660f6e8ffc000000                 movd xmm1, dword ptr [rdi + 0xfc]
000080df 0f5bc9                           cvtdq2ps xmm1, xmm1
000080e2 f30f59ca                         mulss xmm1, xmm2
000080e6 f30f2cc9                         cvttss2si ecx, xmm1
000080ea 81f900000080                     cmp ecx, 0x80000000
000080f0 7421                             je 0x8113
000080f2 660f6ec1                         movd xmm0, ecx
000080f6 0f5bc0                           cvtdq2ps xmm0, xmm0
000080f9 0f2ec1                           ucomiss xmm0, xmm1
000080fc 7415                             je 0x8113
000080fe 0f14c9                           unpcklps xmm1, xmm1
00008101 0f50c1                           movmskps eax, xmm1
00008104 83e001                           and eax, 1
00008107 83f001                           xor eax, 1
0000810a 03c8                             add ecx, eax
0000810c 660f6ec9                         movd xmm1, ecx
00008110 0f5bc9                           cvtdq2ps xmm1, xmm1
00008113 660f6e4224                       movd xmm0, dword ptr [rdx + 0x24]
00008118 0f5bc0                           cvtdq2ps xmm0, xmm0
0000811b 0f2ec1                           ucomiss xmm0, xmm1
0000811e 744f                             je 0x816f
00008120 4c8983a8000000                   mov qword ptr [rbx + 0xa8], r8
00008127 eb46                             jmp 0x816f
00008129 488d8bb0000000                   lea rcx, [rbx + 0xb0]
00008130 8b83fc000000                     mov eax, dword ptr [rbx + 0xfc]
00008136 89442430                         mov dword ptr [rsp + 0x30], eax
0000813a f30f108300010000                 movss xmm0, dword ptr [rbx + 0x100]
00008142 f30f11442428                     movss dword ptr [rsp + 0x28], xmm0
00008148 f30f108b04010000                 movss xmm1, dword ptr [rbx + 0x104]
00008150 f30f114c2420                     movss dword ptr [rsp + 0x20], xmm1
00008156 458b4724                         mov r8d, dword ptr [r15 + 0x24]
0000815a 488bd7                           mov rdx, rdi
0000815d e81e120000                       call 0x9380
00008162 837b5001                         cmp dword ptr [rbx + 0x50], 1
00008166 0f94c0                           sete al
00008169 8883f8000000                     mov byte ptr [rbx + 0xf8], al
0000816f 4c8b4308                         mov r8, qword ptr [rbx + 8]
00008173 f3440f101d58910100               movss xmm11, dword ptr [rip + 0x19158]
0000817c 0f57f6                           xorps xmm6, xmm6
0000817f 807b4400                         cmp byte ptr [rbx + 0x44], 0
00008183 0f84a2000000                     je 0x822b
00008189 4533d2                           xor r10d, r10d
0000818c 45395028                         cmp dword ptr [r8 + 0x28], r10d
00008190 7e64                             jle 0x81f6
00008192 0f1f4000                         nop dword ptr [rax]
00008196 66660f1f840000000000             nop word ptr [rax + rax]
000081a0 418b4824                         mov ecx, dword ptr [r8 + 0x24]
000081a4 8bc1                             mov eax, ecx
000081a6 410fafc2                         imul eax, r10d
000081aa 4863d0                           movsxd rdx, eax
000081ad 4803d6                           add rdx, rsi
000081b0 8d048500000000                   lea eax, [rax*4]
000081b7 4c63d8                           movsxd r11, eax
000081ba 488b8398000000                   mov rax, qword ptr [rbx + 0x98]
000081c1 4533c9                           xor r9d, r9d
000081c4 85c9                             test ecx, ecx
000081c6 7e25                             jle 0x81ed
000081c8 488d480c                         lea rcx, [rax + 0xc]
000081cc 4a8d0c99                         lea rcx, [rcx + r11*4]
000081d0 0f2f31                           comiss xmm6, dword ptr [rcx]
000081d3 0f92c0                           setb al
000081d6 8802                             mov byte ptr [rdx], al
000081d8 41ffc1                           inc r9d
000081db 488d5201                         lea rdx, [rdx + 1]
000081df 488d4910                         lea rcx, [rcx + 0x10]
000081e3 4c8b4308                         mov r8, qword ptr [rbx + 8]
000081e7 453b4824                         cmp r9d, dword ptr [r8 + 0x24]
000081eb 7ce3                             jl 0x81d0
000081ed 41ffc2                           inc r10d
000081f0 453b5028                         cmp r10d, dword ptr [r8 + 0x28]
000081f4 7caa                             jl 0x81a0
000081f6 48897d80                         mov qword ptr [rbp - 0x80], rdi
000081fa 48c7458800000000                 mov qword ptr [rbp - 0x78], 0
00008202 418b4028                         mov eax, dword ptr [r8 + 0x28]
00008206 89442420                         mov dword ptr [rsp + 0x20], eax
0000820a 458b4824                         mov r9d, dword ptr [r8 + 0x24]
0000820e 4c8b8308010000                   mov r8, qword ptr [rbx + 0x108]
00008215 488bd6                           mov rdx, rsi
00008218 488d4d80                         lea rcx, [rbp - 0x80]
0000821c e80f070000                       call 0x8930
00008221 660f6e458c                       movd xmm0, dword ptr [rbp - 0x74]
00008226 0f5bc0                           cvtdq2ps xmm0, xmm0
00008229 eb26                             jmp 0x8251
0000822b c74424400000803f                 mov dword ptr [rsp + 0x40], 0x3f800000
00008233 418b5024                         mov edx, dword ptr [r8 + 0x24]
00008237 410faf5028                       imul edx, dword ptr [r8 + 0x28]
0000823c 4c8d442440                       lea r8, [rsp + 0x40]
00008241 488b8b08010000                   mov rcx, qword ptr [rbx + 0x108]
00008248 e8b3e2ffff                       call 0x6500
0000824d 410f28c3                         movaps xmm0, xmm11
00008251 f30f11434c                       movss dword ptr [rbx + 0x4c], xmm0
00008256 4533d2                           xor r10d, r10d
00008259 4c8b4b08                         mov r9, qword ptr [rbx + 8]
0000825d 45395128                         cmp dword ptr [r9 + 0x28], r10d
00008261 0f8e84000000                     jle 0x82eb
00008267 660f1f840000000000               nop word ptr [rax + rax]
00008270 458b5924                         mov r11d, dword ptr [r9 + 0x24]
00008274 418bc3                           mov eax, r11d
00008277 410fafc2                         imul eax, r10d
0000827b 4863c8                           movsxd rcx, eax
0000827e 488b8308010000                   mov rax, qword ptr [rbx + 0x108]
00008285 488d1488                         lea rdx, [rax + rcx*4]
00008289 488b8388000000                   mov rax, qword ptr [rbx + 0x88]
00008290 4c8d0488                         lea r8, [rax + rcx*4]
00008294 410f28db                         movaps xmm3, xmm11
00008298 f30f10434c                       movss xmm0, dword ptr [rbx + 0x4c]
0000829d 0f2fc6                           comiss xmm0, xmm6
000082a0 7604                             jbe 0x82a6
000082a2 f30f5ed8                         divss xmm3, xmm0
000082a6 33c0                             xor eax, eax
000082a8 4585db                           test r11d, r11d
000082ab 7e35                             jle 0x82e2
000082ad 0f1f00                           nop dword ptr [rax]
000082b0 0f28d3                           movaps xmm2, xmm3
000082b3 f30f5912                         mulss xmm2, dword ptr [rdx]
000082b7 f30f595340                       mulss xmm2, dword ptr [rbx + 0x40]
000082bc 410f28c3                         movaps xmm0, xmm11
000082c0 f30f5c4340                       subss xmm0, dword ptr [rbx + 0x40]
000082c5 f30f58d0                         addss xmm2, xmm0
000082c9 f3410f1110                       movss dword ptr [r8], xmm2
000082ce ffc0                             inc eax
000082d0 4883c204                         add rdx, 4
000082d4 4983c004                         add r8, 4
000082d8 4c8b4b08                         mov r9, qword ptr [rbx + 8]
000082dc 413b4124                         cmp eax, dword ptr [r9 + 0x24]
000082e0 7cce                             jl 0x82b0
000082e2 41ffc2                           inc r10d
000082e5 453b5128                         cmp r10d, dword ptr [r9 + 0x28]
000082e9 7c85                             jl 0x8270
000082eb 488bcb                           mov rcx, rbx
000082ee e8ade7ffff                       call 0x6aa0
000082f3 8b4320                           mov eax, dword ptr [rbx + 0x20]
000082f6 83f801                           cmp eax, 1
000082f9 7533                             jne 0x832e
000082fb 488d4d40                         lea rcx, [rbp + 0x40]
000082ff e8dc240000                       call 0xa7e0
00008304 90                               nop 
00008305 f30f108b80000000                 movss xmm1, dword ptr [rbx + 0x80]
0000830d 488d4d40                         lea rcx, [rbp + 0x40]
00008311 e8fa240000                       call 0xa810
00008316 488bd3                           mov rdx, rbx
00008319 488d4d40                         lea rcx, [rbp + 0x40]
0000831d e8ced3ffff                       call 0x56f0
00008322 90                               nop 
00008323 488d4d40                         lea rcx, [rbp + 0x40]
00008327 e8d4240000                       call 0xa800
0000832c eb36                             jmp 0x8364
0000832e 83f802                           cmp eax, 2
00008331 7531                             jne 0x8364
00008333 488d4d40                         lea rcx, [rbp + 0x40]
00008337 e85497ffff                       call 0x1a90
0000833c 90                               nop 
0000833d f30f108b80000000                 movss xmm1, dword ptr [rbx + 0x80]
00008345 488d4d40                         lea rcx, [rbp + 0x40]
00008349 e87297ffff                       call 0x1ac0
0000834e 488bd3                           mov rdx, rbx
00008351 488d4d40                         lea rcx, [rbp + 0x40]
00008355 e8e6c2ffff                       call 0x4640
0000835a 90                               nop 
0000835b 488d4d40                         lea rcx, [rbp + 0x40]
0000835f e84c97ffff                       call 0x1ab0
00008364 4533f6                           xor r14d, r14d
00008367 45397528                         cmp dword ptr [r13 + 0x28], r14d
0000836b 0f8ede000000                     jle 0x844f
00008371 418b5524                         mov edx, dword ptr [r13 + 0x24]
00008375 6666660f1f840000000000           nop word ptr [rax + rax]
00008380 418bc6                           mov eax, r14d
00008383 0fafc2                           imul eax, edx
00008386 c1e002                           shl eax, 2
00008389 4863c8                           movsxd rcx, eax
0000838c 488b83a0000000                   mov rax, qword ptr [rbx + 0xa0]
00008393 488d3c88                         lea rdi, [rax + rcx*4]
00008397 418bc6                           mov eax, r14d
0000839a 410faf4520                       imul eax, dword ptr [r13 + 0x20]
0000839f 4863c8                           movsxd rcx, eax
000083a2 49034d18                         add rcx, qword ptr [r13 + 0x18]
000083a6 48894c2440                       mov qword ptr [rsp + 0x40], rcx
000083ab 33f6                             xor esi, esi
000083ad 85d2                             test edx, edx
000083af 0f8e88000000                     jle 0x843d
000083b5 6666660f1f840000000000           nop word ptr [rax + rax]
000083c0 f30f107338                       movss xmm6, dword ptr [rbx + 0x38]
000083c5 f3440f1017                       movss xmm10, dword ptr [rdi]
000083ca f3440f104f04                     movss xmm9, dword ptr [rdi + 4]
000083d0 f3440f104708                     movss xmm8, dword ptr [rdi + 8]
000083d6 f30f107f0c                       movss xmm7, dword ptr [rdi + 0xc]
000083db 4c8d4c2440                       lea r9, [rsp + 0x40]
000083e0 458bc6                           mov r8d, r14d
000083e3 8bd6                             mov edx, esi
000083e5 498bcd                           mov rcx, r13
000083e8 e8d3ee0000                       call 0x172c0
000083ed f3440f59c6                       mulss xmm8, xmm6
000083f2 f3450f5dc3                       minss xmm8, xmm11
000083f7 f3440f59ce                       mulss xmm9, xmm6
000083fc f3450f5dcb                       minss xmm9, xmm11
00008401 f3440f59d6                       mulss xmm10, xmm6
00008406 f3450f5dd3                       minss xmm10, xmm11
0000840b 488b442440                       mov rax, qword ptr [rsp + 0x40]
00008410 4889442420                       mov qword ptr [rsp + 0x20], rax
00008415 0f28df                           movaps xmm3, xmm7
00008418 410f28d0                         movaps xmm2, xmm8
0000841c 410f28c9                         movaps xmm1, xmm9
00008420 410f28c2                         movaps xmm0, xmm10
00008424 e867f00000                       call 0x17490
00008429 ffc6                             inc esi
0000842b 488d7f10                         lea rdi, [rdi + 0x10]
0000842f 488344244010                     add qword ptr [rsp + 0x40], 0x10
00008435 418b5524                         mov edx, dword ptr [r13 + 0x24]
00008439 3bf2                             cmp esi, edx
0000843b 7c83                             jl 0x83c0
0000843d 41ffc6                           inc r14d
00008440 453b7528                         cmp r14d, dword ptr [r13 + 0x28]
00008444 0f8c36ffffff                     jl 0x8380
0000844a 488b7c2448                       mov rdi, qword ptr [rsp + 0x48]
0000844f 488b542458                       mov rdx, qword ptr [rsp + 0x58]
00008454 488bcf                           mov rcx, rdi
00008457 e8f4000000                       call 0x8550
0000845c 488b542458                       mov rdx, qword ptr [rsp + 0x58]
00008461 488bcf                           mov rcx, rdi
00008464 e887010000                       call 0x85f0
00008469 488b542460                       mov rdx, qword ptr [rsp + 0x60]
0000846e 488bcf                           mov rcx, rdi
00008471 e8da000000                       call 0x8550
00008476 488b542460                       mov rdx, qword ptr [rsp + 0x60]
0000847b 488bcf                           mov rcx, rdi
0000847e e86d010000                       call 0x85f0
00008483 488b542468                       mov rdx, qword ptr [rsp + 0x68]
00008488 488bcf                           mov rcx, rdi
0000848b e8c0000000                       call 0x8550
00008490 488b542468                       mov rdx, qword ptr [rsp + 0x68]
00008495 488bcf                           mov rcx, rdi
00008498 e853010000                       call 0x85f0
0000849d 488b542470                       mov rdx, qword ptr [rsp + 0x70]
000084a2 488bcf                           mov rcx, rdi
000084a5 e8a6000000                       call 0x8550
000084aa 488b542470                       mov rdx, qword ptr [rsp + 0x70]
000084af 488bcf                           mov rcx, rdi
000084b2 e839010000                       call 0x85f0
000084b7 488b542478                       mov rdx, qword ptr [rsp + 0x78]
000084bc 488bcf                           mov rcx, rdi
000084bf e88c000000                       call 0x8550
000084c4 488b542478                       mov rdx, qword ptr [rsp + 0x78]
000084c9 488bcf                           mov rcx, rdi
000084cc e81f010000                       call 0x85f0
000084d1 837b5003                         cmp dword ptr [rbx + 0x50], 3
000084d5 7510                             jne 0x84e7
000084d7 488d5590                         lea rdx, [rbp - 0x70]
000084db 488b8fb8000000                   mov rcx, qword ptr [rdi + 0xb8]
000084e2 ff5708                           call qword ptr [rdi + 8]
000084e5 eb0c                             jmp 0x84f3
000084e7 488d8bb0000000                   lea rcx, [rbx + 0xb0]
000084ee e8bd120000                       call 0x97b0
000084f3 488b8da0c90300                   mov rcx, qword ptr [rbp + 0x3c9a0]
000084fa 4833cc                           xor rcx, rsp
000084fd e8be4b0100                       call 0x1d0c0
00008502 4c8d9c2410cb0300                 lea r11, [rsp + 0x3cb10]
0000850a 498b5b48                         mov rbx, qword ptr [r11 + 0x48]
0000850e 410f2873f0                       movaps xmm6, xmmword ptr [r11 - 0x10]
00008513 410f287be0                       movaps xmm7, xmmword ptr [r11 - 0x20]
00008518 450f2843d0                       movaps xmm8, xmmword ptr [r11 - 0x30]
0000851d 450f284bc0                       movaps xmm9, xmmword ptr [r11 - 0x40]
00008522 450f2853b0                       movaps xmm10, xmmword ptr [r11 - 0x50]
00008527 450f285ba0                       movaps xmm11, xmmword ptr [r11 - 0x60]
0000852c 498be3                           mov rsp, r11
0000852f 415f                             pop r15
00008531 415e                             pop r14
00008533 415d                             pop r13
00008535 415c                             pop r12
00008537 5f                               pop rdi
00008538 5e                               pop rsi
00008539 5d                               pop rbp
0000853a c3                               ret 
0000853b cc                               int3 
0000853c cc                               int3 
0000853d cc                               int3 
0000853e cc                               int3 
0000853f cc                               int3 

# RVA 8690..8930
00008690 48895c2408                       mov qword ptr [rsp + 8], rbx
00008695 48896c2410                       mov qword ptr [rsp + 0x10], rbp
0000869a 4889742418                       mov qword ptr [rsp + 0x18], rsi
0000869f 57                               push rdi
000086a0 4883ec30                         sub rsp, 0x30
000086a4 488b6c2460                       mov rbp, qword ptr [rsp + 0x60]
000086a9 498bf9                           mov rdi, r9
000086ac 488bf1                           mov rsi, rcx
000086af 488bd1                           mov rdx, rcx
000086b2 488bcd                           mov rcx, rbp
000086b5 4983c120                         add r9, 0x20
000086b9 41b801000000                     mov r8d, 1
000086bf e82c5f0000                       call 0xe5f0
000086c4 488d4730                         lea rax, [rdi + 0x30]
000086c8 41b802000000                     mov r8d, 2
000086ce 4c8d4f28                         lea r9, [rdi + 0x28]
000086d2 4889442420                       mov qword ptr [rsp + 0x20], rax
000086d7 488bd6                           mov rdx, rsi
000086da 488bcd                           mov rcx, rbp
000086dd e87e570000                       call 0xde60
000086e2 4c8d4f64                         lea r9, [rdi + 0x64]
000086e6 41b804000000                     mov r8d, 4
000086ec 488bd6                           mov rdx, rsi
000086ef 488bcd                           mov rcx, rbp
000086f2 e8795b0000                       call 0xe270
000086f7 4c8d4f54                         lea r9, [rdi + 0x54]
000086fb 41b81c000000                     mov r8d, 0x1c
00008701 488bd6                           mov rdx, rsi
00008704 488bcd                           mov rcx, rbp
00008707 e8e45e0000                       call 0xe5f0
0000870c 4c8d4f58                         lea r9, [rdi + 0x58]
00008710 41b81d000000                     mov r8d, 0x1d
00008716 488bd6                           mov rdx, rsi
00008719 488bcd                           mov rcx, rbp
0000871c e84f5b0000                       call 0xe270
00008721 4c8d4f6c                         lea r9, [rdi + 0x6c]
00008725 41b805000000                     mov r8d, 5
0000872b 488bd6                           mov rdx, rsi
0000872e 488bcd                           mov rcx, rbp
00008731 e83a5b0000                       call 0xe270
00008736 4c8d4f68                         lea r9, [rdi + 0x68]
0000873a 41b808000000                     mov r8d, 8
00008740 488bd6                           mov rdx, rsi
00008743 488bcd                           mov rcx, rbp
00008746 e8255b0000                       call 0xe270
0000874b 4c8d4f5c                         lea r9, [rdi + 0x5c]
0000874f 41b81e000000                     mov r8d, 0x1e
00008755 488bd6                           mov rdx, rsi
00008758 488bcd                           mov rcx, rbp
0000875b e8905e0000                       call 0xe5f0
00008760 4c8d4f60                         lea r9, [rdi + 0x60]
00008764 41b81f000000                     mov r8d, 0x1f
0000876a 488bd6                           mov rdx, rsi
0000876d 488bcd                           mov rcx, rbp
00008770 e8fb5a0000                       call 0xe270
00008775 4c8d4f70                         lea r9, [rdi + 0x70]
00008779 41b809000000                     mov r8d, 9
0000877f 488bd6                           mov rdx, rsi
00008782 488bcd                           mov rcx, rbp
00008785 e8e65a0000                       call 0xe270
0000878a 4c8d4f74                         lea r9, [rdi + 0x74]
0000878e 41b81a000000                     mov r8d, 0x1a
00008794 488bd6                           mov rdx, rsi
00008797 488bcd                           mov rcx, rbp
0000879a e8f1590000                       call 0xe190
0000879f 4c8d4f78                         lea r9, [rdi + 0x78]
000087a3 41b80c000000                     mov r8d, 0xc
000087a9 488bd6                           mov rdx, rsi
000087ac 488bcd                           mov rcx, rbp
000087af e87c5c0000                       call 0xe430
000087b4 4c8d4f7c                         lea r9, [rdi + 0x7c]
000087b8 41b80d000000                     mov r8d, 0xd
000087be 488bd6                           mov rdx, rsi
000087c1 488bcd                           mov rcx, rbp
000087c4 e8075f0000                       call 0xe6d0
000087c9 660f6e477c                       movd xmm0, dword ptr [rdi + 0x7c]
000087ce 4c8d8f80000000                   lea r9, [rdi + 0x80]
000087d5 f30fe6c0                         cvtdq2pd xmm0, xmm0
000087d9 41b80f000000                     mov r8d, 0xf
000087df 488bd6                           mov rdx, rsi
000087e2 488bcd                           mov rcx, rbp
000087e5 f20f5905eb8a0100                 mulsd xmm0, qword ptr [rip + 0x18aeb]
000087ed f20f2cc0                         cvttsd2si eax, xmm0
000087f1 89477c                           mov dword ptr [rdi + 0x7c], eax
000087f4 e8375c0000                       call 0xe430
000087f9 f30f108f80000000                 movss xmm1, dword ptr [rdi + 0x80]
00008801 0f57c0                           xorps xmm0, xmm0
00008804 0f2fc8                           comiss xmm1, xmm0
00008807 760e                             jbe 0x8817
00008809 f30f1005c38a0100                 movss xmm0, dword ptr [rip + 0x18ac3]
00008811 f30f5ec1                         divss xmm0, xmm1
00008815 eb08                             jmp 0x881f
00008817 f30f1005b18a0100                 movss xmm0, dword ptr [rip + 0x18ab1]
0000881f 4c8d4f38                         lea r9, [rdi + 0x38]
00008823 f30f118780000000                 movss dword ptr [rdi + 0x80], xmm0
0000882b 41b810000000                     mov r8d, 0x10
00008831 488bd6                           mov rdx, rsi
00008834 488bcd                           mov rcx, rbp
00008837 e8f45b0000                       call 0xe430
0000883c 4c8d4f40                         lea r9, [rdi + 0x40]
00008840 41b811000000                     mov r8d, 0x11
00008846 488bd6                           mov rdx, rsi
00008849 488bcd                           mov rcx, rbp
0000884c e8df5b0000                       call 0xe430
00008851 f30f104740                       movss xmm0, dword ptr [rdi + 0x40]
00008856 4c8d4f3c                         lea r9, [rdi + 0x3c]
0000885a f30f5905968d0100                 mulss xmm0, dword ptr [rip + 0x18d96]
00008862 41b813000000                     mov r8d, 0x13
00008868 488bd6                           mov rdx, rsi
0000886b 488bcd                           mov rcx, rbp
0000886e f30f114740                       movss dword ptr [rdi + 0x40], xmm0
00008873 0f5ac0                           cvtps2pd xmm0, xmm0
00008876 660f2f05828d0100                 comisd xmm0, xmmword ptr [rip + 0x18d82]
0000887e 0f97c0                           seta al
00008881 884744                           mov byte ptr [rdi + 0x44], al
00008884 e8a75b0000                       call 0xe430
00008889 f30f10473c                       movss xmm0, dword ptr [rdi + 0x3c]
0000888e 4c8d4f50                         lea r9, [rdi + 0x50]
00008892 f30f59055e8d0100                 mulss xmm0, dword ptr [rip + 0x18d5e]
0000889a 41b814000000                     mov r8d, 0x14
000088a0 488bd6                           mov rdx, rsi
000088a3 488bcd                           mov rcx, rbp
000088a6 f30f11473c                       movss dword ptr [rdi + 0x3c], xmm0
000088ab e8405d0000                       call 0xe5f0
000088b0 837f5003                         cmp dword ptr [rdi + 0x50], 3
000088b4 7518                             jne 0x88ce
000088b6 4c8b8fa8000000                   mov r9, qword ptr [rdi + 0xa8]
000088bd 41b815000000                     mov r8d, 0x15
000088c3 488bd6                           mov rdx, rsi
000088c6 488bcd                           mov rcx, rbp
000088c9 e802510000                       call 0xd9d0
000088ce 4c8d8ffc000000                   lea r9, [rdi + 0xfc]
000088d5 41b816000000                     mov r8d, 0x16
000088db 488bd6                           mov rdx, rsi
000088de 488bcd                           mov rcx, rbp
000088e1 e88a590000                       call 0xe270
000088e6 4c8d8f00010000                   lea r9, [rdi + 0x100]
000088ed 41b817000000                     mov r8d, 0x17
000088f3 488bd6                           mov rdx, rsi
000088f6 488bcd                           mov rcx, rbp
000088f9 e8b25e0000                       call 0xe7b0
000088fe 4c8d8f04010000                   lea r9, [rdi + 0x104]
00008905 41b818000000                     mov r8d, 0x18
0000890b 488bd6                           mov rdx, rsi
0000890e 488bcd                           mov rcx, rbp
00008911 488b5c2440                       mov rbx, qword ptr [rsp + 0x40]
00008916 488b6c2448                       mov rbp, qword ptr [rsp + 0x48]
0000891b 488b742450                       mov rsi, qword ptr [rsp + 0x50]
00008920 4883c430                         add rsp, 0x30
00008924 5f                               pop rdi
00008925 e9065b0000                       jmp 0xe430
0000892a cc                               int3 
0000892b cc                               int3 
0000892c cc                               int3 
0000892d cc                               int3 
0000892e cc                               int3 
0000892f cc                               int3 

# RVA 9360..9380
00009360 488bc1                           mov rax, rcx
00009363 c3                               ret 
00009364 cc                               int3 
00009365 cc                               int3 
00009366 cc                               int3 
00009367 cc                               int3 
00009368 cc                               int3 
00009369 cc                               int3 
0000936a cc                               int3 
0000936b cc                               int3 
0000936c cc                               int3 
0000936d cc                               int3 
0000936e cc                               int3 
0000936f cc                               int3 
00009370 c20000                           ret 0
00009373 cc                               int3 
00009374 cc                               int3 
00009375 cc                               int3 
00009376 cc                               int3 
00009377 cc                               int3 
00009378 cc                               int3 
00009379 cc                               int3 
0000937a cc                               int3 
0000937b cc                               int3 
0000937c cc                               int3 
0000937d cc                               int3 
0000937e cc                               int3 
0000937f cc                               int3 

# RVA d9d0..daa0
0000d9d0 48895c2408                       mov qword ptr [rsp + 8], rbx
0000d9d5 55                               push rbp
0000d9d6 56                               push rsi
0000d9d7 57                               push rdi
0000d9d8 4881ecf0000000                   sub rsp, 0xf0
0000d9df 488b0592d70100                   mov rax, qword ptr [rip + 0x1d792]
0000d9e6 4833c4                           xor rax, rsp
0000d9e9 48898424e0000000                 mov qword ptr [rsp + 0xe0], rax
0000d9f1 488bd9                           mov rbx, rcx
0000d9f4 498be9                           mov rbp, r9
0000d9f7 488d4c2430                       lea rcx, [rsp + 0x30]
0000d9fc 418bf8                           mov edi, r8d
0000d9ff 488bf2                           mov rsi, rdx
0000da02 e8c9c80000                       call 0x1a2d0
0000da07 8b96f0000000                     mov edx, dword ptr [rsi + 0xf0]
0000da0d 488d8b88000000                   lea rcx, [rbx + 0x88]
0000da14 4883c308                         add rbx, 8
0000da18 483bd9                           cmp rbx, rcx
0000da1b 7410                             je 0xda2d
0000da1d 488bc3                           mov rax, rbx
0000da20 3938                             cmp dword ptr [rax], edi
0000da22 7471                             je 0xda95
0000da24 4883c004                         add rax, 4
0000da28 483bc1                           cmp rax, rcx
0000da2b 75f3                             jne 0xda20
0000da2d b8ffffffff                       mov eax, 0xffffffff
0000da32 448b8ee4000000                   mov r9d, dword ptr [rsi + 0xe4]
0000da39 488d4c2430                       lea rcx, [rsp + 0x30]
0000da3e 448b86e0000000                   mov r8d, dword ptr [rsi + 0xe0]
0000da45 48894c2428                       mov qword ptr [rsp + 0x28], rcx
0000da4a 488bce                           mov rcx, rsi
0000da4d 89542420                         mov dword ptr [rsp + 0x20], edx
0000da51 8bd0                             mov edx, eax
0000da53 e8b8c80000                       call 0x1a310
0000da58 488bd5                           mov rdx, rbp
0000da5b 488d4c2430                       lea rcx, [rsp + 0x30]
0000da60 e8bbc40000                       call 0x19f20
0000da65 488d542430                       lea rdx, [rsp + 0x30]
0000da6a 488bce                           mov rcx, rsi
0000da6d e81ec90000                       call 0x1a390
0000da72 488b8c24e0000000                 mov rcx, qword ptr [rsp + 0xe0]
0000da7a 4833cc                           xor rcx, rsp
0000da7d e83ef60000                       call 0x1d0c0
0000da82 488b9c2410010000                 mov rbx, qword ptr [rsp + 0x110]
0000da8a 4881c4f0000000                   add rsp, 0xf0
0000da91 5f                               pop rdi
0000da92 5e                               pop rsi
0000da93 5d                               pop rbp
0000da94 c3                               ret 
0000da95 482bc3                           sub rax, rbx
0000da98 48c1f802                         sar rax, 2
0000da9c eb94                             jmp 0xda32
0000da9e cc                               int3 
0000da9f cc                               int3 

# RVA 19f20..19f80
00019f20 0f104138                         movups xmm0, xmmword ptr [rcx + 0x38]
00019f24 0f1102                           movups xmmword ptr [rdx], xmm0
00019f27 0f104948                         movups xmm1, xmmword ptr [rcx + 0x48]
00019f2b 0f114a10                         movups xmmword ptr [rdx + 0x10], xmm1
00019f2f 0f104158                         movups xmm0, xmmword ptr [rcx + 0x58]
00019f33 0f114220                         movups xmmword ptr [rdx + 0x20], xmm0
00019f37 0f104968                         movups xmm1, xmmword ptr [rcx + 0x68]
00019f3b 0f114a30                         movups xmmword ptr [rdx + 0x30], xmm1
00019f3f 0f104178                         movups xmm0, xmmword ptr [rcx + 0x78]
00019f43 0f114240                         movups xmmword ptr [rdx + 0x40], xmm0
00019f47 0f108988000000                   movups xmm1, xmmword ptr [rcx + 0x88]
00019f4e 0f114a50                         movups xmmword ptr [rdx + 0x50], xmm1
00019f52 0f108198000000                   movups xmm0, xmmword ptr [rcx + 0x98]
00019f59 0f114260                         movups xmmword ptr [rdx + 0x60], xmm0
00019f5d f20f1089a8000000                 movsd xmm1, qword ptr [rcx + 0xa8]
00019f65 f20f114a70                       movsd qword ptr [rdx + 0x70], xmm1
00019f6a c3                               ret 
00019f6b cc                               int3 
00019f6c cc                               int3 
00019f6d cc                               int3 
00019f6e cc                               int3 
00019f6f cc                               int3 
00019f70 cc                               int3 
00019f71 cc                               int3 
00019f72 cc                               int3 
00019f73 cc                               int3 
00019f74 cc                               int3 
00019f75 cc                               int3 
00019f76 cc                               int3 
00019f77 cc                               int3 
00019f78 cc                               int3 
00019f79 cc                               int3 
00019f7a cc                               int3 
00019f7b cc                               int3 
00019f7c cc                               int3 
00019f7d cc                               int3 
00019f7e cc                               int3 
00019f7f cc                               int3 
