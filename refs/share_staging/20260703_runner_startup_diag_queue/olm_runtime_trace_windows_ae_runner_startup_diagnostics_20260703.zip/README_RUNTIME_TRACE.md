# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `windows_ae_runner_startup_diagnostics_20260703`
   - Area: Windows AE runner startup / request-dispatch diagnostics
   - Action: LIVE NEW DIAGNOSTIC REQUIRED. Do not begin with plugin-local witness breakpoints. Use the exact-case requests that recently stalled before module load: `legacy_case_0004_current_aex` from `smoother2_legacy_full_current_aex_recapture_20260621` and `db_existing_case_0001_software_pair` from `directionalblur_context_scale_20260606`. Follow `refs/conformance/windows_ae_runner_startup_diagnostics_20260703.md` and return a stage-by-stage ledger for AE launch -> startup scripts -> JSX runner invocation -> request directory resolution -> request JSON enumeration -> case-id resolution -> dispatch start -> target plugin module load. Include the exact invocation used, the final request dir path seen by the runner, the final case id seen by the runner, whether `ae_runner_log.txt` or `run_complete.json` creation was attempted, and the exact last startup/runner line before timeout. If the JSX side falls back to a default request dir, report that explicit path.
   - Stop: A satisfactory answer must return runner-stage evidence that classifies the first stage that fails to advance. Another timeout with only AE startup banners or only `sxe ld:<module>` setup counts as failure.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
