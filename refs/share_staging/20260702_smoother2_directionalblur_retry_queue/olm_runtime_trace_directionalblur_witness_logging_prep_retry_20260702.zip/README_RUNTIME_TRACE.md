# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `olmdirectionalblur_witness_logging_prep_20260702`
   - Area: OLMDirectionalBlur witness-level A/B denominator validity logging prep
   - Action: LIVE NEW TRACE REQUIRED. Do not answer from retained evidence, old notes, or package prose. If OLMDirectionalBlur fails to resolve as a loaded module, treat that load failure itself as the primary debugging target and return the exact module-load / breakpoint-bind failure details. Trace only the two active OLMDirectionalBlur Software witness lanes using the concrete logging contract in `refs/conformance/olmdirectionalblur_witness_logging_prep_20260702.md`. Stay on the current AEX-shaped `rotated-aex-full-choreo` structural base and do not satisfy this request with broad PNG rerenders, candidate-matrix prose, or final-byte-only logs. For the angle-0 lane, keep primary `(494,169)` and also include the right-edge endpoint `(579,169)` in the same pass. Record normalized parameters, A/B image pointers, output-to-A/B xy mapping, denominator plane pointer/value, `alpha_or_valid` pointer/value, accumulation numerator RGBA, pre-writeback RGBA float/hex, final stored RGBA bytes, and helper-local source x/y plus actual touched destination x range on row `y=169`, including rowdriver/group membership for both witnesses. For the diagonal lane, keep primary `(507,367)` and a signed-red companion such as `(423,187)` when possible. Record the same shared fields plus rotate sampler source coordinates/order, border or validity decision, and the group-size or opacity gate feeding the diagonal witness.
   - Stop: Treat this request as answered only if at least one lane returns typed denominator + `alpha_or_valid`/validity + pre-writeback evidence in the same witness record. Angle-0 is not answered if the run omits helper-local touched destination range for `(494,169)` and `(579,169)`. Diagonal is not answered if sampler order or border-validity is described only qualitatively. Final PNG bytes or broad means alone are not enough. A retained-evidence rewrite counts as failure, not partial success.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
