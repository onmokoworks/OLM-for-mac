[CmdletBinding()]
param(
  [string]$PluginPath = 'C:\\Program Files\\Adobe\\Common\\Plug-ins\\7.0\\MediaCore\\OLM\\OLMBlur.aex',
  [string]$AfterFX = 'C:\\Program Files\\Adobe\\Adobe After Effects 2026\\Support Files\\AfterFX.exe',
  [string]$OutputDir = (Join-Path $PSScriptRoot 'return')
)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$ExpectedHash = 'f0611785e7b14ac4fcfc75f23b8862beb4539eee52d25d472556849535e96e5b'
$ExpectedInputHash = 'cc1bf1aa128dea6197405ee722c66198fb5fcbc213bf2569c7af9f30be4fa4f4'
$ExpectedTemplate = 'OLM EXR 32 Float'
$RequestId = 'olmblur_32bpc_case0001_repeat1_provenance_request_20260718'
$RunNonce = [guid]::NewGuid().ToString('N')
$RunId = 'olmblur-case0001-' + [guid]::NewGuid().ToString('N')
$RunDir = Join-Path $OutputDir $RunId
$ReturnZip = Join-Path $OutputDir ($RequestId + '-' + $RunId + '.zip')
$script:ActiveAePids = @()
$script:Launch = $null
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
$StatusPath = Join-Path $RunDir 'status.json'
$ManifestPath = Join-Path $RunDir 'return_manifest.json'
$ReadyMarker = Join-Path $RunDir 'ae_ready.marker'
$ContinueMarker = Join-Path $RunDir 'ae_continue.marker'
$AbortMarker = Join-Path $RunDir 'ae_abort.marker'
$LaunchStdout = Join-Path $RunDir 'afterfx_launcher_stdout.txt'
$LaunchStderr = Join-Path $RunDir 'afterfx_launcher_stderr.txt'
function Write-Json([string]$Path, [object]$Value) { $Value | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $Path -Encoding UTF8 }
function Read-OrNull([string]$Path) { if (Test-Path -LiteralPath $Path -PathType Leaf) { return Get-Content -LiteralPath $Path -Raw }; return $null }
function Get-CimProcess([int]$Id) { Get-CimInstance Win32_Process -Filter ("ProcessId=" + $Id) -ErrorAction SilentlyContinue }
function Convert-CimProcessRecord([object]$Process) {
  if ($null -eq $Process) { return $null }
  return [ordered]@{pid=[int]$Process.ProcessId;parent_pid=[int]$Process.ParentProcessId;session_id=[int]$Process.SessionId;started_utc=$Process.CreationDate.ToUniversalTime().ToString('o');path=$Process.ExecutablePath;command_line=$Process.CommandLine}
}
function Get-LaunchRelation([int]$ActualPid, [int]$LauncherPid) {
  if ($ActualPid -eq $LauncherPid) { return 'launcher-pid' }
  $cursor = $ActualPid
  for ($index = 0; $index -lt 8; $index++) {
    $process = Get-CimProcess $cursor
    if ($null -eq $process) { break }
    $parent = [int]$process.ParentProcessId
    if ($parent -eq $LauncherPid) { return 'descendant-of-launcher' }
    $cursor = $parent
  }
  return $null
}
function Get-AfterFxState {
  if ([string]::IsNullOrWhiteSpace($script:ExpectedAfterFxPath)) { return @() }
  @(Get-CimInstance Win32_Process -Filter "Name='AfterFX.exe'" -ErrorAction SilentlyContinue | Where-Object {
    $_.SessionId -eq $script:SessionId -and $_.ExecutablePath -and [IO.Path]::GetFullPath($_.ExecutablePath) -ieq $script:ExpectedAfterFxPath
  } | ForEach-Object { [ordered]@{pid=[int]$_.ProcessId;parent_pid=[int]$_.ParentProcessId;session_id=[int]$_.SessionId;started_utc=$_.CreationDate.ToUniversalTime().ToString('o');path=$_.ExecutablePath;command_line=$_.CommandLine} })
}
function Get-AexObservation([string]$ExpectedPath) {
  $rows = @()
  foreach ($state in @(Get-AfterFxState)) {
    $record = [ordered]@{pid=[int]$state.pid;parent_pid=[int]$state.parent_pid;module_enumeration='not_attempted';olmblur_modules=@();error=$null}
    try {
      $process = Get-Process -Id $state.pid -ErrorAction Stop
      $record.module_enumeration = 'ok'
      $record.olmblur_modules = @($process.Modules | Where-Object { [IO.Path]::GetFileName($_.FileName) -ieq 'OLMBlur.aex' } | ForEach-Object {
        [ordered]@{path=$_.FileName;is_expected_path=($_.FileName -ieq $ExpectedPath);base_address=('0x{0:x}' -f $_.BaseAddress.ToInt64())}
      })
    } catch { $record.module_enumeration = 'error'; $record.error = $_.Exception.Message }
    $rows += $record
  }
  return @($rows)
}
function Get-RuntimeDiagnostics([string]$ExpectedPath) {
  $launchState = $null
  if ($null -ne $script:Launch) {
    try { $script:Launch.Refresh(); $launchState = [ordered]@{pid=[int]$script:Launch.Id;has_exited=[bool]$script:Launch.HasExited;exit_code=$(if ($script:Launch.HasExited) { try { $script:Launch.ExitCode } catch { $null } } else { $null })} } catch { $launchState = [ordered]@{error=$_.Exception.Message} }
  }
  return [ordered]@{launcher=$launchState;candidate_afterfx=@(Get-AfterFxState);aex_observation=@(Get-AexObservation $ExpectedPath);ready_marker=(Read-OrNull $ReadyMarker);ae_log=(Read-OrNull (Join-Path $RunDir 'same_run.log'));ae_result=(Read-OrNull (Join-Path $RunDir 'same_run.result.json'));launcher_stdout=(Read-OrNull $LaunchStdout);launcher_stderr=(Read-OrNull $LaunchStderr)}
}
function Fail-Closed([string]$Stage, [string]$Reason, [object]$Detail=$null) {
  $diagnostics = Get-RuntimeDiagnostics $PluginPath
  Set-Content -LiteralPath $AbortMarker -Value ("stage=" + $Stage + "`nreason=" + $Reason) -Encoding UTF8 -ErrorAction SilentlyContinue
  $killPids = @($script:ActiveAePids + @(Get-AfterFxState | ForEach-Object { $_.pid }) | Select-Object -Unique)
  foreach ($pidValue in $killPids) { try { Stop-Process -Id $pidValue -Force -ErrorAction SilentlyContinue; Wait-Process -Id $pidValue -Timeout 30 -ErrorAction SilentlyContinue } catch {} }
  $script:ActiveAePids = @()
  $body = [ordered]@{ schema='olmblur-32bpc-case0001-return-v1'; request_id=$RequestId; run_id=$RunId; status='exact_bind_failure'; failure=[ordered]@{stage=$Stage; reason=$Reason; detail=$Detail;runtime_diagnostics=$diagnostics} }
  Write-Json $StatusPath $body; Write-Json $ManifestPath $body
  try { if (Test-Path -LiteralPath $ReturnZip) { Remove-Item -LiteralPath $ReturnZip -Force }; Compress-Archive -Path (Join-Path $RunDir '*') -DestinationPath $ReturnZip -CompressionLevel Optimal } catch { [Console]::Error.WriteLine("evidence_archive_failure: $($_.Exception.Message)"); exit 3 }
  [Console]::Error.WriteLine("$Stage`: $Reason"); exit 2
}
function Read-Json([string]$Path) { if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "missing JSON: $Path" }; Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json }
function Resolve-RenderedExr([object]$Result, [string]$Label, [string]$ExpectedRoot) {
  $reported = [string]$Result.output_exr
  if ([string]::IsNullOrWhiteSpace($reported)) { throw "$Label result JSON did not report output_exr" }
  $expectedPrefix = [IO.Path]::GetFullPath($ExpectedRoot).TrimEnd('\') + '\'
  $reportedFull = [IO.Path]::GetFullPath($reported)
  if (-not $reportedFull.StartsWith($expectedPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw "$Label reported EXR escaped the current output directory: $reported" }
  if (-not (Test-Path -LiteralPath $reported -PathType Leaf)) { throw "$Label reported EXR does not exist: $reported" }
  $file = Get-Item -LiteralPath $reported
  if ($file.Extension -ine '.exr' -or $file.Length -le 0) { throw "$Label reported path is not a non-empty EXR: $reported" }
  return $file
}
try {
  if (-not (Test-Path -LiteralPath $PluginPath -PathType Leaf)) { Fail-Closed 'preflight' 'missing OLMBlur.aex' $PluginPath }
  $plugin = Get-Item -LiteralPath $PluginPath
  if ($plugin.Name -cne 'OLMBlur.aex') { Fail-Closed 'preflight' 'PluginPath must name OLMBlur.aex' $plugin.FullName }
  $hash = (Get-FileHash -LiteralPath $plugin.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  $pluginRecord = [ordered]@{path=$plugin.FullName;size_bytes=[int64]$plugin.Length;last_write_time_utc=$plugin.LastWriteTimeUtc.ToString('o');sha256=$hash;required_sha256=$ExpectedHash}
  if ($hash -ne $ExpectedHash) { Fail-Closed 'preflight' 'OLMBlur.aex SHA-256 mismatch; AE was not started' $pluginRecord }
  if (-not (Test-Path -LiteralPath $AfterFX -PathType Leaf)) { Fail-Closed 'preflight' 'AfterFX.exe is missing; AE was not started' $AfterFX }
  $AfterFX = (Get-Item -LiteralPath $AfterFX).FullName
  $script:ExpectedAfterFxPath = $AfterFX
  $script:SessionId = (Get-Process -Id $PID -ErrorAction Stop).SessionId
  $inputPath = Join-Path $Root 'input\case_0001_before_effects.png'
  if (-not (Test-Path -LiteralPath $inputPath -PathType Leaf)) { Fail-Closed 'preflight' 'packaged input is missing' $inputPath }
  $inputHash = (Get-FileHash -LiteralPath $inputPath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($inputHash -ne $ExpectedInputHash) { Fail-Closed 'preflight' 'packaged input SHA-256 mismatch; AE was not started' ([ordered]@{expected=$ExpectedInputHash;actual=$inputHash}) }
  $preexisting = @(Get-Process -Name AfterFX -ErrorAction SilentlyContinue)
  if ($preexisting.Count -ne 0) { Fail-Closed 'preflight' 'close every existing AfterFX process before running this package' @($preexisting | ForEach-Object { $_.Id }) }
  $contractFiles = [ordered]@{
    input = $inputPath
    request_manifest = (Join-Path $Root 'request_manifest.json')
    reference_manifest = (Join-Path $Root 'reference_manifest.json')
    renderer = (Join-Path $Root 'scripts\\ae_render_single_case.jsx')
    package_manifest = (Join-Path $Root 'manifest.json')
    runner = (Join-Path $Root 'run_olmblur_32bpc_case0001.ps1')
  }
  $contractPath = Join-Path $Root 'package_contract.json'
  $contract = Read-Json $contractPath
  if ([string]$contract.request_id -ne $RequestId) { Fail-Closed 'preflight' 'package contract request ID mismatch' $contract.request_id }
  $contractHashes = [ordered]@{}
  foreach ($entry in $contractFiles.GetEnumerator()) {
    if (-not (Test-Path -LiteralPath $entry.Value -PathType Leaf)) { Fail-Closed 'preflight' "missing contract artifact $($entry.Key)" $entry.Value }
    $actualContractHash = (Get-FileHash -LiteralPath $entry.Value -Algorithm SHA256).Hash.ToLowerInvariant()
    $expectedContractHash = [string]$contract.artifacts.($entry.Key).sha256
    if ([string]::IsNullOrWhiteSpace($expectedContractHash) -or $actualContractHash -ne $expectedContractHash) { Fail-Closed 'preflight' "contract artifact SHA-256 mismatch: $($entry.Key)" ([ordered]@{expected=$expectedContractHash;actual=$actualContractHash}) }
    $contractHashes[$entry.Key] = $actualContractHash
  }
  $packageContractHash = (Get-FileHash -LiteralPath $contractPath -Algorithm SHA256).Hash.ToLowerInvariant()
  $out = Join-Path $RunDir 'same_run'; New-Item -ItemType Directory -Force -Path $out | Out-Null
  $resultPath = Join-Path $RunDir 'same_run.result.json'; $logPath = Join-Path $RunDir 'same_run.log'
  $env:OLM_AE_REQUEST_DIR = $Root; $env:OLM_AE_CASE_ID = 'olmblur__case_0001'; $env:OLM_AE_OUTPUT_DIR = $out
  $env:OLM_AE_LOG_PATH = $logPath; $env:OLM_AE_RESULT_JSON = $resultPath; $env:OLM_AE_OUTPUT_MODE = 'exr_render_queue'; $env:OLM_AE_OUTPUT_TEMPLATE = $ExpectedTemplate
  $env:OLM_AE_FORCE_SOFTWARE = '1'; $env:OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT = '1'; $env:OLM_AE_FORCE_NEW_PROJECT = '1'; $env:OLM_AE_DISABLE_EFFECT = '0'; $env:OLM_AE_KEEP_OPEN = '0'
  $env:OLM_AE_PAUSE_BEFORE_RENDER = '1'; $env:OLM_AE_READY_MARKER = $ReadyMarker; $env:OLM_AE_CONTINUE_MARKER = $ContinueMarker; $env:OLM_AE_PAUSE_TIMEOUT_SECONDS = '300'; $env:OLM_AE_RUN_NONCE = $RunNonce; $env:OLM_AE_READY_CASE = 'olmblur__case_0001'
  $jsxPath = $contractFiles.renderer; $quotedJsxPath = '"' + $jsxPath + '"'
  $launchStarted = Get-Date
  $launch = Start-Process -FilePath $AfterFX -ArgumentList @('-r', $quotedJsxPath) -RedirectStandardOutput $LaunchStdout -RedirectStandardError $LaunchStderr -PassThru -WindowStyle Normal
  $script:Launch = $launch
  $script:ActiveAePids = @($launch.Id)
  $launchCim = $null; $launchDeadline = (Get-Date).AddSeconds(10)
  while ((Get-Date) -lt $launchDeadline -and $null -eq $launchCim) { $launchCim = Get-CimProcess $launch.Id; if ($null -eq $launchCim) { Start-Sleep -Milliseconds 100 } }
  if ($null -ne $launchCim) {
    $launchRecord = Convert-CimProcessRecord $launchCim
  } else {
    $launchSession = $null; $launchStartUtc = $null
    try { $launchSession = [int]$launch.SessionId } catch {}
    try { $launchStartUtc = $launch.StartTime.ToUniversalTime().ToString('o') } catch {}
    $launchRecord = [ordered]@{pid=[int]$launch.Id;parent_pid=$null;session_id=$launchSession;started_utc=$launchStartUtc;path=$AfterFX;command_line=$null}
  }
  $deadline = (Get-Date).AddSeconds(180)
  while ((Get-Date) -lt $deadline -and -not (Test-Path -LiteralPath $ReadyMarker -PathType Leaf)) {
    $script:ActiveAePids = @($script:ActiveAePids + @(Get-AfterFxState | ForEach-Object { $_.pid }) | Select-Object -Unique)
    Start-Sleep -Milliseconds 250
  }
  if (-not (Test-Path -LiteralPath $ReadyMarker -PathType Leaf)) { Fail-Closed 'ae_ready_gate' 'AE did not reach the effect-loaded, parameters-applied pause before render' (Get-RuntimeDiagnostics $plugin.FullName) }
  $readyText = Get-Content -LiteralPath $ReadyMarker -Raw
  try { $readyData = ConvertFrom-StringData $readyText } catch { Fail-Closed 'ae_ready_gate' 'AE ready marker is not key/value data' $readyText }
  if ($readyData.nonce -ne $RunNonce -or $readyData.case -ne 'olmblur__case_0001' -or $readyData.fixture -ne 'ae_render_single_case.jsx' -or $readyData.pid -notmatch '^\d+$' -or $readyData.effect_loaded -ne '1' -or $readyData.parameters_applied -ne '1') { Fail-Closed 'ae_ready_gate' 'AE ready marker identity mismatch' ([ordered]@{expected_nonce=$RunNonce;expected_case='olmblur__case_0001';actual=$readyText}) }
  $actualAePid = [int]$readyData.pid
  $actualCim = Get-CimProcess $actualAePid
  if ($null -eq $actualCim -or $actualCim.Name -ine 'AfterFX.exe' -or [IO.Path]::GetFullPath($actualCim.ExecutablePath) -ine $AfterFX -or [int]$actualCim.SessionId -ne $script:SessionId -or $actualCim.CreationDate -lt $launchStarted.AddSeconds(-2)) { Fail-Closed 'process_binding' 'ready marker PID is not the fresh in-session AfterFX executable launched for this request' ([ordered]@{ready=$readyText;candidate=$actualCim;launch_pid=[int]$launch.Id;launch_started=$launchStarted.ToUniversalTime().ToString('o')}) }
  $relation = Get-LaunchRelation $actualAePid $launch.Id
  if ([string]::IsNullOrWhiteSpace($relation)) { Fail-Closed 'process_binding' 'ready marker AfterFX PID is unrelated to this launch' ([ordered]@{actual_ae_pid=$actualAePid;launch_pid=[int]$launch.Id;candidate=$actualCim}) }
  $script:ActiveAePids = @($script:ActiveAePids + $actualAePid | Select-Object -Unique)
  $processBinding = [ordered]@{nonce=$RunNonce;ready_marker_raw=$readyText;caller_session_id=[int]$script:SessionId;launch_started_utc=$launchStarted.ToUniversalTime().ToString('o');launcher=$launchRecord;actual_afterfx=(Convert-CimProcessRecord $actualCim);relation=$relation;observed_afterfx=@(Get-AfterFxState)}
  $loaded = $null; $moduleAttempts = @(); $deadline = (Get-Date).AddSeconds(30)
  while ((Get-Date) -lt $deadline -and $null -eq $loaded) {
    $attempt = [ordered]@{ts_utc=(Get-Date).ToUniversalTime().ToString('o');target_pid=$actualAePid;get_process_ok=$false;modules_ok=$false;match_count=0;error_type=$null;error_message=$null}
    try {
      $boundProcess = Get-Process -Id $actualAePid -ErrorAction Stop; $attempt.get_process_ok = $true
      $matches = @($boundProcess.Modules | Where-Object { $_.FileName -ieq $plugin.FullName }); $attempt.modules_ok = $true; $attempt.match_count = $matches.Count
      if ($matches.Count -eq 1) { $loaded = [pscustomobject]@{process=$boundProcess;module=$matches[0]} }
    } catch { $attempt.error_type = $_.Exception.GetType().FullName; $attempt.error_message = $_.Exception.Message }
    $moduleAttempts += $attempt
    if ($null -eq $loaded) { Start-Sleep -Milliseconds 250 }
  }
  if ($null -eq $loaded) { Fail-Closed 'loaded_aex_gate' 'exact hash-pinned OLMBlur.aex was not observable in the pause-bound AfterFX PID' ([ordered]@{expected_plugin=$pluginRecord;binding=[ordered]@{nonce=$RunNonce;actual_ae_pid=$actualAePid;launch_pid=[int]$launch.Id;relation=$relation};module_probe_attempts=$moduleAttempts;observation=@(Get-AexObservation $plugin.FullName)}) }
  $loadedHash = (Get-FileHash -LiteralPath $loaded.module.FileName -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($loadedHash -ne $ExpectedHash) { Fail-Closed 'loaded_aex_gate' 'loaded OLMBlur.aex SHA-256 mismatch' ([ordered]@{expected_sha256=$ExpectedHash;actual_sha256=$loadedHash;path=$loaded.module.FileName;ae_pid=$loaded.process.Id}) }
  $loadedFile = Get-Item -LiteralPath $loaded.module.FileName
  $loadedRecord = [ordered]@{path=$loaded.module.FileName;size_bytes=[int64]$loadedFile.Length;last_write_time_utc=$loadedFile.LastWriteTimeUtc.ToString('o');sha256=$loadedHash;ae_pid=[int]$loaded.process.Id;launch_pid=[int]$launch.Id;relation=$relation;run_nonce=$RunNonce;module_base=('0x{0:x}' -f $loaded.module.BaseAddress.ToInt64());ready_marker=$readyText.Trim();process_binding=$processBinding;module_probe_attempts=$moduleAttempts}
  Set-Content -LiteralPath $ContinueMarker -Value 'continue' -Encoding ASCII
  if (-not $loaded.process.WaitForExit(600000)) { Fail-Closed 'render_timeout' 'same-run pair exceeded 600 seconds after the pause gate' $loadedRecord }
  $script:ActiveAePids = @()
  $result = Read-Json $resultPath
  if ([string]$result.status -ne 'ok' -or [string]$result.ae_version -ne '26.3x87' -or [int]$result.project_bits_per_channel -ne 32 -or [int]$result.project_gpu_accel_type_raw -ne 1816 -or [string]$result.project_working_space -ne '' -or [bool]$result.project_linear_blending) { Fail-Closed 'render' 'same-run AE result failed project contract' ($result | ConvertTo-Json -Compress) }
  if (@($result.warnings).Count -ne 0) { Fail-Closed 'render' 'same-run result returned warnings' ($result | ConvertTo-Json -Compress) }
  if ([bool]$result.effect_disabled -or [int]$result.effect_count_after_setup -ne 1 -or [string]$result.effect_identity_readback.match_name -ne 'OLM OLM Blur') { Fail-Closed 'effect_identity' 'effect-on identity/readback mismatch' ($result | ConvertTo-Json -Compress) }
  $p=$result.effect_param_readback
  if ($null -eq $p -or [single]$p.blur_amount -ne [single]129.4 -or [single]$p.blur_smoothness -ne [single]100 -or [single]$p.number_of_repeat -ne [single]1 -or [single]$p.bias_direction -ne [single]1 -or [single]$p.legacy -ne [single]0) { Fail-Closed 'parameter_readback' 'effect-on live parameter readback mismatch' ($result | ConvertTo-Json -Compress) }
  if (-not [bool]$result.no_effect_verified -or [int]$result.no_effect_count_after_removal -ne 0) { Fail-Closed 'no_effect_control' 'same-run control was not proven effect-free after removal' ($result | ConvertTo-Json -Compress) }
  $results = @()
  foreach ($mode in @(@{name='effect_on';enabled=$true;archive='return/effect_on.exr'}, @{name='no_effect';enabled=$false;archive='return/effect_no_effect.exr'})) {
    $branch = $result.outputs.($mode.name)
    if ($null -eq $branch) { Fail-Closed 'render' "missing same-run branch $($mode.name)" ($result | ConvertTo-Json -Compress) }
    $om = $branch.output_module_readback
    if ([string]$om.format -ne 'OpenEXR Sequence' -or [string]$om.channels -ne 'RGB + Alpha' -or [string]$om.depth -ne 'Floating Point+' -or [string]$om.color -ne 'Premultiplied (Matted)') { Fail-Closed 'output_module_readback' "$($mode.name) output module readback mismatch" ($result | ConvertTo-Json -Compress) }
    $exrCarrier = [pscustomobject]@{output_exr=[string]$branch.output_exr}
    $exr = Resolve-RenderedExr $exrCarrier $mode.name $out
    $archivePath = Join-Path $RunDir ($mode.archive -replace '/', '\\'); New-Item -ItemType Directory -Force -Path (Split-Path -Parent $archivePath) | Out-Null; Copy-Item -LiteralPath $exr.FullName -Destination $archivePath -Force
    $paramReadback = if ($mode.enabled) { $result.effect_param_readback } else { $null }
    $results += [ordered]@{mode=$mode.name;effect_enabled=$mode.enabled;effect_param_readback=$paramReadback;output_module_readback=$om;archive_path=$mode.archive;exr_sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();exr_size_bytes=[int64](Get-Item $archivePath).Length;ae_version=$result.ae_version;ae_pid=[int]$loadedRecord.ae_pid;project_bits_per_channel=[int]$result.project_bits_per_channel;project_working_space=[string]$result.project_working_space;project_linear_blending=[bool]$result.project_linear_blending;project_gpu_accel_type=[ordered]@{current_name='SOFTWARE';raw=[int]$result.project_gpu_accel_type_raw}}
  }
  foreach ($entry in $contractFiles.GetEnumerator()) { Copy-Item -LiteralPath $entry.Value -Destination (Join-Path $RunDir (Split-Path -Leaf $entry.Value)) -Force }
  Copy-Item -LiteralPath $contractPath -Destination (Join-Path $RunDir 'package_contract.json') -Force
  $manifest = [ordered]@{schema='olmblur-32bpc-case0001-return-v1';kind='olmblur_windows_case0001_float_exr_return';request_id=$RequestId;run_id=$RunId;status='answered_candidate_pending_exr_header_validation';same_ae_process_pair=$true;package_contract_sha256=$packageContractHash;contract_artifact_sha256=$contractHashes;return_zip=$ReturnZip;plugin=[ordered]@{prelaunch=$pluginRecord;loaded=$loadedRecord};input=[ordered]@{path='input/case_0001_before_effects.png';sha256=$inputHash};ae_version=$results[0].ae_version;project=[ordered]@{bits_per_channel=32;gpu_accel_type=[ordered]@{current_name='SOFTWARE';raw=1816};working_space='';linear_blending=$false};output=[ordered]@{template=$ExpectedTemplate;container_format='OpenEXR';required_sample_type='FLOAT';bits_per_channel=32;channel_order='RGBA';required_compression='none';header_validated=$false;requires_post_intake_header_validation=$true};effect_outputs=$results;fail_closed=$true}
  Write-Json $ManifestPath $manifest; Write-Json $StatusPath $manifest
  if (Test-Path -LiteralPath $ReturnZip) { Remove-Item -LiteralPath $ReturnZip -Force }
  Compress-Archive -Path (Join-Path $RunDir '*') -DestinationPath $ReturnZip -CompressionLevel Optimal
  Write-Host "OK: $ReturnZip"; exit 0
} catch { Fail-Closed 'runtime' $_.Exception.Message $null }
