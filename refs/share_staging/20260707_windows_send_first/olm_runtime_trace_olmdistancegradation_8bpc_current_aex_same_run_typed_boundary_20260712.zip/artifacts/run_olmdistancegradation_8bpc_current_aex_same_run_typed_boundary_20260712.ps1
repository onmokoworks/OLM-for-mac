param(
  [string]$PackageRoot = (Split-Path -Parent $PSScriptRoot),
  [string]$WorkRoot = (Join-Path (Split-Path -Parent $PSScriptRoot) 'work'),
  [switch]$ParseOnly,
  [string]$TracePath = '',
  [string]$AexPath = 'C:\Program Files\Adobe\Adobe After Effects 2026\Support Files\Plug-ins\Effects\DistanceGradation.aex',
  [string]$AfterFxPath = 'C:\Program Files\Adobe\Adobe After Effects 2026\Support Files\AfterFX.exe',
  [string]$CdbPath = 'C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe'
)

$ErrorActionPreference = 'Stop'
$requestId = 'olmdistancegradation_8bpc_current_aex_same_run_typed_boundary_20260712'
$expectedHash = 'a1d317c0e18371494bc9c9933684593ca903eb6f3fe262ec06d5147b4c0bcbae'
$cases = @('case_0001','case_0015','case_0029')
$requiredStages = @('FIELD_IN','FIELD_OUT','COMPOSE_IN','COMPOSE_OUT','HOST_STORE')
$runId = 'dg8typed-' + ([guid]::NewGuid().ToString('N'))

function Failure([string]$stage, [string]$reason, [object[]]$missing, [string]$last) {
  [ordered]@{status='exact_bind_failure';kind='typed_boundary';request_id=$requestId;failure=[ordered]@{stage=$stage;reason=$reason;missing_fields=@($missing);last_observation=$last}}
}
function Parse([string]$path) {
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return Failure 'typed_boundary' 'missing combined CDB trace' @('trace') '' }
  $rows = @{}; $depth = @{}; $last = ''
  foreach ($line in Get-Content -LiteralPath $path) {
    $last = $line
    if ($line -match '^DG8_DEPTH_SUMMARY\s+') {
      $m = @{}; foreach ($pair in [regex]::Matches($line,'(?<key>[a-z0-9_]+)=(?<value>[^\s]+)')) {$m[$pair.Groups['key'].Value]=$pair.Groups['value'].Value}
      if ($m.ContainsKey('case_id') -and $m.ContainsKey('rva')) {$depth["$($m.case_id)|$($m.rva)"]=$m}; continue
    }
    if ($line -notmatch '^DG8_(FIELD_IN|FIELD_OUT|COMPOSE_IN|COMPOSE_OUT|HOST_STORE)\s+') {continue}
    $stage = $Matches[1]; $m = @{}; foreach ($pair in [regex]::Matches($line,'(?<key>[a-z0-9_]+)=(?<value>[^\s]+)')) {$m[$pair.Groups['key'].Value]=$pair.Groups['value'].Value}
    if (-not ($m.ContainsKey('case_id') -and $m.ContainsKey('x') -and $m.ContainsKey('y'))) {continue}
    $key = "$($m.case_id)|$($m.x)|$($m.y)"; if (-not $rows.ContainsKey($key)) {$rows[$key]=[ordered]@{case_id=$m.case_id;x=$m.x;y=$m.y;stages=[ordered]@{}}}
    if ($rows[$key].stages.ContainsKey($stage)) {$rows[$key].stages[$stage]['duplicate']='1'} else {$rows[$key].stages[$stage]=$m}
  }
  $missing=@(); $identityFields=@('run_id','ae_pid','module_base','aex_sha256','project_bpc','case_id','x','y','output_addr')
  foreach ($case in $cases) {
    $key="$case|397|281"; if (-not $rows.ContainsKey($key)) {$missing+="missing:$key";continue}; $row=$rows[$key]
    foreach ($stage in $requiredStages) {
      if (-not $row.stages.ContainsKey($stage)) {$missing+="$key:$stage";continue}; $s=$row.stages[$stage]
      foreach ($field in $identityFields + @('typed_rgba')) {if (-not $s.ContainsKey($field)-or [string]::IsNullOrWhiteSpace([string]$s[$field])) {$missing+="$key:$stage:$field"}}
      if ($s.ContainsKey('duplicate')) {$missing+="$key:$stage:duplicate"}
      if ($s.typed_rgba -notmatch '^[^,]+,[^,]+,[^,]+,[^,]+$') {$missing+="$key:$stage:typed_rgba4"}
    }
    foreach ($stage in @('FIELD_IN','FIELD_OUT')) {foreach($field in @('field_base','field_rowbytes','field_addr','pixel_size','address_formula')) {if(-not $row.stages[$stage].ContainsKey($field)){$missing+="$key:$stage:$field"}}}
    foreach ($field in @('source_base','source_rowbytes','source_addr','field_green','x_before_invert','x_after_invert')) {if(-not $row.stages.COMPOSE_IN.ContainsKey($field)){$missing+="$key:COMPOSE_IN:$field"}}
    if (-not $row.stages.COMPOSE_OUT.ContainsKey('pre_store_rgba_float')) {$missing+="$key:COMPOSE_OUT:pre_store_rgba_float"}
    $ids=@($row.stages.Values|ForEach-Object{"$($_.run_id)|$($_.ae_pid)|$($_.module_base)|$($_.aex_sha256)|$($_.project_bpc)|$($_.output_addr)"}|Select-Object -Unique); if($ids.Count-ne 1){$missing+="$key:stage_identity"}
    foreach($rva in @('1170870','1170c90')) {$dk="$case|$rva";if(-not $depth.ContainsKey($dk)){$missing+="$key:depth_rva_$rva";continue};$d=$depth[$dk];foreach($field in @('run_id','ae_pid','module_base','aex_sha256','project_bpc','case_id','rva','hit_count')){if(-not$d.ContainsKey($field)-or[string]::IsNullOrWhiteSpace([string]$d[$field])){$missing+="$key:depth_rva_$rva:$field"}};if($d.run_id-ne$row.stages.FIELD_IN.run_id-or$d.ae_pid-ne$row.stages.FIELD_IN.ae_pid-or$d.module_base-ne$row.stages.FIELD_IN.module_base-or$d.aex_sha256-ne$row.stages.FIELD_IN.aex_sha256-or$d.project_bpc-ne'8'){$missing+="$key:depth_rva_$rva:identity"}}
    if($depth.ContainsKey("$case|1170870") -and [int]$depth["$case|1170870"].hit_count -le 0){$missing+="$key:PF8_hit_count_gt_0"}
    if($depth.ContainsKey("$case|1170c90") -and [int]$depth["$case|1170c90"].hit_count -ne 0){$missing+="$key:PF32_hit_count_eq_0"}
  }
  $selected=@($cases|ForEach-Object{$rows["$_|397|281"]}|Where-Object{$_}); $allStages=@($selected|ForEach-Object{$_.stages.Values})
  $runIds=@($allStages|ForEach-Object{$_.run_id}|Select-Object -Unique); $pids=@($allStages|ForEach-Object{$_.ae_pid}|Select-Object -Unique); $bases=@($allStages|ForEach-Object{$_.module_base}|Select-Object -Unique); $hashes=@($allStages|ForEach-Object{([string]$_.aex_sha256).ToLowerInvariant()}|Select-Object -Unique); $depths=@($allStages|ForEach-Object{$_.project_bpc}|Select-Object -Unique)
  if($runIds.Count-ne 1){$missing+='shared_run_id'};if($pids.Count-ne 1-or$pids[0]-notmatch'^\d+$'){$missing+='shared_ae_pid'};if($bases.Count-ne 1-or$bases[0]-notmatch'^0x[0-9a-fA-F]+$'){$missing+='shared_module_base'};if($hashes.Count-ne 1-or$hashes[0]-ne$expectedHash){$missing+='shared_expected_aex_sha256'};if($depths.Count-ne 1-or$depths[0]-ne'8'){$missing+='shared_project_bpc_8'}
  if($missing.Count){return Failure 'typed_boundary' 'typed stages or depth/module identity are incomplete or mismatched' $missing $last}
  [ordered]@{status='answered';kind='typed_boundary';request_id=$requestId;run_id=$runIds[0];ae_pid=[int]$pids[0];module_base=$bases[0];aex_sha256=$hashes[0];project_bits_per_channel=8;rvas=@([ordered]@{rva='1170870';hit_count=($cases|ForEach-Object{[int]$depth["$_|1170870"].hit_count}|Measure-Object -Sum).Sum},[ordered]@{rva='1170c90';hit_count=0});cases=$selected}
}
if($ParseOnly){if(-not$TracePath){throw '-ParseOnly requires -TracePath'};(Parse $TracePath)|ConvertTo-Json -Depth 14;exit 0}

$work=Join-Path $WorkRoot "olmdg_typed_$runId";New-Item -ItemType Directory -Force -Path $work|Out-Null;$work=(Get-Item -LiteralPath $work).FullName
$returnPath=Join-Path $work 'RETURN_RUNTIME_TRACE.json';$combinedTrace=Join-Path $work 'combined_cdb_trace.txt';$launchStdout=Join-Path $work 'afterfx_launcher_stdout.txt';$launchStderr=Join-Path $work 'afterfx_launcher_stderr.txt';$queueLog=Join-Path $work 'AE_TYPED_QUEUE.log'
$sessionId=(Get-Process -Id $PID).SessionId;$launch=$null;$ae=$null;$cdb=$null;$launchStarted=$false
function ReadOrNull([string]$path){if(Test-Path -LiteralPath $path -PathType Leaf){Get-Content -LiteralPath $path -Raw}else{$null}}
function Get-AfterFxState {@(Get-CimInstance Win32_Process -Filter "Name='AfterFX.exe'" -ErrorAction SilentlyContinue|Where-Object{$_.SessionId-eq$sessionId-and$_.ExecutablePath-and[IO.Path]::GetFullPath($_.ExecutablePath)-ieq$AfterFxPath}|ForEach-Object{[ordered]@{pid=[int]$_.ProcessId;parent_pid=[int]$_.ParentProcessId;session_id=[int]$_.SessionId;path=$_.ExecutablePath;command_line=$_.CommandLine}})}
function LauncherState {if($null-eq$launch){return $null};try{$launch.Refresh()}catch{};$exit=$null;if($launch.HasExited){try{$exit=$launch.ExitCode}catch{}};[ordered]@{pid=$launch.Id;launcher_exited=$launch.HasExited;launcher_exit_code=$exit}}
function RawLogs {[ordered]@{work_directory=$work;launcher_stdout=(ReadOrNull $launchStdout);launcher_stderr=(ReadOrNull $launchStderr);queue_log=(ReadOrNull $queueLog);combined_cdb_trace=(ReadOrNull $combinedTrace);cases=@($cases|ForEach-Object{[ordered]@{case_id=$_;ready_marker=(ReadOrNull (Join-Path $work "ae_ready_$_.marker"));cdb_trace=(ReadOrNull (Join-Path $work "cdb_trace_$_.txt"));cdb_stdout=(ReadOrNull (Join-Path $work "cdb_stdout_$_.txt"));cdb_stderr=(ReadOrNull (Join-Path $work "cdb_stderr_$_.txt"));ae_log=(ReadOrNull (Join-Path $work "AE_SINGLE_CASE_$_.log"));ae_result=(ReadOrNull (Join-Path $work "AE_SINGLE_CASE_$_.json"))}});process_diagnostics=[ordered]@{executable_path=$AfterFxPath;session_id=$sessionId;launcher=(LauncherState);candidate_afterfx=@(Get-AfterFxState)}}}
function Finish([object]$body,[int]$code){
  if($code-ne0){foreach($case in $cases){$ready=Join-Path $work "ae_ready_$case.marker";$continue=Join-Path $work "ae_continue_$case.marker";if((Test-Path $ready)-and-not(Test-Path $continue)){Set-Content $continue 'abort' -Encoding ASCII -ErrorAction SilentlyContinue}};if($cdb-and-not$cdb.HasExited){Stop-Process $cdb.Id -Force -ErrorAction SilentlyContinue};if($launchStarted){foreach($state in @(Get-AfterFxState)){Stop-Process $state.pid -Force -ErrorAction SilentlyContinue}}}
  $body['raw_logs']=RawLogs;$json=$body|ConvertTo-Json -Depth 16;$json|Set-Content $returnPath -Encoding UTF8;$json;exit $code
}
$queue=Join-Path $PackageRoot 'scripts\ae_render_olmdistancegradation_8bpc_queue.jsx'
foreach($path in @($AexPath,$AfterFxPath,$CdbPath,$queue)){if(-not(Test-Path -LiteralPath $path -PathType Leaf)){Finish (Failure 'preflight' "required file missing: $path" @('preflight_file') '') 2}}
if(Get-Process -Name AfterFX -ErrorAction SilentlyContinue){Finish (Failure 'desktop_launch' 'After Effects must be fully closed before this run' @('fresh_AfterFX_process') '') 2}
$AexPath=(Get-Item $AexPath).FullName;$AfterFxPath=(Get-Item $AfterFxPath).FullName;$CdbPath=(Get-Item $CdbPath).FullName;$aexSha256=(Get-FileHash $AexPath -Algorithm SHA256).Hash.ToLowerInvariant();if($aexSha256-ne$expectedHash){Finish (Failure 'module_hash' 'DistanceGradation.aex is not the accepted current binary' @('expected_aex_sha256') "actual=$aexSha256") 2}
$env:OLM_DG_LIVE_REQUEST_DIR=Join-Path $PackageRoot 'request';$env:OLM_DG_LIVE_WORK_ROOT=$work;$env:OLM_DG_LIVE_RUN_ID=$runId;$env:OLM_AE_PAUSE_BEFORE_RENDER='1';$env:OLM_AE_PAUSE_TIMEOUT_SECONDS='300';$env:OLM_AE_FORCE_SOFTWARE='1'
$launch=Start-Process -FilePath $AfterFxPath -ArgumentList @('-m','-r',$queue) -RedirectStandardOutput $launchStdout -RedirectStandardError $launchStderr -PassThru;$launchStarted=$true
$boundPid=$null;$boundBase=$null
foreach($case in $cases){
  $ready=Join-Path $work "ae_ready_$case.marker";$continue=Join-Path $work "ae_continue_$case.marker";$result=Join-Path $work "AE_SINGLE_CASE_$case.json";$deadline=(Get-Date).AddSeconds(180);while((Get-Date)-lt$deadline-and-not(Test-Path $ready)){Start-Sleep -Milliseconds 250}
  if(-not(Test-Path $ready -PathType Leaf)){Finish (Failure 'readiness' "AE ready marker missing for $case" @("ae_ready_$case.marker") '') 2};$readyText=Get-Content $ready -Raw;if($readyText-notmatch"case_id=$case"-or$readyText-notmatch'effect_loaded=1'-or$readyText-notmatch'parameters_applied=1'){Finish (Failure 'readiness' "AE marker is not render-ready for $case" @('case_id','effect_loaded=1','parameters_applied=1') $readyText) 2}
  $loaded=@();$deadline=(Get-Date).AddSeconds(30);while((Get-Date)-lt$deadline-and$loaded.Count-ne1){$loaded=@(Get-AfterFxState|ForEach-Object{$p=Get-Process -Id $_.pid -ErrorAction SilentlyContinue;try{$m=$p.Modules|Where-Object{$_.FileName-ieq$AexPath}|Select-Object -First 1;if($m){[pscustomobject]@{Process=$p;Module=$m}}}catch{}});if($loaded.Count-ne1){Start-Sleep -Milliseconds 250}}
  if($loaded.Count-ne1){Finish (Failure 'desktop_process_discovery' "exactly one loaded module was not found for $case" @('actual_ae_process_module') "matches=$($loaded.Count)") 2};$ae=$loaded[0].Process;$module=$loaded[0].Module;$loadedHash=(Get-FileHash $module.FileName -Algorithm SHA256).Hash.ToLowerInvariant();$base=('0x{0:x}'-f$module.BaseAddress.ToInt64())
  if($loadedHash-ne$expectedHash){Finish (Failure 'module_hash' 'loaded module hash mismatch' @('loaded_aex_sha256') "actual=$loadedHash") 2};if($null-eq$boundPid){$boundPid=$ae.Id;$boundBase=$base}elseif($ae.Id-ne$boundPid-or$base-ne$boundBase){Finish (Failure 'same_run_identity' 'AE PID or module base changed between cases' @('shared_ae_pid','shared_module_base') "pid=$($ae.Id) base=$base") 2}
  $baseValue=$module.BaseAddress.ToInt64();$pf8=('0x{0:x}'-f($baseValue+0x1170870));$pf32=('0x{0:x}'-f($baseValue+0x1170c90));$fieldOut=('0x{0:x}'-f($baseValue+0x117098f));$composeIn=('0x{0:x}'-f($baseValue+0x1170a09));$composeOut=('0x{0:x}'-f($baseValue+0x1170c11));$hostStore=('0x{0:x}'-f($baseValue+0x1170c40));$trace=Join-Path $work "cdb_trace_$case.txt";$stdout=Join-Path $work "cdb_stdout_$case.txt";$stderr=Join-Path $work "cdb_stderr_$case.txt";$script=Join-Path $work "typed_$case.cdb"
  $cdbText=@"
.effmach amd64
.expr /s masm
sxi 80000003
.logopen "$trace"
r @`$t0=0
r @`$t1=0
bp $pf32 ".printf \"DG8_DEPTH_HIT run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case rva=1170c90 hit_count=1\\n\";r @`$t1=@`$t1+1;gc"
bp $pf8 ".if (@edx==397 && @r8d==281) {r @`$t0=@`$t0+1;r @`$t2=poi(@rcx+8);r @`$t3=poi(@rcx);r @`$t4=poi(@rsp+28);r @`$t5=poi(@`$t2+18);r @`$t6=dwo(@`$t2+20);r @`$t7=@`$t5+(281*@`$t6)+(397*4);r @`$t8=poi(@`$t3+18)+(281*dwo(@`$t3+20))+(397*4);.printf \"DG8_DEPTH_CONTROL_CONFIRMED run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case x=397 y=281 output_addr=%p\\n\",@`$t4;.printf \"DG8_FIELD_IN run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case x=397 y=281 output_addr=%p field_base=%p field_rowbytes=%x field_addr=%p pixel_size=4 address_formula=base+y*rowbytes+x*4 typed_rgba=%02x,%02x,%02x,%02x\\n\",@`$t4,@`$t5,@`$t6,@`$t7,by(@`$t7+1),by(@`$t7+2),by(@`$t7+3),by(@`$t7);bp $fieldOut \".if (@rcx==@`$t7) {.printf \\\"DG8_FIELD_OUT run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case x=397 y=281 output_addr=%p field_base=%p field_rowbytes=%x field_addr=%p pixel_size=4 address_formula=base+y*rowbytes+x*4 typed_rgba=%02x,%02x,%02x,%02x\\\\n\\\",@`$t4,@`$t5,@`$t6,@rcx,by(@rcx+1),by(@rcx+2),by(@rcx+3),by(@rcx)};gc\";bp $composeIn \".if (@r10==@`$t8) {.printf \\\"DG8_COMPOSE_IN run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case x=397 y=281 output_addr=%p source_base=%p source_rowbytes=%x source_addr=%p pixel_size=4 address_formula=base+y*rowbytes+x*4 field_green=%02x x_before_invert=%f x_after_invert=%f typed_rgba=%02x,%02x,%02x,%02x\\\\n\\\",@`$t4,poi(@`$t3+18),dwo(@`$t3+20),@r10,by(@`$t7+1),@xmm1,@xmm2,by(@r10+1),by(@r10+2),by(@r10+3),by(@r10)};gc\";bp $composeOut \".if (@rdi==@`$t4) {.printf \\\"DG8_COMPOSE_OUT run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case x=397 y=281 output_addr=%p pre_store_rgba_float=%f,%f,%f,%f typed_rgba=%f,%f,%f,%f\\\\n\\\",@`$t4,@xmm1,@xmm5,@xmm3,@xmm6,@xmm1,@xmm5,@xmm3,@xmm6};gc\";bp $hostStore \".if (@rdi==@`$t4) {.printf \\\"DG8_HOST_STORE run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case x=397 y=281 output_addr=%p typed_rgba=%02x,%02x,%02x,%02x\\\\n\\\",@`$t4,by(@rdi+1),by(@rdi+2),by(@rdi+3),by(@rdi);.printf \\\"DG8_DEPTH_SUMMARY run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case rva=1170870 hit_count=%u\\\\n\\\",@`$t0;.printf \\\"DG8_DEPTH_SUMMARY run_id=$runId ae_pid=$boundPid module_base=$boundBase aex_sha256=$aexSha256 project_bpc=8 case_id=$case rva=1170c90 hit_count=%u\\\\n\\\",@`$t1;.detach;q};gc\";.echo DG8_TYPED_BREAKPOINTS_ARMED_AFTER_DEPTH_CONTROL;gc} .else {gc}"
.echo DG8_DEPTH_BREAKPOINTS_ARMED
g
"@
  $cdbText|Set-Content $script -Encoding ASCII;$cdb=Start-Process -FilePath $CdbPath -ArgumentList ('-cf "'+$script+'" -p '+$boundPid) -RedirectStandardOutput $stdout -RedirectStandardError $stderr -NoNewWindow -PassThru;$deadline=(Get-Date).AddSeconds(60);while((Get-Date)-lt$deadline){if((Test-Path $trace)-and((Get-Content $trace -Raw)-match'DG8_DEPTH_BREAKPOINTS_ARMED')){break};if($cdb.HasExited){break};Start-Sleep -Milliseconds 250;$cdb.Refresh()};if(-not(Test-Path $trace)-or-not((Get-Content $trace -Raw)-match'DG8_DEPTH_BREAKPOINTS_ARMED')){Finish (Failure 'depth_control' "CDB did not arm depth controls for $case" @('DG8_DEPTH_BREAKPOINTS_ARMED') '') 2}
  Set-Content $continue 'continue' -Encoding ASCII;$deadline=(Get-Date).AddSeconds(240);while((Get-Date)-lt$deadline-and-not$cdb.HasExited){Start-Sleep -Milliseconds 250;$cdb.Refresh()};if(-not$cdb.HasExited){Finish (Failure 'typed_boundary' "CDB did not complete exact typed capture for $case" @('cdb_exit') '') 2};if(Test-Path $trace){Get-Content $trace|Add-Content $combinedTrace}
  $deadline=(Get-Date).AddSeconds(180);while((Get-Date)-lt$deadline-and-not(Test-Path $result)){Start-Sleep -Milliseconds 250};if(-not(Test-Path $result)){Finish (Failure 'render_result' "AE result missing for $case" @("AE_SINGLE_CASE_$case.json") '') 2};$aeResult=Get-Content $result -Raw|ConvertFrom-Json;if($aeResult.status-ne'ok'-or[int]$aeResult.project_bits_per_channel-ne8){Finish (Failure 'depth_control' "AE did not complete $case at 8bpc" @('status=ok','project_bits_per_channel=8') ($aeResult|ConvertTo-Json -Compress)) 2}
}
$parsed=Parse $combinedTrace;if($parsed.status-eq'answered'-and($parsed.ae_pid-ne$boundPid-or$parsed.module_base-ne$boundBase-or$parsed.aex_sha256-ne$aexSha256)){$parsed=Failure 'same_run_identity' 'parsed trace differs from located process/module' @('summary_process_module_identity') ($parsed|ConvertTo-Json -Compress)};Finish $parsed $(if($parsed.status-eq'answered'){0}else{2})
