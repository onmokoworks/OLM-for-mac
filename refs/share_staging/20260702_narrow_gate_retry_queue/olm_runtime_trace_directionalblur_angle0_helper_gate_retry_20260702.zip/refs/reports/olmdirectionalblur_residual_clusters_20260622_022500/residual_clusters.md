# OLMDirectionalBlur Residual Cluster Audit

Candidate: `rotated-aex-full-choreo`.

| Case | Classification | Max | Mean | Nonzero px | Components | Max witness |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| angle0_case_0001 | `angle0-rgb-only-rowdriver-or-valid-alpha` | 164 | 4.956984954 | 147615 (28.4751%) | 11 | `x=465 y=169 c=0 ref=[164, 0, 0, 255] cand=[0, 0, 0, 255] signed=[-164, 0, 0, 0]` |
| diagonal_case_0005 | `diagonal-rgb-alpha-rotate-validity` | 251 | 2.297067901 | 88845 (17.1383%) | 5784 | `x=507 y=367 c=0 ref=[1, 0, 0, 255] cand=[252, 0, 0, 255] signed=[251, 0, 0, 0]` |

## angle0_case_0001

angle-0/front-only residual; separates rowdriver/valid-alpha/writeback

Top witnesses:

- `x=494 y=169` ref `[164, 0, 0, 255]` cand `[0, 0, 0, 255]` signed `[-164, 0, 0, 0]`
- `x=493 y=169` ref `[164, 0, 0, 255]` cand `[0, 0, 0, 255]` signed `[-164, 0, 0, 0]`
- `x=492 y=169` ref `[164, 0, 0, 255]` cand `[0, 0, 0, 255]` signed `[-164, 0, 0, 0]`
- `x=491 y=169` ref `[164, 0, 0, 255]` cand `[0, 0, 0, 255]` signed `[-164, 0, 0, 0]`
- `x=490 y=169` ref `[164, 0, 0, 255]` cand `[0, 0, 0, 255]` signed `[-164, 0, 0, 0]`
- `x=489 y=169` ref `[164, 0, 0, 255]` cand `[0, 0, 0, 255]` signed `[-164, 0, 0, 0]`
- `x=488 y=169` ref `[164, 0, 0, 255]` cand `[0, 0, 0, 255]` signed `[-164, 0, 0, 0]`
- `x=487 y=169` ref `[164, 0, 0, 255]` cand `[0, 0, 0, 255]` signed `[-164, 0, 0, 0]`

Largest components:

- size `147593`, bbox `[380, 0, 959, 369]`, centroid `[629.9377816021085, 225.65949604656046]`
- size `5`, bbox `[446, 360, 448, 362]`, centroid `[447.0, 361.0]`
- size `3`, bbox `[433, 357, 434, 358]`, centroid `[433.6666666666667, 357.3333333333333]`
- size `3`, bbox `[447, 357, 448, 358]`, centroid `[447.6666666666667, 357.3333333333333]`
- size `2`, bbox `[450, 356, 450, 357]`, centroid `[450.0, 356.5]`

Signed channel counts:

- R: positive `85873`, negative `61742`, min `-164`, max `102`
- G: positive `0`, negative `0`, min `0`, max `0`
- B: positive `0`, negative `0`, min `0`, max `0`
- A: positive `0`, negative `0`, min `0`, max `0`

Classification:

- residual kind: `angle0-rgb-only-rowdriver-or-valid-alpha`
- nonzero split: RGB `147615` (100.00% of diff px), alpha `0` (0.00% of diff px)
- component split within 8px border: border `1`, interior `10`, largest touches border `True`
- largest border component: `{'size': 147593, 'bbox': [380, 0, 959, 369], 'centroid': [629.9377816021085, 225.65949604656046], 'touches_border': True, 'near_border_8px': True}`
- largest interior component: `{'size': 5, 'bbox': [446, 360, 448, 362], 'centroid': [447.0, 361.0], 'touches_border': False, 'near_border_8px': False}`

## diagonal_case_0005

diagonal rotate-path residual; separates rotate sampler/validity/group normalization

Top witnesses:

- `x=507 y=367` ref `[1, 0, 0, 255]` cand `[252, 0, 0, 255]` signed `[251, 0, 0, 0]`
- `x=519 y=363` ref `[0, 0, 0, 255]` cand `[250, 0, 0, 255]` signed `[250, 0, 0, 0]`
- `x=514 y=365` ref `[0, 0, 0, 255]` cand `[250, 0, 0, 255]` signed `[250, 0, 0, 0]`
- `x=513 y=365` ref `[1, 0, 0, 255]` cand `[251, 0, 0, 255]` signed `[250, 0, 0, 0]`
- `x=508 y=367` ref `[1, 0, 0, 255]` cand `[251, 0, 0, 255]` signed `[250, 0, 0, 0]`
- `x=494 y=370` ref `[1, 0, 0, 255]` cand `[251, 0, 0, 255]` signed `[250, 0, 0, 0]`
- `x=423 y=187` ref `[254, 0, 0, 255]` cand `[4, 0, 0, 255]` signed `[-250, 0, 0, 0]`
- `x=416 y=192` ref `[254, 0, 0, 255]` cand `[4, 0, 0, 255]` signed `[-250, 0, 0, 0]`

Largest components:

- size `81199`, bbox `[0, 0, 959, 539]`, centroid `[446.94960529070556, 342.54553627507727]`
- size `335`, bbox `[497, 0, 805, 2]`, centroid `[652.176119402985, 0.08059701492537313]`
- size `228`, bbox `[823, 0, 959, 74]`, centroid `[915.3640350877193, 13.50438596491228]`
- size `213`, bbox `[123, 0, 316, 1]`, centroid `[218.68544600938966, 0.0892018779342723]`
- size `196`, bbox `[318, 0, 495, 1]`, centroid `[407.7448979591837, 0.09183673469387756]`

Signed channel counts:

- R: positive `40921`, negative `38082`, min `-250`, max `251`
- G: positive `0`, negative `0`, min `0`, max `0`
- B: positive `0`, negative `0`, min `0`, max `0`
- A: positive `10465`, negative `740`, min `-55`, max `56`

Classification:

- residual kind: `diagonal-rgb-alpha-rotate-validity`
- nonzero split: RGB `79003` (88.92% of diff px), alpha `11205` (12.61% of diff px)
- component split within 8px border: border `239`, interior `5545`, largest touches border `True`
- largest border component: `{'size': 81199, 'bbox': [0, 0, 959, 539], 'centroid': [446.94960529070556, 342.54553627507727], 'touches_border': True, 'near_border_8px': True}`
- largest interior component: `{'size': 6, 'bbox': [82, 57, 84, 59], 'centroid': [83.16666666666667, 58.166666666666664], 'touches_border': False, 'near_border_8px': False}`
