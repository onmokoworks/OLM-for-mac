param([string]$OutputDir = "")
$ErrorActionPreference = "Stop"
$requestId = "olm_runtime_trace_olm_math_ucrt_batch_20260814"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$packagesRoot = Split-Path -Parent $root
$directionalId = "olm_runtime_trace_olmdirectionalblur_remaining6_ucrt_expf_20260814"
$directionalPowfId = "olm_runtime_trace_olmdirectionalblur_remaining6_ucrt_powf_20260814"
$distanceId = "olm_runtime_trace_olmdistancegradation_pf32_power_ucrt_powf_20260813"
$directionalRoot = Join-Path $packagesRoot $directionalId
$directionalPowfRoot = Join-Path $packagesRoot $directionalPowfId
$distanceRoot = Join-Path $packagesRoot $distanceId
$runRoot = if ($OutputDir) { $OutputDir } else { Join-Path $root "return" }
$scratch = Join-Path $runRoot ($requestId + "_scratch")
$runDir = Join-Path $runRoot $requestId
$zipPath = Join-Path $runRoot ($requestId + "_return_windows.zip")

function Write-Utf8NoBom([string]$Path, [string]$Content) {
  [IO.File]::WriteAllText($Path, $Content, (New-Object Text.UTF8Encoding($false)))
}
function Sha([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }

if (-not [Environment]::Is64BitProcess -or $env:PROCESSOR_ARCHITECTURE -ne "AMD64") {
  throw "Run from 64-bit x64 PowerShell"
}
foreach ($path in @(
  (Join-Path $directionalRoot "run_olmdirectionalblur_remaining6_ucrt_expf.ps1"),
  (Join-Path $directionalPowfRoot "run_olmdirectionalblur_remaining6_ucrt_powf.ps1"),
  (Join-Path $distanceRoot "run_olmdistancegradation_pf32_power_ucrt_powf.ps1")
)) {
  if (-not (Test-Path -LiteralPath $path)) { throw "Missing child request: $path" }
}
foreach ($path in @($scratch, $runDir)) {
  if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
}
New-Item -ItemType Directory -Force -Path $runRoot | Out-Null
New-Item -ItemType Directory -Force -Path $scratch | Out-Null

& (Join-Path $directionalRoot "run_olmdirectionalblur_remaining6_ucrt_expf.ps1") -OutputDir $scratch | Out-Null
& (Join-Path $directionalPowfRoot "run_olmdirectionalblur_remaining6_ucrt_powf.ps1") -OutputDir $scratch | Out-Null
& (Join-Path $distanceRoot "run_olmdistancegradation_pf32_power_ucrt_powf.ps1") -OutputDir $scratch | Out-Null

$directionalDir = Join-Path $scratch $directionalId
$directionalPowfDir = Join-Path $scratch $directionalPowfId
$distanceDir = Join-Path $scratch $distanceId
$directionalSummaryPath = Join-Path $directionalDir "run_summary.json"
$directionalPowfSummaryPath = Join-Path $directionalPowfDir "run_summary.json"
$distanceSummaryPath = Join-Path $distanceDir "run_summary.json"
$directional = Get-Content -Raw -LiteralPath $directionalSummaryPath | ConvertFrom-Json
$directionalPowf = Get-Content -Raw -LiteralPath $directionalPowfSummaryPath | ConvertFrom-Json
$distance = Get-Content -Raw -LiteralPath $distanceSummaryPath | ConvertFrom-Json
if ($directional.vector_count -ne 494 -or $directionalPowf.vector_count -ne 787 -or $distance.vector_count -ne 63) {
  throw "Child vector count mismatch"
}
if ($directional.process_bitness -ne 64 -or $directionalPowf.process_bitness -ne 64 -or $distance.process_bitness -ne 64) {
  throw "Child process bitness mismatch"
}
if ($directional.ucrtbase.sha256 -ne $directionalPowf.ucrtbase.sha256 -or
    $directional.ucrtbase.sha256 -ne $distance.ucrtbase.sha256 -or
    $directional.ucrtbase.path -ne $directionalPowf.ucrtbase.path -or
    $directional.ucrtbase.path -ne $distance.ucrtbase.path -or
    $directional.ucrtbase.file_version -ne $directionalPowf.ucrtbase.file_version -or
    $directional.ucrtbase.file_version -ne $distance.ucrtbase.file_version -or
    $directional.ucrtbase.product_version -ne $directionalPowf.ucrtbase.product_version -or
    $directional.ucrtbase.product_version -ne $distance.ucrtbase.product_version) {
  throw "Child UCRT identity mismatch"
}

New-Item -ItemType Directory -Force -Path $runDir | Out-Null
Copy-Item -LiteralPath $directionalDir -Destination (Join-Path $runDir "directional") -Recurse
Copy-Item -LiteralPath $directionalPowfDir -Destination (Join-Path $runDir "directional_powf") -Recurse
Copy-Item -LiteralPath $distanceDir -Destination (Join-Path $runDir "distance") -Recurse
Copy-Item -LiteralPath (Join-Path $root "request_manifest.json") -Destination $runDir
$summary = [ordered]@{
  schema="olm.math-ucrt-batch-return/1"; request_id=$requestId
  status="answered_native_windows_ucrt_expf_powf"; process_bitness=64
  processor_architecture=$env:PROCESSOR_ARCHITECTURE; ucrtbase=$directional.ucrtbase
  vectors=[ordered]@{directional_expf=494; directional_powf=787; distance_powf=63; total=1344}
  children=[ordered]@{
    directional=[ordered]@{request_id=$directional.request_id; summary_sha256=(Sha $directionalSummaryPath)}
    directional_powf=[ordered]@{request_id=$directionalPowf.request_id; summary_sha256=(Sha $directionalPowfSummaryPath)}
    distance=[ordered]@{request_id=$distance.request_id; summary_sha256=(Sha $distanceSummaryPath)}
  }
}
$summaryPath = Join-Path $runDir "run_summary.json"
Write-Utf8NoBom $summaryPath (($summary | ConvertTo-Json -Depth 8) + [Environment]::NewLine)
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
Compress-Archive -Path (Join-Path $runDir "*") -DestinationPath $zipPath
Remove-Item -LiteralPath $scratch -Recurse -Force
Write-Output ($summary | ConvertTo-Json -Depth 8)
