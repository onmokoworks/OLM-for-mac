# OLMDistanceGradation Trace Comparison

- Request: `olmdistancegradation_16bpc_constant_boundary_witness_20260630`
- Likely next focus: `trace-too-sparse`
- Windows trace present: `True`

## Local Assumptions

- `distance_transform`: scipy/OpenCV-like Euclidean distance_transform_edt for current CLI; Windows AEX embeds OpenCV 4.5.5
- `normalization`: clamp to UI threshold, then divide by actual max with denominator at least 1.0
- `constant_no_blur`: current CLI binarizes non-blur Constant after interpolation-prep, but this is inferred upstream behavior
- `constant_blur`: current CLI binarizes field before blur and doubles blur radius
- `gaussian_blur`: separable Gaussian with OpenCV default sigma formula and Reflect101/mirror border
- `compose`: FUN_181170870 reads field green byte, applies invert/interpolation, then writes 8bpc RGBA

## Windows Observations

- Status: `answered_partial`
- Summary: The existing Windows evidence resolves the Constant boundary lane as a threshold-ownership problem before compose/writeback: case_0020 flips exactly at field_x==1 on the 951/950 boundary pair, and the case_0022/case_0023 representatives remain boundary-localized after the Constant-specific THRESH_BINARY fix. The exact FUN_181170480 per-pixel compose watchpoint values for case_0022/0023 were not newly isolated in this batch, so those are carried as boundary-class facts rather than a fresh debugger hit.
- Cases: `[{"boundary_pair": [{"binary_mask_value_before_distance_transform": "[source alpha lane / constant-background binary ownership]", "field_value_finally_consumed_by_FUN_181170480": 1.0, "final_rgba16": [65535, 0, 0, 65535], "fun_181170480_output_rgba_before_word_store": null, "inside_distance_before_threshold": null, "mac_candidate_rgba16": [65535, 0, 0, 65535], "notes": "Boundary witness at the plateau edge; this is the red-endpoint side.", "outside_distance_before_threshold": null, "source_input_rgba16": [65535, 0, 0, 65535], "windows_reference_rgba16": [7195, 0, 61165, 65535], "x": 951, "y": 417}, {"binary_mask_value_before_distance_transform": "[source alpha lane / constant-background binary ownership]", "field_value_finally_consumed_by_FUN_181170480": 0.999095619, "final_rgba16": [7195, 0, 61165, 65535], "fun_181170480_output_rgba_before_word_store": null, "inside_distance_before_threshold": null, "mac_candidate_rgba16": [7195, 0, 61165, 65535], "notes": "Adjacent neighbor that already matches Windows; this is the blue-endpoint side.", "outside_distance_before_threshold": null, "source_input_rgba16": [65535, 0, 0, 65535], "windows_reference_rgba16": [7195, 0, 61165, 65535], "x": 950, "y": 417}], "case_id": "olmdistancegradation_extended__case_0020", "comparison_rule": "field_x == 1 plateau; adjacent field_x < 1 selects the blue endpoint and already matches Windows", "family": "constant-bg-binary-boundary", "threshold_values": {"inside_threshold": 78, "outside_threshold": 204}}, {"case_id": "olmdistancegradation_extended__case_0022", "comparison_rule": "boundary-localized Constant/THRESH_BINARY ownership; the residuals are not compose/writeback drift", "family": "constant-bg-binary-boundary", "representative_pixels": [{"binary_mask_value_before_distance_transform": "[source alpha lane / boundary-localized constant]", "field_value_finally_consumed_by_FUN_181170480": null, "final_rgba16": [65535, 0, 0, 65535], "inside_distance_before_threshold": 0.0, "mac_candidate_rgba16": [7195, 0, 61165, 65535], "notes": "Boundary-localized representative from the remaining residual set.", "outside_distance_before_threshold": 10.770329614269007, "source_input_rgba16": [0, 0, 0, 0], "windows_reference_rgba16": [65535, 0, 0, 65535], "x": 1101, "y": 55}, {"binary_mask_value_before_distance_transform": "[source alpha lane / boundary-localized constant]", "field_value_finally_consumed_by_FUN_181170480": null, "final_rgba16": [65535, 0, 0, 65535], "inside_distance_before_threshold": 0.0, "mac_candidate_rgba16": [7195, 0, 61165, 65535], "notes": "Nearby sanity sample; same boundary lane.", "outside_distance_before_threshold": 11.0, "source_input_rgba16": [0, 0, 0, 0], "windows_reference_rgba16": [65535, 0, 0, 65535], "x": 1097, "y": 56}], "threshold_values": {"inside_threshold": 36, "outside_threshold": 11}}, {"case_id": "olmdistancegradation_extended__case_0023", "comparison_rule": "boundary-localized Constant/THRESH_BINARY ownership; the residuals are not compose/writeback drift", "family": "constant-bg-binary-boundary", "representative_pixels": [{"binary_mask_value_before_distance_transform": "[source alpha lane / boundary-localized constant]", "field_value_finally_consumed_by_FUN_181170480": null, "final_rgba16": [65535, 0, 0, 65535], "inside_distance_before_threshold": 1.0, "mac_candidate_rgba16": [7195, 0, 61165, 65535], "notes": "Top-edge representative from the remaining residual family.", "outside_distance_before_threshold": 0.0, "source_input_rgba16": [0, 0, 0, 257], "windows_reference_rgba16": [65535, 0, 0, 65535], "x": 1699, "y": 7}, {"binary_mask_value_before_distance_transform": "[source alpha lane / boundary-localized constant]", "field_value_finally_consumed_by_FUN_181170480": null, "final_rgba16": [65535, 0, 0, 65535], "inside_distance_before_threshold": 1.0, "mac_candidate_rgba16": [7195, 0, 61165, 65535], "notes": "Nearby sanity sample; same boundary lane.", "outside_distance_before_threshold": 0.0, "source_input_rgba16": [0, 0, 0, 257], "windows_reference_rgba16": [65535, 0, 0, 65535], "x": 985, "y": 26}], "threshold_values": {"inside_threshold": 36, "outside_threshold": 0}}]`
- Witness pixels: -
- Field values: `{"binary_mask_before_distance_transform": null, "field_value_before_compose_or_color_pick": null, "fun_181170480_X_after_invert": null, "fun_181170480_X_before_invert": null, "inside_or_outside_distance_before_threshold": null, "source_input_rgba16": null}`
- OpenCV calls: -
- Threshold/normalization: `{"comparison_rule": null, "selected_side_inside_outside_or_both": null, "threshold_values_ui_and_internal": null}`
- Compose: `{"final_rgba16": null, "output_rgba_float_before_cvt": null}`
- Branch decision: `{}`

## Interpretation

- `constant-field-prep`: update the field construction/packing IR before touching compose.
- `threshold-normalization`: settle clamp/minmax denominator before Gaussian or compose changes.
- `distance-transform-args`: update OpenCV/helper primitive assumptions first.
- `gaussian-blur-args`: focus `case_0029` blur radius/kernel/border.
- `compose-field-byte`: focus `FUN_181170870` green-byte/invert/interp/writeback.
- `case0026-field-prep-normalization`: Windows already has a ramp before 16bpc compose; fix field prep/normalization.
- `case0026-invert-power-compose`: Windows creates the ramp in `FUN_181170480`; fix invert/power/compose ownership.
- `case0026-parameter-color-branch`: fix AE parameter/color branch ownership before math changes.
- `constant-boundary-threshold-ownership`: Constant-mode boundary values were captured; decide `<` vs `<=`, side ownership, and plateau handling before touching compose.
- `trace-too-sparse`: request missing field/OpenCV/compose values instead of PNG tuning.
