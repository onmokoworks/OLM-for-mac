# OLMDirectionalBlur remaining-six native UCRT expf request

Run from 64-bit x64 PowerShell on Windows:

    powershell -ExecutionPolicy Bypass -File .\run_olmdirectionalblur_remaining6_ucrt_expf.ps1

The package evaluates all 494 Gaussian source-expression rows for counts 8, 50, 96, 100 and 240
through native `%WINDIR%\System32\ucrtbase.dll!expf`, records exact float32
result bits and DLL identity, and creates a return ZIP. It does not launch
After Effects.

This closes only the missing native math leaf. Production promotion still
requires rebuilding the six fixed public outputs from these returned words and
matching them to a native-Windows-derived same-source oracle. AEXCompat's
host-side native-f32 leaf is not accepted as native Windows evidence. Counts
96 and 240 are recaptured in this same run, avoiding cross-version UCRT mixing.

At index zero the source expression records IEEE-754 `-0`, while the compiled
production call materializes `+0`. The strict intake requires native
`expf(-0)` to return exact `+1`; keyed downstream replay then normalizes only
that signed-zero pair. No nonzero argument is generalized.
