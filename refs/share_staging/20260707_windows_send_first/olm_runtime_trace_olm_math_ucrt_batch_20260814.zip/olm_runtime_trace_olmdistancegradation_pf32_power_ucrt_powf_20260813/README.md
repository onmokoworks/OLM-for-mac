# OLMDistanceGradation PF32 Power native UCRT powf request

Run from 64-bit x64 PowerShell on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_olmdistancegradation_pf32_power_ucrt_powf.ps1
```

This evaluates 63 production-derived float32 input pairs with native
`%WINDIR%\System32\ucrtbase.dll!powf`, records exact result bits and DLL
identity, and creates a return ZIP. It does not launch After Effects.

The returned table is necessary but not sufficient for promotion. Actual-AEX
pre-call XMM inputs are separately bound as an in-order production subsequence,
with the seven production-only transparent-pixel pairs proven output-irrelevant.
Eight final outputs rebuilt from the returned native UCRT words must still be
raw-exact before PF32 Power can leave its current fail-closed policy.
