@echo off
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -m -r C:\Users\Public\OLMWitness\w_7dd4778339a0\queue.jsx
exit /b %ERRORLEVEL%
