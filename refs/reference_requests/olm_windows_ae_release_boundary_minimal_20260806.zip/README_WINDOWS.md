# Minimal OLM Windows AE release-boundary batch

Run only the single row in `BATCH_CONTRACT.json`: OLMSmoother v1 `case_0001`
at native PF16.  The other nine plug-ins are evidence reuse rows and MUST NOT
be rerendered.  In particular, do not recapture ColorKeep or OLMKiraKira: their
remaining release work is Mac-host/production closure using retained Windows
references.  Use a fresh AE 26.3x87 process/project/effect, Software
renderer (raw 1816), working space None, linear blending off, straight-alpha
Preserve-RGB import, and the pinned AEX/source/template hashes.

For each row render disabled and enabled branches to uncompressed scanline
FLOAT32 OpenEXR and retain `attestation.json` with every field listed in the
contract.  Hash files after AE exits.  Do not substitute PNG previews.

Before returning, run:

    py -3 VERIFY_RETURN.py RETURN_OLM_WINDOWS_AE_RELEASE_BOUNDARY_MINIMAL_20260806.zip
