# OLM cross-host linear input

Run `scripts\run_olm_crosshost_linear_input_20260806.ps1`. This is six rows only (ColorKeep/Kira, PF8/PF16/PF32). FLOAT32 EXR input and live Preserve RGB readback are mandatory.
