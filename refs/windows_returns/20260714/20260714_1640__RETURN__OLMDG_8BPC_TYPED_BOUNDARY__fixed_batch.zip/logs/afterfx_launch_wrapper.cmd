@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\olm_short\incoming_20260714_witness_batch_fixed\extracted\windows_witness_batch_20260713\batch_work\002_windows_witness_olmdistancegradation_8bpc_typed_boundary_20260713\package\work\dg8typed-acc91a881717459eb45543eac501391f"
set "WINDOWS_WITNESS_RUN_ID=dg8typed-acc91a881717459eb45543eac501391f"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\olm_short\incoming_20260714_witness_batch_fixed\extracted\windows_witness_batch_20260713\batch_work\002_windows_witness_olmdistancegradation_8bpc_typed_boundary_20260713\package"
set "WINDOWS_WITNESS_QUEUE_SHA256=342d56c7eaa3aa735cad8f340d65958eb0ce99e331f521d80b15f51928cd951a"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT=1"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -m -r C:\Users\Public\OLMWitness\w_9e39122e3a82\queue.jsx
exit /b %ERRORLEVEL%
