# Windows return summary

- status: exact_bind_failure
- request_id: olmdirectionalblur_alpha_fade_fullrender_row755_20260712
- run_id: dblur-row755-294e8b9aacf24dfaaea3bcdda8441856
- host: After Effects 2025, supplied quoted-JSX chunked runner
- AEX identity: matched expected size and SHA256 exactly
- failure: `stage=ae_pause` / `ready marker not written`
- never reached: JSX pause handshake, AE-side logging, module lookup, CDB attach,
  chunk capture, chunk combine
- missing: `ae_render.log`, `ae_render_result.json`, `cdb_output.txt`,
  `cdb_stderr.txt`, and all requested row755 bin outputs
