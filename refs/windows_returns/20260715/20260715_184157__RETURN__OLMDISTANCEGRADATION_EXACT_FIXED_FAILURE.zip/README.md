# OLMDistanceGradation exact-coordinate probe

Status: `exact_bind_failure` for the requested typed coordinate, with a
complete three-case AE control capture.

- AE 2025: 25.2x131
- Project: 8bpc, Software, working space None
- Cases 0001, 0015, 0029: all `status=ok`
- The current AEX loaded and PF8/PF32 breakpoints were armed at the live
  module base plus the requested RVAs.
- The corrected condition `(edx==397) and (r8d==281)` produced no hit in any
  case. The trace retains the exact breakpoint addresses and raw CDB log.
