DirectionalBlur row755 no-space JSX retry return.

Status: `exact_bind_failure`

What succeeded:
- The supplied no-space JSX launch path strategy worked.
- After Effects 2025 launched, the JSX added `OLM Directional Blur`, and the pause handshake completed.
- The live module was resolved by hash and CDB attached to the correct AE PID.
- `DBR_ABSOLUTE_BASE` and `DBR_BREAKPOINTS_READY` were recorded.

What failed:
- The generated CDB breakpoint command at `OLMDirectionalBlur+0x5554` overflowed into malformed quoted text while expanding the 21 chunked `.writemem` operations.
- The rowdriver breakpoint command also produced a CDB expression parse failure.
- Because of those syntax failures, no valid `DBR_STAGE` / `DBR_PROVENANCE` capture fired and no combined row755 plane binaries were produced.

Observed failure markers:
- `Malformed string` while defining the `+0x5554` capture breakpoint
- `Syntax error` in the continued chunk-command tail
- `Numeric expression missing` in the rowdriver conditional
- Final debugger marker: `DBR_NO_CAPTURE`

Artifacts are in `artifacts/`. This return is intentionally marked as failed rather than partial.
