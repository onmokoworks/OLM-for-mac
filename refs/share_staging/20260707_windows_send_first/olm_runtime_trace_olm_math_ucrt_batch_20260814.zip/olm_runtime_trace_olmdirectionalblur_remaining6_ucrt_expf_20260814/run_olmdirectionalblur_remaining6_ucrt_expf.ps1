param([string]$OutputDir = "")
$ErrorActionPreference = "Stop"
$requestId = "olm_runtime_trace_olmdirectionalblur_remaining6_ucrt_expf_20260814"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$runRoot = if ($OutputDir) { $OutputDir } else { Join-Path $root "return" }
$runDir = Join-Path $runRoot $requestId
$zipPath = Join-Path $runRoot ($requestId + "_return_windows.zip")
$ucrtPath = Join-Path $env:WINDIR "System32\ucrtbase.dll"

function Write-Utf8NoBom([string]$Path, [string]$Content) {
  [IO.File]::WriteAllText($Path, $Content, (New-Object Text.UTF8Encoding($false)))
}
function Sha([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Hex32([uint32]$Value) { "0x{0:x8}" -f $Value }

if (-not [Environment]::Is64BitProcess -or $env:PROCESSOR_ARCHITECTURE -ne "AMD64") {
  throw "Run from 64-bit x64 PowerShell"
}
if (-not (Test-Path -LiteralPath $ucrtPath)) { throw "Missing $ucrtPath" }
if (Test-Path -LiteralPath $runDir) { Remove-Item -LiteralPath $runDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $runRoot | Out-Null
New-Item -ItemType Directory -Force -Path $runDir | Out-Null
Add-Type -LiteralPath (Join-Path $root "UcrtExpfCapture.cs")
$vectorsPath = Join-Path $root "expf_vectors.json"
$vectors = Get-Content -Raw -LiteralPath $vectorsPath | ConvertFrom-Json
$ucrtInfo = [Diagnostics.FileVersionInfo]::GetVersionInfo($ucrtPath)
$ucrt = [ordered]@{
  path=$ucrtPath; file_version=$ucrtInfo.FileVersion
  product_version=$ucrtInfo.ProductVersion; sha256=(Sha $ucrtPath)
}
$rows = @()
foreach ($vector in $vectors) {
  $argumentBits = [Convert]::ToUInt32($vector.argument_bits.Substring(2), 16)
  $resultBits = [UcrtExpfCapture]::Evaluate($argumentBits)
  $rows += [ordered]@{
    count=[int]$vector.count; index=[int]$vector.index
    ratio_bits=$vector.ratio_bits; ratio_square_bits=$vector.ratio_square_bits
    denominator_bits=$vector.denominator_bits; numerator_bits=$vector.numerator_bits
    argument_bits=$vector.argument_bits; native_ucrt_result_bits=(Hex32 $resultBits)
    ucrtbase_path=$ucrt.path; ucrtbase_file_version=$ucrt.file_version
    ucrtbase_product_version=$ucrt.product_version; ucrtbase_sha256=$ucrt.sha256
  }
}
$summary = [ordered]@{
  schema="olmdirectionalblur.remaining6-ucrt-expf-return/1"; request_id=$requestId
  status="answered_native_windows_ucrt_expf"; process_bitness=([IntPtr]::Size*8)
  processor_architecture=$env:PROCESSOR_ARCHITECTURE; ucrtbase=$ucrt
  counts=@(8,50,96,100,240); vector_count=$rows.Count; vectors_sha256=(Sha $vectorsPath); rows=$rows
}
$summaryPath = Join-Path $runDir "run_summary.json"
Write-Utf8NoBom $summaryPath (($summary | ConvertTo-Json -Depth 8) + [Environment]::NewLine)
Copy-Item -LiteralPath (Join-Path $root "request_manifest.json") -Destination $runDir
Copy-Item -LiteralPath $vectorsPath -Destination $runDir
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
Compress-Archive -Path (Join-Path $runDir "*") -DestinationPath $zipPath
Write-Output ($summary | ConvertTo-Json -Depth 8)
