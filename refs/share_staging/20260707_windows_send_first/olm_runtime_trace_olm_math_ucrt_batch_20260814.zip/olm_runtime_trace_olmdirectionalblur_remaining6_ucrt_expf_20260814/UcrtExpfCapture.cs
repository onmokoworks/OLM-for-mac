using System;
using System.Runtime.InteropServices;

public static class UcrtExpfCapture
{
    [DllImport("ucrtbase.dll", CallingConvention = CallingConvention.Cdecl,
        ExactSpelling = true, EntryPoint = "expf")]
    public static extern float Expf(float value);

    public static uint Evaluate(uint argumentBits)
    {
        float argument = BitConverter.ToSingle(BitConverter.GetBytes(argumentBits), 0);
        float result = Expf(argument);
        return BitConverter.ToUInt32(BitConverter.GetBytes(result), 0);
    }
}
