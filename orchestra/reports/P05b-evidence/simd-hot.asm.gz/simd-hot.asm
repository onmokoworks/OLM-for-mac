    bca8:	6e 02 26 1e	fmov	w14, s19
    bcac:	c4 79 00 12	and	w4, w14, #0x7fffffff
    bcb0:	bb 02 26 1e	fmov	w27, s21
    bcb4:	7b 7b 00 12	and	w27, w27, #0x7fffffff
    bcb8:	36 00 80 52	mov	w22, #0x1
    bcbc:	16 f0 af 72	movk	w22, #0x7f80, lsl #16
    bcc0:	7f 03 19 6b	cmp	w27, w25
    bcc4:	d3 3e 37 1e	fcsel	s19, s22, s23, lo
    bcc8:	e0 22 37 1e	fcmp	s23, s23
    bccc:	fb 02 26 1e	fmov	w27, s23
    bcd0:	02 61 4d 7a	ccmp	w8, w13, #0x2, vs
    bcd4:	60 93 4b 7a	ccmp	w27, w11, #0x0, ls
    bcd8:	f3 1e 33 1e	fcsel	s19, s23, s19, ne
    bcdc:	c8 01 0a 32	orr	w8, w14, #0x400000
    bce0:	15 01 27 1e	fmov	s21, w8
    bce4:	9f 00 11 6b	cmp	w4, w17
    bce8:	73 3e 35 1e	fcsel	s19, s19, s21, lo
    bcec:	df 07 00 71	cmp	w30, #0x1
    bcf0:	e8 b2 9e 1a	csel	w8, w23, w30, lt
    bcf4:	ae b0 89 9a	csel	x14, x5, x9, lt
    bcf8:	1e 05 00 51	sub	w30, w8, #0x1
    bcfc:	10 06 00 11	add	w16, w16, #0x1
    bd00:	9f 02 10 6b	cmp	w20, w16
    bd04:	a0 07 00 54	b.eq	0xbdf8
    bd08:	15 02 23 1e	ucvtf	s21, w16
    bd0c:	a9 02 26 1e	fmov	w9, s21
    bd10:	3f 01 0d 6b	cmp	w9, w13
    bd14:	b6 8e 32 1e	fcsel	s22, s21, s18, hi
    bd18:	db 02 26 1e	fmov	w27, s22
    bd1c:	7b 7b 00 12	and	w27, w27, #0x7fffffff
    bd20:	7f 03 11 6b	cmp	w27, w17
    bd24:	a3 00 00 54	b.lo	0xbd38
    bd28:	c9 02 26 1e	fmov	w9, s22
    bd2c:	29 01 0a 32	orr	w9, w9, #0x400000
    bd30:	35 01 27 1e	fmov	s21, w9
    bd34:	04 00 00 14	b	0xbd44
    bd38:	55 0a 35 1e	fmul	s21, s18, s21
    bd3c:	a0 22 35 1e	fcmp	s21, s21
    bd40:	a6 04 00 54	b.vs	0xbdd4
    bd44:	c9 05 00 d1	sub	x9, x14, #0x1
    bd48:	16 e4 00 2f	movi	d22, #0000000000000000
    bd4c:	df 05 00 f1	cmp	x14, #0x1
    bd50:	6b 01 00 54	b.lt	0xbd7c
    bd54:	9f 03 0e eb	cmp	x28, x14
    bd58:	ca 00 00 54	b.ge	0xbd70
    bd5c:	2e 01 1c cb	sub	x14, x9, x28
    bd60:	df 01 02 eb	cmp	x14, x2
    bd64:	c2 00 00 54	b.hs	0xbd7c
    bd68:	ee 09 0e 8b	add	x14, x15, x14, lsl #2
    bd6c:	03 00 00 14	b	0xbd78
    bd70:	4e 11 09 8b	add	x14, x10, x9, lsl #4
    bd74:	ce 31 00 91	add	x14, x14, #0xc
    bd78:	d6 01 40 bd	ldr	s22, [x14]
    bd7c:	ae 02 38 1e	fcvtzs	w14, s21
    bd80:	d5 d8 6e bc	ldr	s21, [x6, w14, sxtw #2]
    bd84:	ce 02 26 1e	fmov	w14, s22
    bd88:	ce 79 00 12	and	w14, w14, #0x7fffffff
    bd8c:	df 01 0d 6b	cmp	w14, w13
    bd90:	d7 8e 35 1e	fcsel	s23, s22, s21, hi
    bd94:	fb 02 26 1e	fmov	w27, s23
    bd98:	7b 7b 00 12	and	w27, w27, #0x7fffffff
    bd9c:	7f 03 11 6b	cmp	w27, w17
    bda0:	62 f4 ff 54	b.hs	0xbc2c
    bda4:	b6 0a 36 1e	fmul	s22, s21, s22
    bda8:	c0 22 36 1e	fcmp	s22, s22
    bdac:	db 02 26 1e	fmov	w27, s22
    bdb0:	c2 61 4d 7a	ccmp	w14, w13, #0x2, vs
    bdb4:	60 93 4b 7a	ccmp	w27, w11, #0x0, ls
    bdb8:	01 f4 ff 54	b.ne	0xbc38
    bdbc:	ae 02 26 1e	fmov	w14, s21
    bdc0:	ce 79 00 12	and	w14, w14, #0x7fffffff
    bdc4:	df 01 16 6b	cmp	w14, w22
    bdc8:	97 01 27 1e	fmov	s23, w12
    bdcc:	f6 3e 36 1e	fcsel	s22, s23, s22, lo
    bdd0:	9a ff ff 17	b	0xbc38
    bdd4:	bb 02 26 1e	fmov	w27, s21
    bdd8:	e8 e3 40 b9	ldr	w8, [sp, #0xe0]
    bddc:	1f 01 16 6b	cmp	w8, w22
    bde0:	96 01 27 1e	fmov	s22, w12
    bde4:	d6 3e 35 1e	fcsel	s22, s22, s21, lo
    bde8:	7f 03 0b 6b	cmp	w27, w11
    bdec:	22 01 4d 7a	ccmp	w9, w13, #0x2, eq
    bdf0:	b5 8e 36 1e	fcsel	s21, s21, s22, hi
    bdf4:	d4 ff ff 17	b	0xbd44
    bdf8:	94 02 38 1e	fcvtzs	w20, s20
    bdfc:	9f 0a 00 71	cmp	w20, #0x2
    be00:	eb 0f 00 54	b.lt	0xbffc
    be04:	49 02 26 1e	fmov	w9, s18
    be08:	28 79 00 12	and	w8, w9, #0x7fffffff
    be0c:	e8 e3 00 b9	str	w8, [sp, #0xe0]
    be10:	e8 c3 09 91	add	x8, sp, #0x270
    be14:	0f 25 43 a9	ldp	x15, x9, [x8, #0x30]
    be18:	29 01 0f cb	sub	x9, x9, x15
    be1c:	22 fd 42 93	asr	x2, x9, #2
    be20:	30 00 80 52	mov	w16, #0x1
    be24:	ee 03 1a aa	mov	x14, x26
    be28:	fe 03 00 aa	mov	x30, x0
    be2c:	39 00 00 14	b	0xbf10
    be30:	c8 02 26 1e	fmov	w8, s22
    be34:	08 01 0a 32	orr	w8, w8, #0x400000
    be38:	15 01 27 1e	fmov	s21, w8
    be3c:	36 2a 35 1e	fadd	s22, s17, s21
    be40:	28 02 26 1e	fmov	w8, s17
    be44:	08 79 00 12	and	w8, w8, #0x7fffffff
    be48:	1f 01 0d 6b	cmp	w8, w13
    be4c:	31 8e 35 1e	fcsel	s17, s17, s21, hi
    be50:	2e 02 26 1e	fmov	w14, s17
    be54:	c4 79 00 12	and	w4, w14, #0x7fffffff
    be58:	bb 02 26 1e	fmov	w27, s21
    be5c:	7b 7b 00 12	and	w27, w27, #0x7fffffff
    be60:	39 00 80 52	mov	w25, #0x1
    be64:	19 f0 af 72	movk	w25, #0x7f80, lsl #16
    be68:	7f 03 19 6b	cmp	w27, w25
    be6c:	95 01 27 1e	fmov	s21, w12
    be70:	b1 3e 36 1e	fcsel	s17, s21, s22, lo
    be74:	c0 22 36 1e	fcmp	s22, s22
    be78:	db 02 26 1e	fmov	w27, s22
    be7c:	02 61 4d 7a	ccmp	w8, w13, #0x2, vs
    be80:	60 93 4b 7a	ccmp	w27, w11, #0x0, ls
    be84:	d1 1e 31 1e	fcsel	s17, s22, s17, ne
    be88:	c8 01 0a 32	orr	w8, w14, #0x400000
    be8c:	16 01 27 1e	fmov	s22, w8
    be90:	9f 00 11 6b	cmp	w4, w17
    be94:	31 3e 36 1e	fcsel	s17, s17, s22, lo
    be98:	76 2a 34 1e	fadd	s22, s19, s20
