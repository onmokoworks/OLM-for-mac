/* One desktop AE process, serial readiness handshakes, three typed cases. */
(function () {
    function env(name) { try { return $.getenv(name) || ""; } catch (e) { return ""; } }
    function write(path, text, append) { var f = new File(path); f.encoding = "UTF-8"; if (f.open(append ? "a" : "w")) { f.write(text); f.close(); } }
    var root = File($.fileName).parent.parent.fsName;
    var requestDir = env("OLM_DG_LIVE_REQUEST_DIR");
    var workRoot = env("OLM_DG_LIVE_WORK_ROOT");
    var runId = env("OLM_DG_LIVE_RUN_ID");
    if (!requestDir || !workRoot || !runId) { throw new Error("typed request/work/run binding is required"); }
    var cases = ["case_0001", "case_0015", "case_0029"];
    var queueLog = workRoot + "/AE_TYPED_QUEUE.log";
    write(queueLog, "OLMDG8_QUEUE_START run_id=" + runId + "\n", false);
    for (var i = 0; i < cases.length; i++) {
        var caseId = cases[i];
        $.setenv("OLM_AE_REQUEST_DIR", requestDir);
        $.setenv("OLM_AE_CASE_ID", caseId);
        $.setenv("OLM_AE_OUTPUT_DIR", workRoot + "/single_case_output/" + caseId);
        $.setenv("OLM_AE_LOG_PATH", workRoot + "/AE_SINGLE_CASE_" + caseId + ".log");
        $.setenv("OLM_AE_RESULT_JSON", workRoot + "/AE_SINGLE_CASE_" + caseId + ".json");
        $.setenv("OLM_AE_READY_MARKER", workRoot + "/ae_ready_" + caseId + ".marker");
        $.setenv("OLM_AE_CONTINUE_MARKER", workRoot + "/ae_continue_" + caseId + ".marker");
        $.setenv("OLM_AE_KEEP_OPEN", i === cases.length - 1 ? "0" : "1");
        $.setenv("OLM_AE_FORCE_NEW_PROJECT", i === 0 ? "1" : "0");
        write(queueLog, "OLMDG8_CASE_START run_id=" + runId + " case_id=" + caseId + "\n", true);
        $.evalFile(new File(root + "/scripts/ae_render_single_case.jsx"));
        write(queueLog, "OLMDG8_CASE_END run_id=" + runId + " case_id=" + caseId + "\n", true);
    }
    write(queueLog, "OLMDG8_QUEUE_END run_id=" + runId + "\n", true);
}());
