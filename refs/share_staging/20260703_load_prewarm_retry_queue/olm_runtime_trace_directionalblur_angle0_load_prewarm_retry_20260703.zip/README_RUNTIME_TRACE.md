# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `olmdirectionalblur_angle0_load_prewarm_retry_20260703`
   - Area: OLMDirectionalBlur angle-0 exact-case module-load prewarm retry
   - Action: LIVE NEW TRACE REQUIRED. This retry exists because the previous exact-case narrow-gate run stalled before `OLMDirectionalBlur` loaded. Use the real request set `directionalblur_context_scale_20260606`, case `db_existing_case_0001_software_pair`, and follow `refs/conformance/smoother2_directionalblur_startup_stall_retry_20260703.md`. Do not begin with the narrow helper breakpoints. First prove that the exact case/project path really loads `OLMDirectionalBlur` in the current AE session. If needed, use a prewarm render or a load-only pass with only `sxe ld:OLMDirectionalBlur(.aex)` and minimal logging. Once the load marker is confirmed, bind only one narrow helper-stage family for the same session or immediately report the exact startup log tail if the session stalls before load again.
   - Stop: A satisfactory answer must at minimum confirm target module load for the real angle-0 case/project path, or return a fresh exact startup-stall signature narrower than the current timeout. It does not need final witness-local values if load stabilization is the only new progress.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
