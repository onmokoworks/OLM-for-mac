@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\olm_short\incoming_20260714_witness_batch_fixed\extracted\windows_witness_batch_20260713\batch_work\004_windows_witness_olmdistancegradation_case0026_16bpc_livefield_20260713\package\work\olmdg16-case0026-livefield-9222fc97d671488ca2d10703b2577a2f"
set "WINDOWS_WITNESS_RUN_ID=olmdg16-case0026-livefield-9222fc97d671488ca2d10703b2577a2f"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\olm_short\incoming_20260714_witness_batch_fixed\extracted\windows_witness_batch_20260713\batch_work\004_windows_witness_olmdistancegradation_case0026_16bpc_livefield_20260713\package"
set "WINDOWS_WITNESS_QUEUE_SHA256=b4fdda95969244097d7948f063e42143a9417baf77ca466fc1ee01fb4d0c5f04"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT=1"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -m -r C:\Users\Public\OLMWitness\w_7cd1efcdcd8a\queue.jsx
exit /b %ERRORLEVEL%
