# OLM AE Pixel Validation Request

Request id: `ae_pixel_olmsmoother2_no_key_grid_20260619`
Effect: `OLM Smoother v2` / `OLM Smoother v2`

Use the packaged macOS plug-in in After Effects, recreate the listed cases
from `reference_manifest.json`, render each output PNG, and return the PNGs
plus a filled `AE_PIXEL_VALIDATION_RESULT.template.json`.

Input PNGs are in `input/`; Windows expected outputs are in `expected/`.
Returned render PNGs should keep the same frame names, for example
`case_0001.png`.

Gate kind: `host_smoke_pixel_tolerance`.
This is an AE-host integration smoke using the listed thresholds, not a final exact-equivalence claim.

Threshold groups:

- `no_key_grid_exact`: sm2_no_key_s000_r1, sm2_no_key_s025_r1, sm2_no_key_s050_r1, sm2_no_key_s100_r1, sm2_no_key_s000_r2, sm2_no_key_s025_r2, sm2_no_key_s050_r2, sm2_no_key_s100_r2, sm2_no_key_s000_r3, sm2_no_key_s025_r3, sm2_no_key_s050_r3, sm2_no_key_s100_r3; max <= 0, mean <= 0.0, nonzero_px_percent <= 0.0

Important metadata to record:

- AE version
- macOS version
- Project Settings renderer / `project_gpu_accel_type` if available
- Whether AE was launched cleanly after installing the plug-in
- Any missing UI parameter, render error, or crash

Do not use hidden `ADBE Force CPU GPU` as proof of GPU/CPU execution.
Record it only as reference metadata if it appears.
