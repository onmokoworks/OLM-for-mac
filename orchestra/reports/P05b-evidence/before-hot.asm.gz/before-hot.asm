    c8fc:	f4 13 41 b9	ldr	w20, [sp, #0x110]
    c900:	f6 0b 41 b9	ldr	w22, [sp, #0x108]
    c904:	05 00 00 14	b	0xc918
    c908:	10 06 00 11	add	w16, w16, #0x1
    c90c:	ce 11 00 91	add	x14, x14, #0x4
    c910:	ef 05 00 f1	subs	x15, x15, #0x1
    c914:	20 1a 00 54	b.eq	0xcc58
    c918:	c1 01 40 bd	ldr	s1, [x14]
    c91c:	1f 01 19 6b	cmp	w8, w25
    c920:	c0 8d 21 1e	fcsel	s0, s14, s1, hi
    c924:	11 00 26 1e	fmov	w17, s0
    c928:	31 7a 00 12	and	w17, w17, #0x7fffffff
    c92c:	3f 02 1c 6b	cmp	w17, w28
    c930:	a3 00 00 54	b.lo	0xc944
    c934:	11 00 26 1e	fmov	w17, s0
    c938:	31 02 0a 32	orr	w17, w17, #0x400000
    c93c:	20 02 27 1e	fmov	s0, w17
    c940:	07 00 00 14	b	0xc95c
    c944:	c0 09 21 1e	fmul	s0, s14, s1
    c948:	00 20 20 1e	fcmp	s0, s0
    c94c:	11 00 26 1e	fmov	w17, s0
    c950:	02 61 59 7a	ccmp	w8, w25, #0x2, vs
    c954:	20 92 53 7a	ccmp	w17, w19, #0x0, ls
    c958:	80 13 00 54	b.eq	0xcbc8
    c95c:	11 0a c5 1a	udiv	w17, w16, w5
    c960:	31 7e 05 1b	mul	w17, w17, w5
    c964:	11 02 11 4b	sub	w17, w16, w17
    c968:	11 03 11 8b	add	x17, x24, x17
    c96c:	21 f6 7e d3	lsl	x1, x17, #2
    c970:	00 00 26 1e	fmov	w0, s0
    c974:	00 78 00 12	and	w0, w0, #0x7fffffff
    c978:	21 79 75 bc	ldr	s1, [x9, x21, lsl #2]
    c97c:	02 08 21 1e	fmul	s2, s0, s1
    c980:	1f 00 19 6b	cmp	w0, w25
    c984:	03 8c 21 1e	fcsel	s3, s0, s1, hi
    c988:	62 00 26 1e	fmov	w2, s3
    c98c:	43 78 00 12	and	w3, w2, #0x7fffffff
    c990:	42 00 0a 32	orr	w2, w2, #0x400000
    c994:	43 00 27 1e	fmov	s3, w2
    c998:	22 00 26 1e	fmov	w2, s1
    c99c:	42 78 00 12	and	w2, w2, #0x7fffffff
    c9a0:	5f 00 17 6b	cmp	w2, w23
    c9a4:	c1 00 27 1e	fmov	s1, w6
    c9a8:	21 3c 22 1e	fcsel	s1, s1, s2, lo
    c9ac:	40 20 22 1e	fcmp	s2, s2
    c9b0:	42 00 26 1e	fmov	w2, s2
    c9b4:	02 60 59 7a	ccmp	w0, w25, #0x2, vs
    c9b8:	40 90 53 7a	ccmp	w2, w19, #0x0, ls
    c9bc:	41 1c 21 1e	fcsel	s1, s2, s1, ne
    c9c0:	7f 00 19 6b	cmp	w3, w25
    c9c4:	61 8c 21 1e	fcsel	s1, s3, s1, hi
    c9c8:	42 79 61 bc	ldr	s2, [x10, x1, lsl #2]
    c9cc:	22 00 26 1e	fmov	w2, s1
    c9d0:	42 78 00 12	and	w2, w2, #0x7fffffff
    c9d4:	5f 00 19 6b	cmp	w2, w25
    c9d8:	23 8c 22 1e	fcsel	s3, s1, s2, hi
    c9dc:	63 00 26 1e	fmov	w3, s3
    c9e0:	63 78 00 12	and	w3, w3, #0x7fffffff
    c9e4:	7f 00 1c 6b	cmp	w3, w28
    c9e8:	a3 00 00 54	b.lo	0xc9fc
    c9ec:	62 00 26 1e	fmov	w2, s3
    c9f0:	42 00 0a 32	orr	w2, w2, #0x400000
    c9f4:	41 00 27 1e	fmov	s1, w2
    c9f8:	07 00 00 14	b	0xca14
    c9fc:	21 28 22 1e	fadd	s1, s1, s2
    ca00:	20 20 21 1e	fcmp	s1, s1
    ca04:	23 00 26 1e	fmov	w3, s1
    ca08:	42 60 59 7a	ccmp	w2, w25, #0x2, vs
    ca0c:	60 90 53 7a	ccmp	w3, w19, #0x0, ls
    ca10:	80 0e 00 54	b.eq	0xcbe0
    ca14:	41 79 21 bc	str	s1, [x10, x1, lsl #2]
    ca18:	22 79 6b bc	ldr	s2, [x9, x11, lsl #2]
    ca1c:	1f 00 19 6b	cmp	w0, w25
    ca20:	01 8c 22 1e	fcsel	s1, s0, s2, hi
    ca24:	22 00 26 1e	fmov	w2, s1
    ca28:	42 78 00 12	and	w2, w2, #0x7fffffff
    ca2c:	5f 00 19 6b	cmp	w2, w25
    ca30:	a9 00 00 54	b.ls	0xca44
    ca34:	22 00 26 1e	fmov	w2, s1
    ca38:	42 00 0a 32	orr	w2, w2, #0x400000
    ca3c:	41 00 27 1e	fmov	s1, w2
    ca40:	07 00 00 14	b	0xca5c
    ca44:	01 08 22 1e	fmul	s1, s0, s2
    ca48:	20 20 21 1e	fcmp	s1, s1
    ca4c:	22 00 26 1e	fmov	w2, s1
    ca50:	02 60 59 7a	ccmp	w0, w25, #0x2, vs
    ca54:	40 90 53 7a	ccmp	w2, w19, #0x0, ls
    ca58:	00 0d 00 54	b.eq	0xcbf8
    ca5c:	22 00 40 b2	orr	x2, x1, #0x1
    ca60:	42 79 62 bc	ldr	s2, [x10, x2, lsl #2]
    ca64:	23 00 26 1e	fmov	w3, s1
    ca68:	63 78 00 12	and	w3, w3, #0x7fffffff
    ca6c:	7f 00 19 6b	cmp	w3, w25
    ca70:	23 8c 22 1e	fcsel	s3, s1, s2, hi
    ca74:	64 00 26 1e	fmov	w4, s3
    ca78:	84 78 00 12	and	w4, w4, #0x7fffffff
    ca7c:	9f 00 19 6b	cmp	w4, w25
    ca80:	a9 00 00 54	b.ls	0xca94
    ca84:	63 00 26 1e	fmov	w3, s3
    ca88:	63 00 0a 32	orr	w3, w3, #0x400000
    ca8c:	61 00 27 1e	fmov	s1, w3
    ca90:	07 00 00 14	b	0xcaac
    ca94:	21 28 22 1e	fadd	s1, s1, s2
    ca98:	20 20 21 1e	fcmp	s1, s1
    ca9c:	24 00 26 1e	fmov	w4, s1
    caa0:	62 60 59 7a	ccmp	w3, w25, #0x2, vs
    caa4:	80 90 53 7a	ccmp	w4, w19, #0x0, ls
    caa8:	40 0b 00 54	b.eq	0xcc10
    caac:	41 79 22 bc	str	s1, [x10, x2, lsl #2]
    cab0:	22 79 6d bc	ldr	s2, [x9, x13, lsl #2]
    cab4:	1f 00 19 6b	cmp	w0, w25
    cab8:	01 8c 22 1e	fcsel	s1, s0, s2, hi
    cabc:	22 00 26 1e	fmov	w2, s1
    cac0:	42 78 00 12	and	w2, w2, #0x7fffffff
    cac4:	5f 00 19 6b	cmp	w2, w25
    cac8:	a9 00 00 54	b.ls	0xcadc
    cacc:	22 00 26 1e	fmov	w2, s1
    cad0:	42 00 0a 32	orr	w2, w2, #0x400000
    cad4:	41 00 27 1e	fmov	s1, w2
    cad8:	04 00 00 14	b	0xcae8
