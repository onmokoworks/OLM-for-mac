# Windows return for `olmdirectionalblur_alpha_fade_fullrender_row755_20260712`

Status: `exact_bind_failure`

This return was produced from the supplied quoted-JSX chunked-capture retry
package, run against the installed current `OLMDirectionalBlur.aex` on After
Effects 2025.

Observed result:

- AEX identity matched the package expectation exactly.
- The package still failed before the JSX pause handshake began.
- `ae_ready.marker` was never written.
- No `ae_render.log`, no `ae_render_result.json`, and no CDB trace files were
  produced.
- The retry-specific `-m -r` / quoted JSX invocation did not change the outcome
  from the previous `ae_pause` failures.

This means the failure happened before the chunked capture logic, debugger
attach, or any AE-side logging started.

Included artifacts:

- `RETURN_RUNTIME_TRACE.json`
- `run_summary.json`
- `artifacts/attempt_RETURN_RUNTIME_TRACE.json`
- `artifacts/run_listing.json`
- copies of the supplied runner/CDB/JSX used for this run
