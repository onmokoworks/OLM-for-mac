@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\Users\optim\olm_s2_upstream_request\work\smoother2-legacy-upstream-classplane-inprocess-239b7962c4b348f582e86cde7e255cbb"
set "WINDOWS_WITNESS_RUN_ID=smoother2-legacy-upstream-classplane-inprocess-239b7962c4b348f582e86cde7e255cbb"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\Users\optim\olm_s2_upstream_request\package"
set "WINDOWS_WITNESS_QUEUE_SHA256=1c986ead62f5c5886648858c613e72def5283372667308a39cc255aec355160f"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT=1"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -ro C:\Users\Public\OLMWitness\w_ea5ef58c62f7\queue.jsx
exit /b %ERRORLEVEL%
