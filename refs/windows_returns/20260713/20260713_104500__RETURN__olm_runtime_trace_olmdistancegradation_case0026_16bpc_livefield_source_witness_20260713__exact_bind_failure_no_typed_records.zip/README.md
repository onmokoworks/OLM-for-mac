Status: `exact_bind_failure`

This package needed two local syntax repairs in the supplied PowerShell runner before it could execute:
- `${coord}` interpolation instead of `$coord:...`
- hoisting inline `if(...)` expressions that PowerShell does not accept in those positions

After those minimal fixes, the request was run on After Effects 2025 and a CDB trace was produced. The packaged parser originally failed because it expected `cdb_trace.log` while CDB emitted a suffixed trace filename. We re-parsed the actual emitted trace file and updated `RETURN_RUNTIME_TRACE.json` with that result.

Included:
- original package manifests, contract, and runner file as executed locally
- updated `RETURN_RUNTIME_TRACE.json`
- raw debugger outputs and emitted trace in `artifacts/`

Observed failure:
- no typed witness records were present for the four required points
- parse result ended at `typed_capture` with `record_count=0`
