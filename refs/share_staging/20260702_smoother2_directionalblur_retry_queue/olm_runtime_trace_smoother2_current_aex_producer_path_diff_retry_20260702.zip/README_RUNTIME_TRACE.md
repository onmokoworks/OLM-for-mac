# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `olmsmoother2_current_aex_producer_path_diff_20260702`
   - Area: OLMSmoother2 current-AEX producer-path diff from writer anchor
   - Action: LIVE NEW TRACE REQUIRED. Do not answer from retained writer-anchor evidence alone, old notes, or previously known final bytes. This request is only useful if a new debugger pass reaches the first unresolved producer stage. Trace only the two active current-AEX Software residual lanes using the writer-anchored stage matrix in `refs/conformance/olmsmoother2_producer_path_diff_20260702.md`. Do not spend this round on broad PNG rerenders, global toggles, or retired legacy PNGs. Anchor from the already confirmed final writer frame and capture only the first unresolved producer facts. For `legacy_case_0004_current_aex` at `(1903,519)`, prove whether Windows stays on `idx=0xd0 / FUN_180013140` with zero vertices and a nonzero cce0 fallback, or whether it appends a neighbor-derived sample before cce0. Return the c280 switch index, polygon vertex count before bb10/b120, helper append source xy/rgba/weight if any, and cce0 output floats before final u8 packing. For `legacy_case_0012_gamma5_red_blue_current_aex` at `(91,841)`, keep the same writer anchor but isolate the first divergence inside `cardinal6/e170/f270/e3a0`: return c280 switch index, cardinal6 descriptor/key and polygon count before append, e170 bits/code, f270/e3a0 append/no-append facts, and cce0 output floats before final u8 packing.
   - Stop: A satisfactory answer must classify the first unresolved producer stage for at least one of the two active lanes. `0004` is not answered by final writer bytes alone; it needs polygon-or-fallback evidence. `0012` is not answered by a broad cce0 dump alone; it needs the first Windows-vs-local difference inside the `cardinal6/e170/f270/e3a0` chain. If the exact callsite cannot be held, return the precise failed breakpoint/watchpoint reason and the closest writer-anchored frame that still preserves the needed producer inputs. Repeating the known writer-anchor facts alone counts as failure, not partial success.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
