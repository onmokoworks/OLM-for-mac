# OLM native UCRT math batch (AE-free)

This wrapper runs the existing, hash-pinned native Windows requests for:

- OLMDirectionalBlur: `expf`, 494 exact float32 arguments for counts 8, 50, 96, 100 and 240.
- OLMDirectionalBlur: `powf`, 787 exact float32 input/exponent keys observed in the six exported-Smart cells.
- OLMDistanceGradation: `powf`, 63 exact float32 input/exponent pairs.

It launches neither After Effects nor `aerender`. Run it from 64-bit x64
PowerShell after extracting the sibling
`olm_runtime_trace_olm_math_ucrt_batch_20260814.zip`. The ZIP contains this
directory and all three child request directories byte-for-byte. One invocation
produces all three child returns and a batch summary that requires the same
`%WINDIR%\System32\ucrtbase.dll` identity.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run_olm_math_ucrt_batch.ps1 -OutputDir C:\olm-ucrt-return
```

All 1,344 returned words are evidence inputs, not production admission by
themselves. The hostless downstream replay rebuilds the six bounded
DirectionalBlur and eight bounded DistanceGradation public outputs before any
promotion decision. DistanceGradation's actual-AEX pre-call XMM relation is
already closed separately for all 992 real calls.
