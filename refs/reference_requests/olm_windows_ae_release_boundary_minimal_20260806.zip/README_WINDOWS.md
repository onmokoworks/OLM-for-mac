# Minimal OLM Windows AE release-boundary batch

Run only the seven rows in `BATCH_CONTRACT.json`: ColorKeep and OLMKiraKira
Mode4 at PF8/PF16/PF32, plus OLMSmoother v1 `case_0001` at native PF16.  The
other seven plug-ins are evidence reuse rows and MUST NOT be rerendered.  Use
a fresh AE 26.3x87 process/project/effect per row, Software
renderer (raw 1816), working space None, linear blending off, straight-alpha
Preserve-RGB import, and the pinned AEX/source/template hashes.

For each row render disabled and enabled branches to uncompressed scanline
FLOAT32 OpenEXR and retain `attestation.json` with every field listed in the
contract.  Hash files after AE exits.  Do not substitute PNG previews.

Before returning, run:

    py -3 VERIFY_RETURN.py RETURN_OLM_WINDOWS_AE_RELEASE_BOUNDARY_MINIMAL_20260806.zip
