@echo off
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -m -r C:\Users\Public\OLMWitness\w_14ac3e6515e4\queue.jsx
exit /b %ERRORLEVEL%
