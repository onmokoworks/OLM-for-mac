# OLMSmoother2 Writer-Frame Follow-Up Analysis

- Decision: `producer-upstream-of-writer-frame`
- Recommended action: Do not tune final writer or broad alpha handling. The writer-frame floats explain the Windows reference pixels; the remaining work is to identify the upstream c280/helper producer for these frames.

| Case | XY | Writer float | Derived PNG | Reference | Candidate | Explains reference |
| --- | --- | --- | --- | --- | --- | --- |
| `legacy_case_0012_gamma5_red_blue_current_aex` | `[91, 841]` | `[1.0,1.0,1.0,0.0]` | `[0,0,0,0]` | `[0,0,0,0]` | `[90,90,90,91]` | `True` |
| `legacy_case_0004_current_aex` | `[1903, 519]` | `[0.80824906,0.80824906,0.80824906,0.44156867]` | `[103,103,103,113]` | `[103,103,103,113]` | `[0,0,0,0]` | `True` |

## Remaining Unisolated Producer Evidence

- one-shot breakpoint at exact cce0 return address
- c280 switch index at runtime for the exact writer frame
- helper append list / sample source xy / weights for the exact writer frame
- producer classification between fallback, c280 append, or alternate path
