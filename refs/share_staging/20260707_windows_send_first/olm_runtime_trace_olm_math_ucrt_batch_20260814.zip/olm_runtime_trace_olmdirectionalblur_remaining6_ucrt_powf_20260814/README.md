# DirectionalBlur remaining-six native UCRT powf request

Run `run_olmdirectionalblur_remaining6_ucrt_powf.ps1` from 64-bit x64 PowerShell.
It evaluates all 787 exact `powf` keys observed in the six pinned exported-Smart
cells against `%WINDIR%\System32\ucrtbase.dll`. It does not launch After Effects.
Returned words still require same-table exported-AEX and Mac public replay before
any production promotion.
