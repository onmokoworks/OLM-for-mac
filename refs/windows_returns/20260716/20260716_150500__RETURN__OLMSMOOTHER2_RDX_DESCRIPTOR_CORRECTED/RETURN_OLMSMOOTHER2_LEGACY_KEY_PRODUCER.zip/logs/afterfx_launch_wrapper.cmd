@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\Users\optim\olm_s2_rdx_corrected\work\smoother2-legacy-producer-inprocess-fcefd3f4d8b9410b93ede5dff562675b"
set "WINDOWS_WITNESS_RUN_ID=smoother2-legacy-producer-inprocess-fcefd3f4d8b9410b93ede5dff562675b"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\Users\optim\olm_s2_rdx_corrected"
set "WINDOWS_WITNESS_QUEUE_SHA256=ed970c9ea6ee184cd81d53be1eddbbaa3cdbdae64814ad9f60acb6e82e558366"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT=1"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -r C:\Users\Public\OLMWitness\w_87709163b181\queue.jsx
exit /b %ERRORLEVEL%
