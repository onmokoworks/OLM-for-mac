# 32bpc second-generation parity

Run `run.ps1 -AfterFX <AfterFX.exe> -ColorKeyAex <2025 OLMColorKey.aex> -ToonDilateAex <2025 OLMToonDilate.aex>`. This deliberately re-imports the supplied before-effect EXR on Windows and renders both effect-on and no-effect, matching the Mac input generation. Return the generated zip. Any host, hash, effect-state, or artifact mismatch fails closed.
