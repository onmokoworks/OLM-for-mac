# OLMBlur Windows Software 8bpc canonical recapture

Run `run_olmblur_recapture.ps1 -PluginPath <exact installed OLMBlur.aex>` from a clean Windows AE session. The script records path, size, UTC timestamp, SHA-256, AE version, Software renderer, 8bpc project, color settings, the no-effect control, and all seven PNGs. A missing or mismatched AEX exits as `hash_mismatch` before AE is launched.

The effect's `GPU Rendering` parameter is replayed from the normalized cases but is not used to infer the project renderer. `ADBE Force CPU GPU` is metadata-only and is never accepted as renderer evidence.
