# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `olmsmoother2_current_aex_0004_load_prewarm_retry_20260703`
   - Area: OLMSmoother2 current-AEX 0004 exact-case module-load prewarm retry
   - Action: LIVE NEW TRACE REQUIRED. This retry exists because the previous exact-gated 0004 run stalled before `OLMSmoother2` loaded. Use only `legacy_case_0004_current_aex` from `smoother2_legacy_full_current_aex_recapture_20260621`, and follow `refs/conformance/smoother2_directionalblur_startup_stall_retry_20260703.md`. Do not begin with the conditional `+0x350b` witness gate. First prove that the exact case/project path really loads `OLMSmoother2` in the current AE session. If needed, use a prewarm render or a load-only pass with only `sxe ld:OLMSmoother2(.aex)` and minimal logging. Once the load marker is confirmed, bind only one narrow writer-gated breakpoint family for the same session or immediately report the exact startup log tail if the session stalls before load again.
   - Stop: A satisfactory answer must at minimum confirm target module load for `legacy_case_0004_current_aex`, or return a fresh exact startup-stall signature narrower than the current timeout. It does not need final producer facts if load stabilization is the only new progress.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
