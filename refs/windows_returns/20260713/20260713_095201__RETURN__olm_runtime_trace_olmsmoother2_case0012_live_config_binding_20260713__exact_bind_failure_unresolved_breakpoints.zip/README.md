Status: `exact_bind_failure`

This package was executed on After Effects 2025. The runner completed and produced `RETURN.json`, but the configured `OLMSmoother2+...` breakpoints never bound to the live module. CDB repeatedly logged unresolved unqualified symbol errors, so no live `bind / c280 / cce0 / writer` records were captured.

Included:
- original package manifests, contract, and runner files
- emitted `RETURN.json`
- raw debugger outputs and traces in `artifacts/`

Observed failure:
- unresolved breakpoint expressions such as `OLMSmoother2+0x3370`
- final return status `exact_bind_failure`
