# OLMRadialBlur Residual Cluster Audit

| Case | Max | Mean | Nonzero px | Components | Max witness |
| --- | ---: | ---: | ---: | ---: | --- |
| zoom_case_0009 | 1 | 0.004614559 | 31124 (1.5010%) | 26415 | `x=6 y=0 c=3 ref=[20, 3, 3, 254] cand=[20, 3, 3, 255] signed=[0, 0, 0, 1]` |
| tiny_rotation_case_0010 | 255 | 0.010407142 | 33796 (1.6298%) | 26845 | `x=1614 y=6 c=0 ref=[255, 255, 255, 255] cand=[0, 0, 0, 255] signed=[-255, -255, -255, 0]` |

## zoom_case_0009

Largest components:

- size `9`, bbox `[120, 519, 122, 524]`, centroid `[121.11111111111111, 521.6666666666666]`
- size `8`, bbox `[19, 237, 21, 242]`, centroid `[19.875, 239.375]`
- size `8`, bbox `[408, 504, 411, 507]`, centroid `[409.5, 505.375]`
- size `8`, bbox `[362, 524, 363, 529]`, centroid `[362.375, 526.75]`
- size `8`, bbox `[81, 545, 84, 548]`, centroid `[82.125, 547.125]`

Signed channel counts:

- R: positive `7142`, negative `49`, min `-1`, max `1`
- G: positive `33`, negative `27`, min `-1`, max `1`
- B: positive `34`, negative `28`, min `-1`, max `1`
- A: positive `30962`, negative `0`, min `0`, max `1`

## tiny_rotation_case_0010

Largest components:

- size `40`, bbox `[1651, 0, 1659, 5]`, centroid `[1655.7, 2.075]`
- size `38`, bbox `[1791, 0, 1798, 7]`, centroid `[1794.1052631578948, 3.526315789473684]`
- size `30`, bbox `[195, 207, 201, 217]`, centroid `[197.76666666666668, 211.53333333333333]`
- size `30`, bbox `[309, 570, 313, 580]`, centroid `[310.8666666666667, 574.4666666666667]`
- size `29`, bbox `[1917, 824, 1919, 836]`, centroid `[1918.344827586207, 830.2068965517242]`

Signed channel counts:

- R: positive `4925`, negative `1307`, min `-255`, max `75`
- G: positive `1115`, negative `1158`, min `-255`, max `44`
- B: positive `1503`, negative `1279`, min `-255`, max `44`
- A: positive `31204`, negative `0`, min `0`, max `1`
