param(
    [Parameter(Mandatory=$false)][string]$AfterFX = "",
    [Parameter(Mandatory=$false)][string]$PluginPath = "",
    [Parameter(Mandatory=$false)][string]$OutputDir = ""
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Manifest = Join-Path $Root "manifest.json"
$ExpectedHash = "f0611785e7b14ac4fcfc75f23b8862beb4539eee52d25d472556849535e96e5b"
$RunDir = if ($OutputDir) { $OutputDir } else { Join-Path $Root "run" }
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
$Provenance = Join-Path $RunDir "provenance.json"
$Summary = Join-Path $RunDir "run_summary.json"

function Write-Json($Path, $Value) { $Value | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 $Path }
function Stop-FailClosed([string]$Status, [string]$Message) {
    $record = [ordered]@{ kind="olmblur_windows_recapture_run"; status=$Status; error=$Message; rendered=$false; required_sha256=$ExpectedHash }
    Write-Json $Summary $record
    Write-Host "$Status`: $Message" -ForegroundColor Red
    exit 2
}

if (-not (Test-Path $Manifest)) { Stop-FailClosed "missing_manifest" "manifest.json not found" }
$searchRoots = @()
if ($PluginPath) { $searchRoots += $PluginPath }
$searchRoots += @(
    (Join-Path ${env:ProgramFiles} "Adobe\Common\Plug-ins\7.0\MediaCore"),
    (Join-Path ${env:ProgramFiles} "Adobe\After Effects 2026\Support Files\Plug-ins"),
    (Join-Path ${env:ProgramFiles} "Adobe\After Effects 2025\Support Files\Plug-ins")
)
$candidates = @()
foreach ($root in ($searchRoots | Select-Object -Unique)) {
    if (Test-Path $root) { $candidates += Get-ChildItem -LiteralPath $root -Filter "OLMBlur.aex" -File -Recurse -ErrorAction SilentlyContinue }
}
$candidates = @($candidates | Sort-Object FullName -Unique)
if ($candidates.Count -eq 0) { Stop-FailClosed "missing_plugin" "no installed OLMBlur.aex found" }
if ($candidates.Count -gt 1 -and -not $PluginPath) { Stop-FailClosed "ambiguous_plugin_path" "multiple installed OLMBlur.aex files; pass -PluginPath for the exact installed path" }
$plugin = if ($PluginPath) { Get-Item -LiteralPath $PluginPath -ErrorAction SilentlyContinue } else { $candidates[0] }
if (-not $plugin -or $plugin.Name -ne "OLMBlur.aex") { Stop-FailClosed "missing_plugin" "-PluginPath is not an OLMBlur.aex file" }
$hash = (Get-FileHash -LiteralPath $plugin.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
$pluginRecord = [ordered]@{
    path=$plugin.FullName; size_bytes=[int64]$plugin.Length; last_write_time_utc=$plugin.LastWriteTimeUtc.ToString("o"); sha256=$hash; required_sha256=$ExpectedHash
}
$provenance = [ordered]@{ kind="olmblur_aex_provenance"; status="verified"; plugin=$pluginRecord; ae_version="pending_from_AE"; renderer="Software"; project_bits_per_channel=8; color_settings="pending_from_AE"; no_effect_control="required" }
if ($hash -ne $ExpectedHash) { $provenance.status="hash_mismatch"; Write-Json $Provenance $provenance; Stop-FailClosed "hash_mismatch" "installed OLMBlur.aex SHA-256 $hash does not equal required $ExpectedHash" }
Write-Json $Provenance $provenance

if (-not $AfterFX) {
    $AfterFX = (Get-ChildItem (Join-Path ${env:ProgramFiles} "Adobe") -Filter "AfterFX.exe" -File -Recurse -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1).FullName
}
if (-not $AfterFX -or -not (Test-Path $AfterFX)) { Stop-FailClosed "missing_afterfx" "AfterFX.exe was not found; no render was started" }
$caseIds = 1..7 | ForEach-Object { "case_{0:D4}" -f $_ }
$caseResults = @()
foreach ($caseId in $caseIds) {
    $env:OLM_AE_REQUEST_DIR = $Root
    $env:OLM_AE_CASE_ID = $caseId
    $env:OLM_AE_OUTPUT_DIR = (Join-Path $RunDir "rendered")
    $env:OLM_AE_LOG_PATH = (Join-Path $RunDir "$caseId.log")
    $env:OLM_AE_RESULT_JSON = (Join-Path $RunDir "$caseId.result.json")
    $env:OLM_AE_PROVENANCE_JSON = $Provenance
    $env:OLM_AE_FORCE_SOFTWARE = "1"
    & $AfterFX -r (Join-Path $Root "render_olmblur_case.jsx")
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path (Join-Path $RunDir "rendered") "$caseId.png"))) { Stop-FailClosed "render_failed" "$caseId did not produce a PNG" }
    $caseResults += Get-Content $env:OLM_AE_RESULT_JSON -Raw | ConvertFrom-Json
}
$firstResult = $caseResults[0]
$provenance = Get-Content $Provenance -Raw | ConvertFrom-Json
$provenance.ae_version = $firstResult.ae_version
$provenance.project_bits_per_channel = $firstResult.project_bits_per_channel
$provenance.color_settings = [ordered]@{ working_space=$firstResult.project_working_space; linear_blending=$firstResult.project_linear_blending; bits_per_channel=$firstResult.project_bits_per_channel }
Write-Json $Provenance $provenance
$env:OLM_AE_CASE_ID = "case_0001"
$env:OLM_AE_OUTPUT_DIR = (Join-Path $RunDir "no_effect_control")
$env:OLM_AE_LOG_PATH = (Join-Path $RunDir "no_effect_control.log")
$env:OLM_AE_RESULT_JSON = (Join-Path $RunDir "no_effect_control.result.json")
$env:OLM_AE_DISABLE_EFFECT = "1"
& $AfterFX -r (Join-Path $Root "render_olmblur_case.jsx")
if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $RunDir "no_effect_control\case_0001.png"))) { Stop-FailClosed "no_effect_control_failed" "no-effect control did not produce a PNG" }
$control = Get-Content $env:OLM_AE_RESULT_JSON -Raw | ConvertFrom-Json
Remove-Item Env:OLM_AE_DISABLE_EFFECT -ErrorAction SilentlyContinue
$summaryRecord = [ordered]@{ kind="olmblur_windows_recapture_run"; status="rendered"; rendered=$true; renderer="Software"; project_bits_per_channel=8; color_settings="recorded in AE result"; provenance=(Get-Content $Provenance -Raw | ConvertFrom-Json); no_effect_control=$control; cases=$caseResults; outputs=(Get-ChildItem (Join-Path $RunDir "rendered") -Filter "case_*.png" | Select-Object -ExpandProperty FullName) }
Write-Json $Summary $summaryRecord
Write-Host "OK: seven OLMBlur 8bpc Software PNGs written to $RunDir\rendered"
