# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `olmsmoother2_current_aex_0004_writer_gate_retry_20260702`
   - Area: OLMSmoother2 current-AEX 0004 writer-gated producer retry
   - Action: LIVE NEW TRACE REQUIRED. Do not start with broad unconditioned `+0xc280/+0xcce0/+0x350b/+0x3610` breakpoints. Use only `legacy_case_0004_current_aex` from `smoother2_legacy_full_current_aex_recapture_20260621`, targeting witness `(1903,519)`, and follow the gating contract in `refs/conformance/olmsmoother2_current_aex_0004_writer_gate_retry_20260702.md`. First bind the exact output address or exact writer-frame xy for `(1903,519)` from the writer anchor. Only after that exact writer hit is confirmed, single-step or one-shot-break through the corresponding `+0x350b -> +0x3510` call path for the same frame. From that exact frame, capture c280 switch index, polygon vertex count before `bb10/b120`, helper append source xy/rgba/weight or proof of no append, and cce0 output floats before final u8 packing.
   - Stop: A satisfactory answer must return at least one new witness-local producer fact for `legacy_case_0004_current_aex (1903,519)` from a gated frame. Known writer-anchor bytes/floats or another broad hit storm count as failure.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
