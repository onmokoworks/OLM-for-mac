@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\olm_short\single_20260714\job006\work_fixed2\kk-mode3-411d4f671e0d4e9097c0838c5b6371c3"
set "WINDOWS_WITNESS_RUN_ID=kk-mode3-411d4f671e0d4e9097c0838c5b6371c3"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\olm_short\single_20260714\job006\package_fixed2"
set "WINDOWS_WITNESS_QUEUE_SHA256=76478a4af628768a35ca306f8f79f6e320ac20ca90f9263b066e1c57f8700270"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_PARAM_OVERRIDES_JSON={"OLM OLM Kira Kira-0003":5,"OLM OLM Kira Kira-0004":0,"OLM OLM Kira Kira-0005":0,"OLM OLM Kira Kira-0026":0}"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -m -r C:\Users\Public\OLMWitness\w_1b465867bb8f\queue.jsx
exit /b %ERRORLEVEL%
