# Windows Codex Handoff: OLM Reference Requests

You are running on the Windows AE machine. Render the selected OLM Tools
reference requests in this package and return a packed result zip to the
Mac porting workspace.

Hard requirements:

- This zip is self-contained as a request/spec package. It does not
  include the Mac porting repository or a Windows AE automation runner.
- You do not need the Mac OLM worktree to render these references.
  You do need Windows After Effects with the original OLM Tools AEX
  plug-ins installed and an AE script/runner that can read these JSON
  request specs, set the listed effect properties, render PNGs, and
  write the return manifest.
- Prefer `project_gpu_accel_type.current_name = SOFTWARE` first.
- CUDA renders are useful but optional unless a request marks them required.
- Record `project_gpu_accel_type.current_name` and raw value in the manifest.
- Keep `ADBE Force CPU GPU` / hidden GPU Rendering as reference-only metadata.
- Save `before_effects_frame` and the effect output PNG for every case.
- Record all selected effect property names, match_names, indices, values,
  and enabled/active state.
- If a request asks for instrumentation that AE scripting cannot access,
  record that limitation explicitly rather than inventing a value.

Selected requests: 1
Total requested cases before render-set multiplication: 9

## Request Summaries

### olm_bitdepth_32bpc_colorkey_probe_20260701

- Effect: `OLM bit-depth conformance batch` / `mixed`
- Cases: 9
- Required render set(s): SOFTWARE
- Why: The listed feature groups are normalized 8bpc Windows Software exact and need 32bpc output-format probing before 32bpc exactness can be claimed.
- Case ids: olmcolorkey__case_0001, olmcolorkey__case_0002, olmcolorkey__case_0003, olmcolorkey__case_0004, ...
- Mac follow-up: Import with scripts/intake_olm_return.py path/to/returned_reference.zip --quick.

## Return Shape

Windows-side setup:

- Create any working folder for the extracted request package.
- Extract this zip there.
- Use the JSON files under `refs/reference_requests/` as render specs.
- If no existing AE runner is available, create a minimal ExtendScript
  or Windows Codex helper that reads these specs, applies the requested
  OLM effect parameters, saves `before_effects_frame` PNGs, renders the
  effect PNGs, and writes the manifest described below.
- The Mac-side commands in this README are for after the returned zip is
  copied back to the Mac repository; do not run them on the Windows box
  unless that repository also exists there.

Return one zip containing:

- Rendered PNG outputs.
- Matching `before_effects_frame` PNGs.
- A manifest JSON with render-set metadata and all effect parameters.
- Any AE script/log output or error screenshots if a case fails.

The Mac side will import the result with:

```sh
python3 scripts/intake_olm_return.py path/to/returned_reference.zip --quick --dispatch-dir /tmp/olm_reference_dispatch
```

That command auto-detects Windows reference returns, imports the manifest,
runs post-import request checks, writes per-request `SUBAGENT.md` files,
prints the prioritized next action, and runs the quick AE-free aggregate smoke.

If manual low-level validation is needed, use:

```sh
python3 refs/scripts/import_and_check_win_reference.py path/to/returned_reference.zip --quick --dispatch-dir /tmp/olm_reference_dispatch
python3 refs/scripts/verify_reference_request_result.py refs/reference_requests/<request>.json path/to/imported/reference_manifest.json
```
