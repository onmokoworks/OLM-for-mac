# OLMBlur Windows dual-depth canonical recapture

Run `run_olmblur_dual_depth.ps1 -PluginPath <exact OLMBlur.aex> -AfterFX <AfterFX.exe> -ExrOutputTemplate 'OLMBlur OpenEXR RGBA Float32 No Compression'`. The runner hashes the AEX before launching AE, uses Software rendering with linear blending off, renders seven 8bpc PNGs and seven 32bpc FLOAT32 RGBA no-compression OpenEXR files, runs one disabled-effect control per lane, and writes `run/return_manifest.json`. Any gate failure exits before claiming rendered output.
