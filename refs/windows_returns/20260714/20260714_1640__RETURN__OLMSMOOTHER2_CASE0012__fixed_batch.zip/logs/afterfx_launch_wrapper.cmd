@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\olm_short\incoming_20260714_witness_batch_fixed\extracted\windows_witness_batch_20260713\batch_work\003_olmsmoother2_case0012_current_aex_20260713\package\work\smoother2-case0012-8ce2cd5eed6d434fbad50cd29d816c40"
set "WINDOWS_WITNESS_RUN_ID=smoother2-case0012-8ce2cd5eed6d434fbad50cd29d816c40"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\olm_short\incoming_20260714_witness_batch_fixed\extracted\windows_witness_batch_20260713\batch_work\003_olmsmoother2_case0012_current_aex_20260713\package"
set "WINDOWS_WITNESS_QUEUE_SHA256=ed970c9ea6ee184cd81d53be1eddbbaa3cdbdae64814ad9f60acb6e82e558366"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT=1"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -m -r C:\Users\Public\OLMWitness\w_963a82689a23\queue.jsx
exit /b %ERRORLEVEL%
