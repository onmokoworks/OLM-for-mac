# OLMSmoother2 Current-AEX Proof Plan

- Decision: `producer-upstream-of-writer-frame-required`
- Recommended action: Keep the Smooth Range threshold fix and do not request broad PNGs. The final writer/raw packing is satisfied for both witnesses; only producer-side c280/helper/alternate-path proof can justify another implementation change.

## Witnesses

| Case | XY | Static dispatch | Shape | Local path | Stop line |
| --- | --- | --- | --- | --- | --- |
| `legacy_case_0004_current_aex` | `[1903, 519]` | `0xd0 -> FUN_180013140` | `windows-adds-semitransparent-output-where-local-passthrough-is-transparent` | `local-transparent-center-no-polygon-passthrough` | Do not add a global transparent-center fallback. This witness only proves a 0004-local path if cce0/c280 emits a neighbor sample for the same call. |
| `legacy_case_0012_gamma5_red_blue_current_aex` | `[91, 841]` | `0x69 -> FUN_1800125c0 -> FUN_180010760 -> FUN_18000cc70` | `local-adds-semitransparent-output-where-windows-stays-transparent` | `local-cardinal6-f270-e3a0-append` | Do not suppress f270 or transparent-center appends globally. Prior probes show global f270 suppression worsens the case set. |

## Satisfied Probes

- `legacy_case_0004_current_aex` `writer-anchor`: final raw 0xe8e8e871 derives [103, 103, 103, 113] after AE premultiply
- `legacy_case_0012_gamma5_red_blue_current_aex` `writer-anchor`: final raw 0xffffff00 derives [0, 0, 0, 0] after AE premultiply

## Remaining Probes

- `legacy_case_0004_current_aex` `cce0-return`
- `legacy_case_0004_current_aex` `c280-polygon`
- `legacy_case_0004_current_aex` `neighbor-correlation`
- `legacy_case_0012_gamma5_red_blue_current_aex` `descriptor`
- `legacy_case_0012_gamma5_red_blue_current_aex` `emit-chain`
- `legacy_case_0012_gamma5_red_blue_current_aex` `blend`

## Ordered Probes

### legacy_case_0004_current_aex `[1903, 519]`

- Static dispatch: `0xd0` -> `FUN_180013140`
- Case-map evidence: disasm/OLMSmoother2_case_map.txt maps 0xd0/0xd1 to FUN_180013140.
- Port evidence: mac/OLMSmoother2/Mac/OLMSmoother2_port.cpp dispatches case 0xd0/0xd1 to win_FUN_180013140(poly).
- Helper fact: guard returns when y == height - 1 or x == 0
- Helper fact: scans dbd0 and d6a0, then derives spanX/spanY
- Helper fact: rejects when both spans are >= 4
- Helper fact: for spans >= 2, side-channel byte at (x-1,y) byte index 3 can reject
- Helper fact: appends (x-1,y), (x-1,y-1), and (x,y-1) with corner weights
- Required proof: Windows must decide whether idx=208 also produces zero polygon vertices, or whether a helper appends neighbor-derived samples before cce0.
- Writer-frame evidence: raw `0xe8e8e871` derives `[103, 103, 103, 113]`; reference `[103, 103, 103, 113]`; candidate `[0, 0, 0, 0]`.

1. `writer-anchor` [satisfied]: Does the target still store Windows `[103,103,103,113]` at the final 8bpc writer? Values: final writer bytes; writer stack x/y; output buffer pointer. Evidence: final raw 0xe8e8e871 derives [103, 103, 103, 113] after AE premultiply.
2. `cce0-return` [unresolved]: Does Windows cce0 return a nonzero semitransparent value for the transparent center? Values: cce0 output floats; poly count before b120; passthrough/fallback flag.
3. `c280-polygon` [unresolved]: Does the 0xd0/FUN_180013140 path pass the span/side-channel guards and append neighbor-derived samples? Values: idx; class-plane bits; append list; sample source xy/rgba/weight.
4. `neighbor-correlation` [unresolved]: Does the missing center value match one of the strongest neighboring cells? Values: neighbor [1903, 518]; neighbor [1901, 520]; neighbor [1901, 519].

### legacy_case_0012_gamma5_red_blue_current_aex `[91, 841]`

- Static dispatch: `0x69` -> `FUN_1800125c0 -> FUN_180010760 -> FUN_18000cc70`
- Case-map evidence: disasm/OLMSmoother2_case_map.txt maps 0x49/0x4d/0x61/0x69/0x6d to FUN_1800125c0 -> FUN_180010760 -> FUN_18000cc70.
- Port evidence: mac/OLMSmoother2/Mac/OLMSmoother2_port.cpp dispatches case 0x69 to win_FUN_1800125c0(poly), win_cardinal_6(poly), normalize; win_cardinal_6 is the local FUN_180010760 model.
- Helper fact: FUN_1800125c0 emits the 12-o-clock/NW-end contribution
- Helper fact: FUN_180010760 returns when x == width - 1
- Helper fact: FUN_180010760 scans d3b0 and da50, builds a six-int descriptor, then dispatches through fef0
- Helper fact: FUN_18000cc70 normalizes the accumulated polygon after both emitters
- Required proof: Windows must decide whether this exact witness differs in c280 idx, cardinal6 desc/key, e170 bits/code, f270/e3a0 emission, cce0 blend, or final u8 writer.
- Writer-frame evidence: raw `0xffffff00` derives `[0, 0, 0, 0]`; reference `[0, 0, 0, 0]`; candidate `[90, 90, 90, 91]`.

1. `writer-anchor` [satisfied]: Does Windows still store transparent output at the final 8bpc writer? Values: final writer bytes; writer stack x/y; output buffer pointer. Evidence: final raw 0xffffff00 derives [0, 0, 0, 0] after AE premultiply.
2. `descriptor` [unresolved]: Does Windows FUN_180010760 enter the same cardinal6 descriptor/key as local? Values: idx; cardinal6 desc; key; polygon count before append.
3. `emit-chain` [unresolved]: Where does the local f270/e3a0 append disappear in Windows? Values: d3b0/da50 state; e170 bits/code; f270 branch; e3a0 trap/weight; append/no-append.
4. `blend` [unresolved]: If Windows appends the same sample, does cce0/b120 zero it later? Values: pre-b120 rgba; post-b120 rgba; final writer bytes.
