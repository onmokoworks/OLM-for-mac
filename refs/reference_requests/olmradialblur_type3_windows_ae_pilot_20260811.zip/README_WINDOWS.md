# OLMRadialBlur Type 3 PF32 pilot

Run `RUN_WINDOWS.ps1`. Exactly eight fresh AE 25.2x131 Software processes are used. If AE exposes `OLM RadialBlur-0021` as `NO_VALUE`, the runner stops with `NOISE_LAYER_BINDING_UNAVAILABLE`; an output made with the default None layer is never accepted.
