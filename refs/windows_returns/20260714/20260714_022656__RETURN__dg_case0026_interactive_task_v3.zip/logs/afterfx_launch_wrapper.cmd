@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\olm_short\incoming_20260714_dg_case0026_interactive_task_v3\package\work\olmdg16-case0026-livefield-69c74f67b8a24dadbf9ed3852ef6ce3b"
set "WINDOWS_WITNESS_RUN_ID=olmdg16-case0026-livefield-69c74f67b8a24dadbf9ed3852ef6ce3b"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\olm_short\incoming_20260714_dg_case0026_interactive_task_v3\package"
set "WINDOWS_WITNESS_QUEUE_SHA256=25507a4b204375d08acca1f04a4212fb03ccf38b6d72178cdf9f347b390622b2"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT=1"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -m -r C:\Users\Public\OLMWitness\w_03efb172191a\queue.jsx
exit /b %ERRORLEVEL%
