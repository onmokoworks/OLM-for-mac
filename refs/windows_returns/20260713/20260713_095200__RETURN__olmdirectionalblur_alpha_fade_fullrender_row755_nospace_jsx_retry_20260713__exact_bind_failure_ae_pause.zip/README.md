Status: `exact_bind_failure`

This request was re-run against `OLMDirectionalBlur.aex` with After Effects 2025 to avoid the AE 2026 compatibility modal. The supplied runner still failed at the AE pause stage: the ready marker was never written, so the JSX did not reach the expected paused state.

Included:
- original package manifests and runner files
- emitted `RETURN_RUNTIME_TRACE.json`
- work directory snapshot (`artifacts/`)

Observed failure:
- `failure.stage = ae_pause`
- `failure.reason = ready marker not written`
