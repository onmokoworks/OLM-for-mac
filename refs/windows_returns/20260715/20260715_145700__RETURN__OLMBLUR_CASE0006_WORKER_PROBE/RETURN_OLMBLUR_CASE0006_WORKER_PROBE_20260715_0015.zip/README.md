# OLMBlur case_0006 worker probe

- AE: 25.2x131
- Project: 16bpc, Software, working space None
- Direct UI render: `status=ok`
- PNG: `export/case_0006.png`
- `ae_ready.marker` and `ae_continue.marker` were observed.
- No `aex_smart_worker.exe` command line containing `OLMBlur.aex` was observed during this run.
- The worker monitor was corrected to avoid fragile module enumeration; the next run should use the same pause/continue wrapper with the corrected monitor.
