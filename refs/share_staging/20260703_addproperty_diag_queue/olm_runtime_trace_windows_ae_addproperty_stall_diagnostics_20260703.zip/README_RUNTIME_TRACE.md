# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `windows_ae_addproperty_stall_diagnostics_20260703`
   - Area: Windows AE addProperty return / modal / native-stall diagnostics
   - Action: LIVE NEW HOST DIAGNOSTIC REQUIRED. Do not use plugin-local witness breakpoints. Use the same exact-case requests that now prove request dispatch and target module load: `db_existing_case_0001_software_pair` from `directionalblur_context_scale_20260606` and `legacy_case_0004_current_aex` from `smoother2_legacy_full_current_aex_recapture_20260621`. Follow `refs/conformance/windows_ae_addproperty_stall_20260703.md`. The goal is to classify what happens across `effectParade.addProperty(...)`: success, catchable AE/ExtendScript error, hidden modal/dialog, or native/plugin init stall. Return the exact candidate string passed to addProperty, whether JSX returns from the try/catch, the exact caught error if any, and if it does not return, the exact last breadcrumb before stall plus any hidden/modal window titles, screenshot or window dump, and a compact first-chance exception summary between `about_to_add_effect` and timeout.
   - Stop: A satisfactory answer must classify the addProperty boundary itself for at least one exact case. Repeating only that the module loaded is failure.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
