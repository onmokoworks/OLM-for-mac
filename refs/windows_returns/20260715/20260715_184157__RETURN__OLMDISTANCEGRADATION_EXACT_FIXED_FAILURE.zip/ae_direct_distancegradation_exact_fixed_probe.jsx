(function () {
    var root = "C:/olm_short/batch_20260715_1518_distancegradation";
    var work = root + "/work/exact_fixed_probe_20260715";
    $.setenv("OLM_DG_LIVE_REQUEST_DIR", root + "/request");
    $.setenv("OLM_DG_LIVE_WORK_ROOT", work);
    $.setenv("OLM_DG_LIVE_RUN_ID", "dg8-exact-fixed-probe-20260715");
    $.setenv("OLM_AE_PAUSE_BEFORE_RENDER", "1");
    $.setenv("OLM_AE_PAUSE_TIMEOUT_SECONDS", "300");
    $.setenv("OLM_AE_FORCE_SOFTWARE", "1");
    $.evalFile(new File(root + "/scripts/ae_render_olmdistancegradation_8bpc_queue.jsx"));
}());
