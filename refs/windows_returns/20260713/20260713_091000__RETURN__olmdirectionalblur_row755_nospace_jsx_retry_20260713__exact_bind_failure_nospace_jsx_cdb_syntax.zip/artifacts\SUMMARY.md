Run summary for `olmdirectionalblur_alpha_fade_fullrender_row755_20260712`.

- AE 2025 launched successfully and the supplied JSX advanced through effect add and pause markers.
- The run used `OLMDirectionalBlur.aex` SHA-256 `d3e5e4079a759d521dc7457ebf998487fe43b00f182a1e2f910b187936b6c06e`.
- CDB resolved the live module base and attached to PID `39556`.
- `DBR_BREAKPOINTS_READY` was emitted.
- The generated `bu @$t0+0x5554 "...chunked .writemem..."` command overflowed into malformed quoted text and subsequent syntax errors.
- The rowdriver conditional also failed with `Numeric expression missing`.
- Final debugger outcome was `DBR_NO_CAPTURE`.
- No chunk binaries and no combined row755 plane binaries were produced, so this return is `exact_bind_failure`.
