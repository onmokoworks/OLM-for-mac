using System;
using System.Runtime.InteropServices;

public static class UcrtPowfCapture
{
    [DllImport("ucrtbase.dll", CallingConvention = CallingConvention.Cdecl,
        ExactSpelling = true, EntryPoint = "powf")]
    public static extern float Powf(float x, float y);

    public static uint Evaluate(uint inputBits, uint exponentBits)
    {
        float input = BitConverter.ToSingle(BitConverter.GetBytes(inputBits), 0);
        float exponent = BitConverter.ToSingle(BitConverter.GetBytes(exponentBits), 0);
        float result = Powf(input, exponent);
        return BitConverter.ToUInt32(BitConverter.GetBytes(result), 0);
    }
}
