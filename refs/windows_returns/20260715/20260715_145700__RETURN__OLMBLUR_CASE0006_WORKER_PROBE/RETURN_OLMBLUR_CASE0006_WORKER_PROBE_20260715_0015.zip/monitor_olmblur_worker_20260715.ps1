param(
    [string]$Work = 'C:\olm_short\batch_20260714_2205\work\olmblur_blur16-worker-probe-20260715-0015',
    [int]$Seconds = 900
)

$ErrorActionPreference = 'SilentlyContinue'
New-Item -ItemType Directory -Force -Path $Work | Out-Null
$log = Join-Path $Work 'worker_process_monitor.log'
$deadline = (Get-Date).AddSeconds($Seconds)
"started=$(Get-Date -Format o)" | Set-Content -LiteralPath $log -Encoding ASCII

while ((Get-Date) -lt $deadline) {
    $workers = Get-CimInstance Win32_Process -Filter "Name='aex_smart_worker.exe'"
    foreach ($w in $workers) {
        # CommandLine is stable enough for short-lived smart workers; module enumeration
        # can terminate the monitor when a worker exits during inspection.
        $hasOlmBlur = $w.CommandLine -like '*OLMBlur.aex*'
        $tag = if ($hasOlmBlur) { 'OLMBLUR_TARGET_WORKER' } else { 'worker_seen' }
        $line = [ordered]@{
            time = (Get-Date -Format o)
            tag = $tag
            pid = [int]$w.ProcessId
            parent_pid = [int]$w.ParentProcessId
            start_time = $null
            command_line = $w.CommandLine
            olmblur_module = if ($hasOlmBlur) { 'OLMBlur.aex (command line)' } else { $null }
            olmblur_base = $null
        }
        ($line | ConvertTo-Json -Compress) | Add-Content -LiteralPath $log -Encoding ASCII
    }
    Start-Sleep -Milliseconds 250
}
"finished=$(Get-Date -Format o)" | Add-Content -LiteralPath $log -Encoding ASCII
