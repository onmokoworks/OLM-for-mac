@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\olm_short\incoming_20260714_witness_batch_fixed\extracted\windows_witness_batch_20260713\batch_work\001_olmblur_case0006_same_run_20260713\package\work\olmblur16-case0006-18b052f2d254435ca0f5f068de0f99fe"
set "WINDOWS_WITNESS_RUN_ID=olmblur16-case0006-18b052f2d254435ca0f5f068de0f99fe"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\olm_short\incoming_20260714_witness_batch_fixed\extracted\windows_witness_batch_20260713\batch_work\001_olmblur_case0006_same_run_20260713\package"
set "WINDOWS_WITNESS_QUEUE_SHA256=6464dd609b94cbaeeb7e9a52ba76b6b200e2b478c662cf137a3ce75b5e2f87d1"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT=1"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe" -m -r C:\Users\Public\OLMWitness\w_52ece891256c\queue.jsx
exit /b %ERRORLEVEL%
