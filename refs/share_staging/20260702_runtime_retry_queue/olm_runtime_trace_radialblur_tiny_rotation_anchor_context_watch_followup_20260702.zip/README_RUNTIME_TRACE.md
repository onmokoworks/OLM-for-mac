# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `olmradialblur_tiny_rotation_anchor_context_watch_followup_20260702`
   - Area: OLMRadialBlur tiny Rotation anchor context/watch reconstruction follow-up
   - Action: Trace only OLMRadialBlur tiny Rotation `case_0010` witness `(1614,6)` on the current Software AEX path, anchored from the already stable inverse-sampler hit `OLMRadialBlur+0x4eb9/+0x4ec8`, but this round treat anchor-context reconstruction as the primary task. At the stable anchor, dump `rsi/rbp/rsp` qword windows plus any polar-grid, row-base, and metadata pointers before continuing, compute the exact sampled-cell address for source xy `[1603.8396,844.3175]`, then set the narrowest read/write watchpoints on that cell and adjacent row cells before final inverse sampling. Capture the first upstream promotion branch that can still turn the witness chain from near-black into white: concrete sampled-cell address, neighboring-row addresses, substitute/fallback or source-population decision, preserved validity `+0xf252`, accumulated `+0xf250` RGBA, normalized final polar `+0xe` RGBA, and any typed row/angle/cell addresses involved before final inverse sampling. If the cell cannot be reconstructed, the retained log must still include the exact failed address/condition together with the dumped `rsi/rbp/rsp` qword windows and anchor-context pointers that blocked the reconstruction.
   - Stop: Return enough typed pointer/watchpoint evidence to decide which anchored upstream branch actually promotes the missing bright lobe at `case_0010 (1614,6)`. If the watchpoint path still cannot be held, return the exact failed address/condition plus the dumped `rsi/rbp/rsp` qword windows and pointer context used to reconstruct the sampled-cell address.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
