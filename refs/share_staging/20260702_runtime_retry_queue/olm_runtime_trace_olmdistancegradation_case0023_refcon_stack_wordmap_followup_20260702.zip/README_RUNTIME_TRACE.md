# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `olmdistancegradation_case0023_refcon_stack_wordmap_followup_20260702`
   - Area: OLMDistanceGradation case_0023 refcon/stack/output-word mapping follow-up
   - Action: Trace only OLMDistanceGradation normalized Software 16bpc `olmdistancegradation_extended__case_0023` threshold-family witnesses `(414,393)`, `(415,393)`, `(416,393)`, but this round treat stack/refcon/output-word reconstruction as the primary task at `FUN_181170480`. At every relevant hit, first dump `r8`, `r9`, `[rsp+0x28]`, and enough surrounding qwords/dwords to infer width, stride, current output pointer, and any refcon layout needed to recover xy/output-address mapping. Once that mapping is known, set data breakpoints on the three `RGBA16` output word ranges and dump the same frame before store. Do not spend time on broad callback activity or final-only endpoint restatement. Record XY, recovered output-word address, raw inside/outside distances, helper-stage field value, exact threshold/equality/plateau decision, whether the Constant binary fork runs before or after that decision, the value consumed by `FUN_181170480`, compose output RGBA before word store, and final stored RGBA16. The README triplet `(414,393)/(415,393)/(416,393)` is authoritative; do not fall back to the older edge witnesses. If the watchpoint/bind still cannot be held, the retained log must still include the exact failed address/condition plus the dumped `r8`, `r9`, `[rsp+0x28]`, and surrounding pointer/stack window that blocked reconstruction.
   - Stop: Return enough typed values to explain the `case_0023` triplet crossing with XY bound from recovered output-word/refcon/stack mapping at `FUN_181170480`. If even that stop cannot be isolated, return the precise failed bind/watchpoint reason plus the exact address/condition and the dumped `r8/r9/[rsp+0x28]` layout and pointer state needed for the next retry.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
