/* UI-run wrapper: pause before render so the smart worker can be identified safely. */
(function () {
    var root = "C:/olm_short/batch_20260714_2205";
    var work = root + "/work/olmblur_blur16-worker-probe-20260715-0015";
    $.setenv("OLM_BLUR16_REQUEST_DIR", root + "/request");
    $.setenv("OLM_BLUR16_WORK_ROOT", work);
    $.setenv("OLM_BLUR16_RUN_ID", "blur16-worker-probe-20260715-0015");
    $.setenv("OLM_AE_PAUSE_BEFORE_RENDER", "1");
    $.setenv("OLM_AE_PAUSE_TIMEOUT_SECONDS", "900");
    $.setenv("OLM_AE_FORCE_SOFTWARE", "1");
    $.setenv("OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT", "1");
    $.evalFile(new File(root + "/scripts/ae_render_olmblur_case0006_queue.jsx"));
}());
