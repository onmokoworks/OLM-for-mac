param(
  [Parameter(Mandatory=$true)][string]$AfterFX,
  [Parameter(Mandatory=$true)][string]$ColorKeyAex,
  [Parameter(Mandatory=$true)][string]$ToonDilateAex,
  [Parameter(Mandatory=$false)][string]$OutputDir=""
)
$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$RunDir=if($OutputDir){$OutputDir}else{Join-Path $Root "run"}
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
$Cases=ConvertFrom-Json @'
[{"id":"olmcolorkey__case_0002","spec":"refs/reference_requests/olm_bitdepth_32bpc_colorkey_float_20260710.json","effect":"OLM Color Key","plugin_name":"OLMColorKey.aex","plugin_sha256":"9c6cca226a52d35ce7833fcc4c0f914f6b15b3abe0202e0957ba97ba3bb2cf2c"},{"id":"olmtoondilate__case_0001","spec":"refs/reference_requests/olm_bitdepth_32bpc_toondilate_float_20260710.json","effect":"ADBE OLMToonDilate","plugin_name":"OLMToonDilate.aex","plugin_sha256":"c05db8c118029ff3216d3cae8e6423e2eb41ca8f56de2fb3668db81b9b8c32b3"}]
'@
function WriteJson($Path,$Value){$Value|ConvertTo-Json -Depth 30|Set-Content -Encoding UTF8 $Path}
function Fail([string]$Status,[string]$Message){WriteJson (Join-Path $RunDir "return_manifest.json") ([ordered]@{kind="olm_32bpc_second_generation_return";status=$Status;error=$Message;rendered=$false});throw "$Status`: $Message"}
if(-not(Test-Path -LiteralPath $AfterFX -PathType Leaf)){Fail "missing_afterfx" "AfterFX.exe missing"}
if($env:OLM_EXR_TEMPLATE -and $env:OLM_EXR_TEMPLATE -cne "OLM EXR 32 Float"){Fail "wrong_template" "OLM_EXR_TEMPLATE must be exactly OLM EXR 32 Float"}
$Template="OLM EXR 32 Float"
$Plugins=@{"OLMColorKey.aex"=$ColorKeyAex;"OLMToonDilate.aex"=$ToonDilateAex}
$PluginRecords=@{}
foreach($c in $Cases){$p=$Plugins[$c.plugin_name];if(-not(Test-Path -LiteralPath $p -PathType Leaf)){Fail "missing_plugin" "$($c.plugin_name) missing"};$h=(Get-FileHash -Algorithm SHA256 -LiteralPath $p).Hash.ToLowerInvariant();if($h -ne $c.plugin_sha256){Fail "hash_mismatch" "$($c.plugin_name) $h != $($c.plugin_sha256)"};$PluginRecords[$c.plugin_name]=[ordered]@{path=(Resolve-Path $p).Path;sha256=$h}}
$Results=@()
foreach($c in $Cases){
  $RequestDir=Join-Path $Root ("cases\"+$c.id)
  foreach($mode in @("effect_on","no_effect")){
    $Out=Join-Path $RunDir ($c.id+"_"+$mode);New-Item -ItemType Directory -Force -Path $Out|Out-Null
    $env:OLM_AE_REQUEST_DIR=$RequestDir;$env:OLM_AE_CASE_ID=$c.id;$env:OLM_AE_OUTPUT_DIR=$Out
    $env:OLM_AE_LOG_PATH=Join-Path $Out "AE_SINGLE_CASE.log";$env:OLM_AE_RESULT_JSON=Join-Path $Out "AE_SINGLE_CASE_RESULT.json"
    $env:OLM_AE_OUTPUT_MODE="exr_render_queue";$env:OLM_AE_OUTPUT_TEMPLATE=$Template;$env:OLM_AE_FORCE_SOFTWARE="1"
    $env:OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT="1";$env:OLM_AE_FORCE_NEW_PROJECT="1";$env:OLM_AE_KEEP_OPEN=""
    $env:OLM_AE_DISABLE_EFFECT=if($mode -eq "no_effect"){"1"}else{""}
    & $AfterFX -r (Join-Path $Root "render_case.jsx")
    if($LASTEXITCODE -ne 0 -or -not(Test-Path $env:OLM_AE_RESULT_JSON)){Fail "render_failed" "$($c.id) $mode did not return JSON"}
    $r=Get-Content $env:OLM_AE_RESULT_JSON -Raw|ConvertFrom-Json
    if($r.status -ne "ok" -or $r.project_bits_per_channel -ne 32 -or $r.project_linear_blending -ne $false){Fail "contract_mismatch" "$($c.id) $mode host contract mismatch"}
    if(($mode -eq "no_effect") -ne [bool]$r.effect_disabled){Fail "effect_state_mismatch" "$($c.id) $mode effect state mismatch"}
    if(-not $r.output_exr -or -not(Test-Path -LiteralPath $r.output_exr)){Fail "missing_exr" "$($c.id) $mode EXR missing"}
    $Results += [ordered]@{case_id=$c.id;mode=$mode;effect=$c.effect;plugin=$PluginRecords[$c.plugin_name];result=$r;exr_sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $r.output_exr).Hash.ToLowerInvariant()}
  }
}
if(-not $Results[0].result.ae_version.StartsWith("26.3")){Fail "wrong_ae_version" "AE 26.3 required; got $($Results[0].result.ae_version)"}
$Manifest=[ordered]@{kind="olm_32bpc_second_generation_return";schema=1;status="rendered";rendered=$true;ae_version=$Results[0].result.ae_version;renderer="SOFTWARE";bits_per_channel=32;linear_light=$false;output_template=$Template;input_contract="same supplied Windows before-effect EXR re-imported for effect-on and no-effect";results=$Results}
WriteJson (Join-Path $RunDir "return_manifest.json") $Manifest
$Zip=Join-Path (Split-Path $RunDir -Parent) "olm_windows_32bpc_second_generation_parity_return.zip"
if(Test-Path $Zip){Remove-Item $Zip -Force}
Compress-Archive -Path (Join-Path $RunDir "*") -DestinationPath $Zip
Write-Host "OK return=$Zip"
