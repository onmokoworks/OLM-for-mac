# OLMDirectionalBlur Front Alpha Fade Host-Boundary Proof

Request id: `olmdirectionalblur_front_alpha_host_boundary_2025_20260711`

This package captures the PF input world immediately before the 2025
`OLMDirectionalBlur.aex` populate callback and the PF output world immediately
after `Iterate8`, in one After Effects process and one render.

## Run on Windows

Requirements: After Effects 2026, Windows SDK x64 CDB, and the exact retained
2025 AEX installed at the path supplied below. Close all After Effects processes
first, extract this package to a local path, then run:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_front_alpha_host_boundary.ps1 -AexPath "C:\path\to\installed\OLMDirectionalBlur.aex"
```

The runner expects CDB at the Windows SDK default path and AfterFX at the Adobe
2026 default path; use `-CdbPath` or `-AfterFxPath` to override either. Results
are written under `work\<run-id>\`, including `RETURN_RUNTIME_TRACE.json`,
`input_argb8_tight.bin`, `output_argb8_tight.bin`, padded raw dumps, CDB output,
the rendered PNG, and AE logs. Before exit, the runner automatically creates a
`*_return_windows.zip` beside the `work` directory and prints its full path.

The fixture is imported as `PREMULTIPLIED`, matching the retained case replay
whose host-boundary residual is under investigation. Changing the alpha
interpretation makes the returned worlds a different experiment and fails the
request contract.

## Exact live contract

- Required AEX SHA256: `d3e5e4079a759d521dc7457ebf998487fe43b00f182a1e2f910b187936b6c06e`
- Required AEX size: `56832`
- Input hook: module `+0x5267`, before call at `+0x6980`, PF world in `R12`
- Output hook: module `+0x566A`, after Iterate8 at `+0x6B30`, PF world at `poi(@rsp+0x58)`
- PF world fields: data `+0x18`, rowbytes `+0x20`, width `+0x24`, height `+0x28`,
  extent `+0x2C..+0x38`, origin `+0x68/+0x6C`
- Required geometry: 1920x1080 ARGB8, rowbytes at least 7680

Only these two host-boundary sites are hooked. Per-pixel callbacks must never be
hooked. CDB dumps `rowbytes * height` bytes at each site. PowerShell then copies
exactly `width * 4` bytes from each row, producing exactly 8,294,400 bytes per
tight dump.

The runner hash-gates `-AexPath` before launch and requires CDB's loaded `Image
path` to resolve to the same file. The return records loaded module path, base,
image size, PE timestamp, file/product version, SHA256, AE PID, run id, fixture
identity, extent/origin, world fields, dump hashes, and dump sizes. Input and
output must also carry the same function-frame pointer, render-context pointer,
and saved output-world pointer; this binds the pair to one render invocation.

## Status vocabulary

- `answered`: exact hash/path gate passed and exactly one valid input dump plus
  exactly one valid output dump were captured in the same AE PID/render.
- `binary_identity_mismatch`: nominated or loaded AEX path, size, or SHA256
  differs; offset hooks are not accepted.
- `module_identity_failure`: loaded module path or CDB module metadata cannot be
  proven to match the nominated AEX.
- `world_validation_failure`: a PF world is null, not 1920x1080, or has rowbytes
  below 7680.
- `exact_dump_failure`: either boundary hit count is not exactly one, the
  invocation/context/output-world binding differs, either raw dump is
  absent/wrong-sized, or either tight dump is absent/wrong-sized.
- `render_failure`: AE/CDB or the fixture render failed before acceptance.
- `return_packaging_failure`: evidence was written to the run directory, but
  the automatic return ZIP could not be created.

All non-`answered` statuses are failures. Partial returns are forbidden.

## Reference provenance warning

`case/reference_manifest.json` and `case/expected/...png` are retained June 19
reference material. Their producing AEX identity was not hash-bound in that
capture. That reference provenance is **UNPROVEN** and must not be used as proof
that the expected PNG came from the required 2025 binary. It is included only
for case identity and visual comparison; this live boundary capture is the
requested provenance proof.
