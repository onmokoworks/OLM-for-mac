@echo off
set "WINDOWS_WITNESS_WORK_ROOT=C:\Users\optim\olm_s2_inprocess_run\work\smoother2-legacy-producer-inprocess-2f98bd27a20b456f99026bfb757b7980"
set "WINDOWS_WITNESS_RUN_ID=smoother2-legacy-producer-inprocess-2f98bd27a20b456f99026bfb757b7980"
set "WINDOWS_WITNESS_PACKAGE_ROOT=C:\Users\optim\olm_s2_inprocess_run"
set "WINDOWS_WITNESS_QUEUE_SHA256=ed970c9ea6ee184cd81d53be1eddbbaa3cdbdae64814ad9f60acb6e82e558366"
set "OLM_AE_PAUSE_BEFORE_RENDER=1"
set "OLM_AE_PAUSE_TIMEOUT_SECONDS=300"
set "OLM_AE_FORCE_SOFTWARE=1"
set "OLM_AE_DISABLE_PROJECT_COLOR_MANAGEMENT=1"
"C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe"
exit /b %ERRORLEVEL%
