status: blocked
summary:
  Blanket fixture removal loses 169 of 315 Smart admissions; those conditions must remain.
  Narrow 32x18/three-Gaussian-leaf OFF passes the focused pixel campaign.
  Deleting the 32x18 helper fails a currently passing out-of-scope text assertion.
  Operative source changes were reverted; only a retention comment is committed.
  No removal or release-gate completion is claimed.

facts:
- Base: `db59044515791af9890d0768c1fa4c7f5ad34034`, branch `orch/F01-fixtures-olmkirakira`.
- Read `AGENT_GUIDE.md`, `orchestra/FIXTURE_REMOVAL.md`, `orchestra/REFACTOR_SPEC.md`,
  `tools/emulation/GOTCHAS.md`, compatibility plan, and KiraKira ledger row.
- Original AEX SHA-256: `60997c0c52207c15844a46289435231fa6b0a885f63778404e02cea6e03899f7`.
- Worker: `/Users/onmk/.cache/olm-emu/worker-F54c/aex-guest-worker`, SHA-256
  `3d5eec0c6792f176a9cfbc38093c53b852f4ea1baae2cfd313345c02f55d6fba`.
  No worker rebuild, MAIN modification, release-gate modification, or push.

Predicate inventory (fact from source; classification is interpretation):
- Fixture-style: seven literal conjunctions in `ClassicClosureSourceFamilyForTuple`:
  `mode1_horizontal`, `mode1_highlight`, `mode2_horizontal`, `mode2_highlight`,
  `mode3_horizontal`, `mode4_highlight_gradient`, `mode4_declared_family`.
  The shared default-white/ramp and zero/default-control preconditions complete their tuples.
  `IsClassicClosureTuple` wraps the map. This map is also used by general-size admission.
- Fixture-style: `IsClassicClosureLayout` (5x3), `IsMode3Closure32x18Tuple`,
  `IsMode3Closure32x18Layout`, and `ClassicClosureSourceMatches` (per-index byte patterns,
  PF16 promotion and PF32 bit comparison). Their entry-point consumers are
  `classic_closure`, `mode3_32x18_closure`, `pre_is_classic`, `pre_is_mode3_32x18`,
  `exact_world_layout`, `exact_tuple_is_admitted`, and `exact_closure`.
- Fixture-style workspace exceptions in `mode3_gaussian_admitted`:
  `(11,6,3)`, `(13,5,7)`, `(15,6,9)` for width/height/length.
- General, retained: `IsGenericBetaFullFrameDimensions`, `IsSmartOwnerFullFrameDimensions`,
  `KiraSmartGeometryFits`, checked multiply/add, generic Mode3 memory/work limits,
  `GenericBetaDirectionalRayIsAdmitted`, generic layout/disjoint-storage checks,
  finite-SDR/source support checks, `IsZeroRayTuple`/`IsSmartZeroRayTuple`,
  `IsAlphaBoxTuple`, Smart scalar/color box, approximation and directional Gaussian checks.
  Enum dispatch, zero-length skip, percentage endpoints, float representability and
  recovered seed/color pipeline selection are general, despite literal equalities.
- Mixed dependencies, retained: `IsGenericBetaMode12Tuple`,
  `IsGenericBetaMode3HorizontalTuple`, `IsGenericBetaMode34TupleForGeometry`,
  `IsGenericBetaTupleForGeometry` use the fixed map at arbitrary frame sizes.
  `ColorIsClosureWhite` and `RampIsClosureDefault` describe control values, not source pixels;
  the latter also gates general ray support.
- The brief's “98” is not used as an independently verified predicate count. The explicit
  regex `\binfo\.\w+\s*==\s*-?[\d.]+` finds 86 equalities in Admission, 20 in Filters,
  and 15 in Render (121 total). These are expressions, not 121 removable predicates.

Oracle campaign results (seed 1001, 315 cases each; same input hashes and parameters):

| Campaign | Smart exact | Smart mismatch | Smart uncompared/refusal | Classic exact | Classic mismatch | Classic uncompared/refusal |
|---|---:|---:|---:|---:|---:|---:|
| ON (base behavior) | 259 | 0 | 56 | 0 | 236 | 79 |
| All closure admissions OFF | 90 | 0 | 225 | 0 | 40 | 275 |
| Selected OFF: 32x18 + Gaussian exceptions | 259 | 0 | 56 | 0 | 236 | 79 |
| Gaussian leaf supplement ON (18) | 18 | 0 | 0 | 0 | 0 | 18 |
| Gaussian leaf supplement OFF (18) | 18 | 0 | 0 | 0 | 0 | 18 |

- Every original Classic and Smart oracle execution returned `ok`: 315 per route in
  each primary campaign, 18 per route in each supplement. No timeout or framework
  failure in these completed campaigns. “Uncompared” above is specifically native refusal.
- All-OFF changed 169 Smart observations. First: index 0, `mode1_horizontal`, 5x3 PF8,
  input SHA-256 `40a68d8a2f5e83c281777829bffdbdb4850838d44a7746e03c94286918d2e3b9`.
  ON is exact with raw SHA-256
  `9c20573663b0cda83708eeb206ac7a6dddd6705629eeee0f7a9d357959881ef6`;
  OFF refuses with error 516. There is no first differing output byte for a refusal.
- Selected OFF has zero changed Smart observations. First existing Classic mismatch
  (ON and selected OFF) is index 0, byte 0: original `00`, Mac `44`, 60 differing bytes.
  Classic is reported separately under T14; it is not promoted to exact.
- The generator parses the seven conjunctions, rejection-samples until each full expression
  is true, sets shared defaults, cycles 5x3/32x18/9x7 and all depths, uses mostly opaque
  random sources plus the exact byte-pattern sources in one quarter of cases.
  The supplement parses all three workspace triples and uses source dimensions minus 4.
- Initial generator attempt: 315 framework errors from Python multiline-expression syntax,
  before any case comparison. Parenthesizing the expression fixed it; excluded from oracle counts.

G1 numbers and limits:
- Stable selected-OFF experiment, `native_diff --cases 300 --seed 909 --arch arm64
  --build reference --jobs 1`: 303 comparisons (including three UHD), 298 exact,
  5 identical refusals, 0 differences, 0 new refusals, 0 execution errors; exit 0.
- Earlier exploratory both-arch/both-build run: 1,212 comparisons, 1,192 exact,
  20 identical refusals, 0 differences/errors/new refusals. **Not a qualification run**:
  WORKTREE was changed between configuration builds. Do not treat it as one-source proof.
- Required final 3,000-case both-arch/both-build G1: **not run** after the deletion blocker.
  G2/G4/G5 full gates: **not run**. No final OFF deletion campaign is claimed.
- Concrete blocker: targeted test
  `test_olmkirakira_generic_beta_lane_20260820.KiraKiraGenericBetaLaneTests.test_mode3_generic_uses_full_visible_ui_length_without_widening_exact_tuple`
  passed before deleting `IsMode3Closure32x18Tuple`, failed afterwards at line 51
  (`AssertionError: unexpectedly None : IsMode3Closure32x18Tuple`), and passes again restored.
  The function was removed by a small Python substring script, then restored. No weakened test.
- Additional static contract: `tools/emulation/test_kirakira_mode3_nonwhitelist_geometry.cpp`
  explicitly asserts all three Gaussian exceptions (lines 11, 34, 35). Its contract would
  also need review before removal; no claim that this executable was run.
- No tool approval rejection occurred. All started processes completed. Scratch is 13 MiB;
  shared runners removed regenerable hosts/archives. Remaining files are logs, observations,
  and scratch reproduction scripts, not durable workers or bundles.

inference:
- Blanket removal is incorrect: fixed-looking controls still supply Smart admissions absent
  from the general >=1 brightness path and Mode4 path. The campaign proves the combined
  dependency, not which individual map member alone causes each lost admission.
- Narrow removal looks pixel-neutral on the measured cases, but cannot satisfy the existing
  test contract within this ticket's scope. `REFACTOR_SPEC.md` says “Never weaken what a test
  asserts”; the test is outside `mac/OLMKiraKira` and plugin-only core headers. I have not
  interpreted fixture removal as permission to change that assertion or retain dead helpers
  solely to appease it. This is the reason for `blocked`, not an oracle Smart mismatch.

Code lines before/after:
- Same inventory as Q03: top-level plugin cpp/h/inc plus all `core/kirakira*.h`; excludes tests,
  project/resources and report artifacts. Counts strip comments while preserving string literals.
- Physical: 5,419 -> 5,420 (one explanatory comment). Non-comment/nonblank: 4,871 -> 4,871.
- Per-file baseline counts are in `F01-fixtures-olmkirakira-evidence/line-counts.json`;
  every final code count is identical. Only Admission's physical count increases by one.

changed_files:
- `mac/OLMKiraKira/KiraAdmission.inc`: one-line reason to retain closure admissions.
- `orchestra/reports/F01-fixtures-olmkirakira.md`: this report, including reproduction code.
- `orchestra/reports/F01-fixtures-olmkirakira-evidence/`: compressed full campaign reports,
  stable preliminary differential summary, line counts and targeted before/after test logs.

verify:
Use a disposable ticket worktree at the base above for experimental source switching.
The following scripts are embedded here instead of committing one-off tool files, as required
by REFACTOR_SPEC. Extract the two `python` blocks, in order, as `switch.py` and `focused.py`
under `orchestra/state/F01-fixtures-olmkirakira`. Run each campaign to completion before
changing the source. The switch script always derives from the recorded base.

```sh
S="$PWD/orchestra/state/F01-fixtures-olmkirakira"
export TMPDIR="$S" OLM_TEST_JOBS=1 OLM_PARALLEL_MAX=1
# Repeat with pairs on/on, all/off2, selected/selected-off:
F01_SWITCH=on python3 "$S/switch.py"
python3 "$S/focused.py" --plugin olmkirakira --n 315 --seed 1001 --jobs 1 \
  --budget-minutes 30 --case-timeout 20 --shrink-attempts 0 \
  --worker /Users/onmk/.cache/olm-emu/worker-F54c/aex-guest-worker \
  --scratch "$S/recheck-on" --report "$S/recheck-on.json" \
  --corpus "$S/recheck-on-corpus" > "$S/recheck-on.log" 2>&1
# Supplement: same invocation, n=18, separate paths, F01_CORE_CAMPAIGN=1;
# use switch on then selected for the two runs. Expected table above.
# Stable preliminary random verification with switch selected:
python3 tools/refactor/native_diff.py --plugin olmkirakira \
  --base db59044515791af9890d0768c1fa4c7f5ad34034 --head WORKTREE \
  --cases 300 --seed 909 --arch arm64 --build reference --jobs 1 \
  --scratch "$S/recheck-native" > "$S/recheck-native.log" 2>&1
# Expected 303 comparisons, 298 exact, 5 refusals, zero differences/errors/new refusals.
PYTHONPATH=tests python3 -m unittest \
  test_olmkirakira_generic_beta_lane_20260820.KiraKiraGenericBetaLaneTests.test_mode3_generic_uses_full_visible_ui_length_without_widening_exact_tuple
# Expected PASS on committed source; FAIL if the named helper is deleted.
```

next:
- Authorize a follow-up that updates the obsolete fixture-presence tests while retaining
  behavioral coverage. Then fold 32x18 and Gaussian exceptions away mechanically, run the
  final OFF campaign, full G1 (3,000 cases × both architectures × both builds), G2/G4/G5.
- Keep the fixed map and 5x3 closure until their missing general admissions are recovered
  against the original. Do not broaden brightness/Mode4 admission merely to make this refactor green.

Reproduction switch:

```python
import os, subprocess
from pathlib import Path
base='db59044515791af9890d0768c1fa4c7f5ad34034'
mode=os.environ['F01_SWITCH']  # on, all, selected
root=Path.cwd(); scratch=root/'orchestra/state/F01-fixtures-olmkirakira'
scratch.mkdir(parents=True,exist_ok=True)
def original(path): return subprocess.check_output(['git','show',base+':'+path],text=True)
f='mac/OLMKiraKira/KiraAdmission.inc';s=original(f)
(scratch/'admission-base.inc').write_text(s)
macro='#ifndef OLM_KIRAKIRA_FIXTURE_PATHS\n#define OLM_KIRAKIRA_FIXTURE_PATHS '+('1' if mode=='on' else '0')+'\n#endif\n'
selected=['IsMode3Closure32x18Tuple','IsMode3Closure32x18Layout']
all_names=['ClassicClosureSourceFamilyForTuple','IsMode3Closure32x18Tuple','IsClassicClosureLayout','IsMode3Closure32x18Layout','ClassicClosureSourceMatches']
for name in all_names if mode in ('all','on') else selected:
 pos=s.index('{',s.index(name+'('))+1
 ret='ClassicClosureSource_None' if name=='ClassicClosureSourceFamilyForTuple' else 'false'
 s=s[:pos]+'\n\tif (!OLM_KIRAKIRA_FIXTURE_PATHS) return '+ret+';'+s[pos:]
(root/f).write_text(macro+s)
f='core/kirakira_gaussian.h';s=original(f)
if mode=='selected':
 s=s.replace('#pragma once','#pragma once\n'+macro).replace('    return (width == 11','    if (!OLM_KIRAKIRA_FIXTURE_PATHS) return false;\n    return (width == 11')
(root/f).write_text(s)
```

Focused generator:

```python
import os, collections, random, re, runpy, struct, sys
from pathlib import Path
from types import SimpleNamespace
ROOT = Path.cwd()
sys.path.insert(0, str(ROOT/'tools/fuzz'))
import adapters.olmkirakira as kk
from core import case_seed
SLOT = dict(channel=1, blur_mode=2, merge_mode=3, approximated_input=4, brightness_gain=5,
 strength_multiplier=6, fade_out=7, glow_opacity=8, source_opacity=9, vertical_length=10,
 vertical_use_ramp=13, horizontal_length=16, horizontal_use_ramp=19, diagonal_length=22,
 diagonal_use_ramp=25, diagonal2_length=28, diagonal2_use_ramp=31, highlight_radius=34,
 highlight_use_ramp=37, glow_rotation=40)
src = (ROOT/'orchestra/state/F01-fixtures-olmkirakira/admission-base.inc').read_text()
flags=[]
for name, body in re.findall(r'const bool (mode\w+) =\s*(.*?);',src,re.S):
 eq=collections.defaultdict(set)
 for f,v in re.findall(r'info\.(\w+) == (-?[\d.]+)',body): eq[f].add(float(v))
 expr=re.sub(r'!(?!=)', ' not ', body).replace('&&',' and ').replace('||',' or ')
 flags.append((name,eq,expr))
base=kk.Adapter.generate
def generate(self,seed,index):
 rng=random.Random(case_seed(seed,index)^0xf01)
 name,eq,expr=flags[index%len(flags)]
 w,h=[(5,3),(32,18),(9,7)][(index//len(flags))%3]
 fields=dict(channel=1, approximated_input=0, brightness_gain=1, strength_multiplier=1,
 fade_out=0, glow_opacity=1, source_opacity=1, glow_rotation=0,
 **{k:0 for k in SLOT if k.endswith(('_length','_radius','_use_ramp'))})
 for attempt in range(10000):
  for f,vs in eq.items(): fields[f]=rng.choice(sorted(vs))
  for f in re.findall(r'(?<!!)info\.(\w+_use_ramp)',expr): fields[f]=rng.choice([0,1])
  if eval('('+expr+')',{'info':SimpleNamespace(**fields)}): break
 else: raise RuntimeError(name)
 if os.environ.get('F01_CORE_CAMPAIGN'):
  import subprocess
  core=subprocess.check_output(['git','show','HEAD:core/kirakira_gaussian.h'],text=True)
  leaves=re.findall(r'width == (\d+) && height == (\d+) && length == (\d+)',core)
  rw,rh,length=map(int,leaves[index%len(leaves)])
  w,h=rw-4,rh-4
  fields.update(blur_mode=3,merge_mode=1,brightness_gain=1,glow_rotation=0,
   horizontal_length=length,diagonal2_length=0,highlight_radius=0,horizontal_use_ramp=0,highlight_use_ramp=0)
  name='gaussian-leaf-'+str((rw,rh,length))
 case=base(self,seed,index);params=self.defaults(w,h)
 for p in params:
  f=next((f for f,s in SLOT.items() if s==p['slot']),None)
  if f:
   v=fields[f]
   if f in ('strength_multiplier','glow_opacity','source_opacity'): v*=100
   if f=='glow_rotation': v/=65536
   p['value']=int(v) if p['kind'] in ('i','u','b') else v
  elif p['kind']=='c': p['value']=[255]*4
 depth=[8,16,32][(index//(3 if os.environ.get('F01_CORE_CAMPAIGN') else 21))%3]; raw=bytearray()
 exact=index%4==0
 gradient='highlight' in name and 'declared' not in name
 for i in range(w*h):
  vals=[(i*15)%256 if gradient else (64+i*11)%256,
        0 if gradient else (i*15)%256,0 if gradient else (i*11)%256,0 if gradient else (i*7)%256]
  if depth==32:
   vals=[v/255 for v in vals] if exact else [1. if rng.random()<.85 else rng.random(),rng.random(),rng.random(),rng.random()]
   raw+=struct.pack('<4f',*vals)
  else:
   top=255 if depth==8 else 32768
   vals=[int(v*top/255+.5) for v in vals] if exact else [top if rng.random()<.85 else rng.randint(0,top),rng.randint(0,top),rng.randint(0,top),rng.randint(0,top)]
   raw+=struct.pack('<4B' if depth==8 else '<4H',*vals)
 case.update(geometry=[w,h],parameters=params,depth=depth,pixels=bytes(raw),profile='sdr',fixture=name)
 return case
kk.Adapter.generate=generate
sys.argv=[str(ROOT/'tools/fuzz/run.py')]+sys.argv[1:]
runpy.run_path(sys.argv[0],run_name='__main__')
```
