# OLM Runtime Trace Request Package

This zip is for the Windows machine / Windows Codex session.
It asks for debugger or exact-library primitive facts, not another PNG render batch.

Entrypoint: `notes/WINDOWS_RUNTIME_TRACE_REQUESTS.md`

Priority order:

1. `olmdirectionalblur_angle0_helper_gate_retry_20260702`
   - Area: OLMDirectionalBlur angle-0 helper-local witness gate retry
   - Action: LIVE NEW TRACE REQUIRED. Do not use a surrogate load case and do not stop at broad +0x2000 hits. Use the real request set `directionalblur_context_scale_20260606`, case `db_existing_case_0001_software_pair`, and target only the angle-0 witness lane described in `refs/conformance/olmdirectionalblur_angle0_helper_gate_retry_20260702.md`. If needed, use a single broad entry hit only to confirm module load, then move to a narrower rowdriver/front-helper stage for the same render. The required same-pass witness record is `(494,169)` plus endpoint `(579,169)`, with normalized consumed parameters, A/B mapping, denominator, `alpha_or_valid` or equivalent validity side-channel, helper-local source x/y, actual touched destination x range on row `y=169`, rowdriver/group membership, pre-writeback RGBA, and final stored bytes.
   - Stop: A satisfactory answer must return typed angle-0 witness-local fields for both `(494,169)` and `(579,169)` in the same pass. Broad `+0x2000` hit storms, final bytes alone, or surrogate cases count as failure.

Return exactly the trace values / primitive fact requested in the note.
You can fill `RETURN_RUNTIME_TRACE_TEMPLATE.json` and zip it back as the return artifact.
Do not tune implementation code from PNG residuals while answering this package.
