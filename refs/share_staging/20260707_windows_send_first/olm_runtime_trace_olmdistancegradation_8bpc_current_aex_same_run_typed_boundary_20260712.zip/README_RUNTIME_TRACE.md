# OLMDistanceGradation 8bpc Current-AEX Typed Boundary v4

Status: ready and sendable.

This request extends the accepted desktop depth-control launch contract into a
three-case typed capture. The accepted control used run prefix `dglive-983b`,
AE PID `5936`, module base `0x7fffcd660000`, AEX SHA-256 `a1d317c0e18371494bc9c9933684593ca903eb6f3fe262ec06d5147b4c0bcbae`, an
8bpc project, PF8 `+0x1170870` hit count `24377`, and PF32 `+0x1170c90` hit
count `0`. Those PID/base values identify the accepted prior run; the v4
runner discovers and returns the fresh run's actual PID/base and requires one
identity across all three captures.

The runner launches After Effects normally in the caller's desktop session.
For each of `case_0001`, `case_0015`, and `case_0029`, the included renderer
pauses only after `effect_loaded=1` and `parameters_applied=1`. The runner then
finds exactly one matching AfterFX process, pins the loaded module to the
expected hash, and attaches CDB. Initially only PF8 and PF32 depth-control
breakpoints are armed. The PF8 exact-coordinate hit at `(397,281)` emits
`DG8_DEPTH_CONTROL_CONFIRMED` and only then arms the typed PF8 sites.

The five required records are `FIELD_IN`, `FIELD_OUT`, `COMPOSE_IN`,
`COMPOSE_OUT`, and `HOST_STORE`. Every record binds the same run ID, AE PID,
module base, AEX hash, project depth, case, coordinate, and live output address.
Field/source base, rowbytes, pixel size, exact address formulas, byte values,
normalized field scalars, pre-store floats, and final host bytes are retained.

Run:

`artifacts/run_olmdistancegradation_8bpc_current_aex_same_run_typed_boundary_20260712.ps1`

`-ParseOnly -TracePath <combined_cdb_trace.txt>` runs the same fail-closed
trace classifier. The return embeds raw launcher, CDB, AE, readiness, and queue
logs on both success and failure; the work directory also retains each file.
No partial status is accepted.
